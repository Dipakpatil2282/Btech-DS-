-- Create profiles table
CREATE TABLE IF NOT EXISTS public.profiles (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT,
  email TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS for profiles
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Create policies for profiles
CREATE POLICY "Users can view their own profile"
  ON public.profiles
  FOR SELECT
  USING (auth.uid() = user_id);
  
CREATE POLICY "Users can insert their own profile"
  ON public.profiles
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);
  
CREATE POLICY "Users can update their own profile"
  ON public.profiles
  FOR UPDATE
  USING (auth.uid() = user_id);

-- Create interview_results table
CREATE TABLE IF NOT EXISTS public.interview_results (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  job_role TEXT NOT NULL,
  level TEXT NOT NULL,
  score INTEGER NOT NULL,
  relevance_score INTEGER NOT NULL,
  communication_score INTEGER NOT NULL,
  behavior_score INTEGER NOT NULL,
  coding_score INTEGER NOT NULL,
  date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  status TEXT DEFAULT 'completed',
  strengths TEXT[] DEFAULT '{}',
  improvements TEXT[] DEFAULT '{}',
  feedback TEXT[] DEFAULT '{}',
  recording_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS for interview_results
ALTER TABLE public.interview_results ENABLE ROW LEVEL SECURITY;

-- Create policies for interview_results
CREATE POLICY "Users can view their own interview results"
  ON public.interview_results
  FOR SELECT
  USING (auth.uid() = user_id);
  
CREATE POLICY "Users can insert their own interview results"
  ON public.interview_results
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);
  
CREATE POLICY "Users can update their own interview results"
  ON public.interview_results
  FOR UPDATE
  USING (auth.uid() = user_id);
  
CREATE POLICY "Users can delete their own interview results"
  ON public.interview_results
  FOR DELETE
  USING (auth.uid() = user_id);

-- Create scheduled_interviews table
CREATE TABLE IF NOT EXISTS public.scheduled_interviews (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  job_role TEXT NOT NULL,
  level TEXT NOT NULL,
  scheduled_date DATE NOT NULL,
  scheduled_time TEXT NOT NULL,
  status TEXT DEFAULT 'scheduled',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS for scheduled_interviews
ALTER TABLE public.scheduled_interviews ENABLE ROW LEVEL SECURITY;

-- Create policies for scheduled_interviews
CREATE POLICY "Users can view their own scheduled interviews"
  ON public.scheduled_interviews
  FOR SELECT
  USING (auth.uid() = user_id);
  
CREATE POLICY "Users can insert their own scheduled interviews"
  ON public.scheduled_interviews
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);
  
CREATE POLICY "Users can update their own scheduled interviews"
  ON public.scheduled_interviews
  FOR UPDATE
  USING (auth.uid() = user_id);
  
CREATE POLICY "Users can delete their own scheduled interviews"
  ON public.scheduled_interviews
  FOR DELETE
  USING (auth.uid() = user_id);
