"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useAuth } from "@/contexts/auth-context"
import Link from "next/link"
import { AlertCircle, Brain, Loader2, WifiOff } from "lucide-react"
import { useRouter, useSearchParams } from "next/navigation"
import NetworkStatus from "@/components/NetworkStatus"

export default function VerifyOtpPage() {
  const [otp, setOtp] = useState("")
  const [error, setError] = useState<string | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isOnline, setIsOnline] = useState(true)
  const [countdown, setCountdown] = useState(60)
  const [canResend, setCanResend] = useState(false)
  const { verifyOtp, signInWithPhone, user, isLoading } = useAuth()
  const router = useRouter()
  const searchParams = useSearchParams()
  const phone = searchParams.get("phone") || ""

  // Check online status
  useEffect(() => {
    const handleOnline = () => setIsOnline(true)
    const handleOffline = () => setIsOnline(false)

    // Set initial state
    setIsOnline(navigator.onLine)

    // Add event listeners
    window.addEventListener("online", handleOnline)
    window.addEventListener("offline", handleOffline)

    // Clean up
    return () => {
      window.removeEventListener("online", handleOnline)
      window.removeEventListener("offline", handleOffline)
    }
  }, [])

  // Countdown for resend
  useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000)
      return () => clearTimeout(timer)
    } else {
      setCanResend(true)
    }
  }, [countdown])

  // Redirect if already logged in
  useEffect(() => {
    if (user && !isLoading) {
      router.push("/")
    }
  }, [user, isLoading, router])

  // Redirect if no phone number
  useEffect(() => {
    if (!phone && !isLoading) {
      router.push("/login")
    }
  }, [phone, isLoading, router])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    setIsSubmitting(true)

    if (!isOnline) {
      setError("You are offline. Please check your internet connection and try again.")
      setIsSubmitting(false)
      return
    }

    if (!otp) {
      setError("Please enter the verification code")
      setIsSubmitting(false)
      return
    }

    try {
      const { error, success } = await verifyOtp(phone, otp)

      if (error) {
        if (error.message?.includes("Invalid one-time password")) {
          setError("Invalid verification code. Please try again.")
        } else if (
          error.message?.includes("Failed to fetch") ||
          error.message?.includes("Network error") ||
          error.message?.includes("Unable to connect")
        ) {
          setError(
            "Network error: Unable to connect to the authentication service. Please check your internet connection.",
          )
        } else {
          setError(error.message || "Failed to verify code")
        }
      } else if (success) {
        // Redirect is handled in the auth context
      }
    } catch (err: any) {
      console.error("OTP verification error:", err)

      if (err.message?.includes("Failed to fetch")) {
        setError(
          "Network error: Unable to connect to the authentication service. Please check your internet connection.",
        )
      } else {
        setError(err.message || "An unexpected error occurred")
      }
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleResend = async () => {
    if (!isOnline || isSubmitting) return

    try {
      setIsSubmitting(true)
      setError(null)

      const { error, success } = await signInWithPhone(phone)

      if (error) {
        setError(error.message || "Failed to resend verification code")
      } else if (success) {
        setCountdown(60)
        setCanResend(false)
      }
    } catch (err: any) {
      console.error("Resend OTP error:", err)
      setError(err.message || "An unexpected error occurred")
    } finally {
      setIsSubmitting(false)
    }
  }

  // Show loading state while checking auth
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-gray-900 to-gray-800 p-4">
        <div className="text-center">
          <Loader2 className="h-12 w-12 animate-spin text-purple-500 mx-auto mb-4" />
          <p className="text-white">Loading...</p>
        </div>
      </div>
    )
  }

  // Don't show verification page if already logged in
  if (user) {
    return null // Will redirect via useEffect
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-gray-900 to-gray-800 p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="relative">
              <div className="absolute -inset-1 rounded-full bg-gradient-to-r from-purple-600 to-blue-600 opacity-75 blur-sm"></div>
              <div className="relative bg-gray-900 rounded-full p-3">
                <Brain className="h-12 w-12 text-purple-400" />
              </div>
            </div>
          </div>
          <h1 className="text-3xl font-bold text-white">SmartHire AI</h1>
          <p className="text-gray-400 mt-2">Verify your phone number</p>
        </div>

        {!isOnline && (
          <div className="mb-6 bg-red-900/30 text-red-300 p-4 rounded-md flex items-center">
            <WifiOff className="h-5 w-5 mr-3 flex-shrink-0" />
            <div>
              <p className="font-medium">You are offline</p>
              <p className="text-sm">Please check your internet connection to verify your phone.</p>
            </div>
          </div>
        )}

        <Card className="border-gray-700 bg-gray-800/50 backdrop-blur-sm shadow-xl">
          <CardHeader>
            <CardTitle className="text-white">Verification Code</CardTitle>
            <CardDescription className="text-gray-400">Enter the verification code sent to {phone}</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="otp" className="text-white">
                  Verification Code
                </Label>
                <Input
                  id="otp"
                  type="text"
                  placeholder="123456"
                  value={otp}
                  onChange={(e) => setOtp(e.target.value)}
                  className="bg-gray-700 border-gray-600 text-white placeholder:text-gray-400 text-center text-xl tracking-widest"
                  disabled={isSubmitting || !isOnline}
                  maxLength={6}
                />
              </div>

              {error && (
                <div className="bg-red-900/30 text-red-300 p-3 rounded-md flex items-start">
                  <AlertCircle className="h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
                disabled={isSubmitting || !isOnline}
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Verifying...
                  </>
                ) : (
                  "Verify"
                )}
              </Button>

              <div className="text-center mt-4">
                {canResend ? (
                  <Button
                    type="button"
                    variant="link"
                    className="text-purple-400 hover:text-purple-300"
                    onClick={handleResend}
                    disabled={isSubmitting || !isOnline}
                  >
                    Resend verification code
                  </Button>
                ) : (
                  <p className="text-gray-400 text-sm">
                    Resend code in <span className="font-medium">{countdown}</span> seconds
                  </p>
                )}
              </div>
            </form>
          </CardContent>
          <CardFooter className="flex justify-center border-t border-gray-700 pt-4">
            <p className="text-gray-400 text-sm">
              <Link href="/login" className="text-purple-400 hover:text-purple-300 font-medium">
                Back to login
              </Link>
            </p>
          </CardFooter>
        </Card>
      </div>
      <NetworkStatus onStatusChange={setIsOnline} />
    </div>
  )
}
