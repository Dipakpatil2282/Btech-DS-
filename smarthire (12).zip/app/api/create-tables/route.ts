import { NextResponse } from "next/server"
import { supabase } from "@/lib/supabase"

export async function POST(request: Request) {
  try {
    // Create profiles table
    const profilesResult = await createProfilesTable()

    // Create interview results table
    const interviewsResult = await createInterviewResultsTable()

    // Create scheduled interviews table
    const scheduledResult = await createScheduledInterviewsTable()

    return NextResponse.json({
      success: true,
      profiles: profilesResult,
      interviewResults: interviewsResult,
      scheduledInterviews: scheduledResult,
    })
  } catch (error) {
    console.error("Error creating tables:", error)
    return NextResponse.json(
      { error: "Failed to create tables", details: error instanceof Error ? error.message : "Unknown error" },
      { status: 500 },
    )
  }
}

async function createProfilesTable() {
  try {
    // Check if table exists first
    const { error: checkError } = await supabase.from("profiles").select("*", { count: "exact", head: true })

    if (!checkError) {
      return { success: true, message: "Profiles table already exists" }
    }

    // Create the profiles table using REST API instead of raw SQL
    // First create the table
    const { error: createTableError } = await supabase.from("profiles").insert({
      user_id: "00000000-0000-0000-0000-000000000000", // Dummy UUID for initial creation
      name: "System",
      email: "system@example.com",
    })

    if (createTableError && !createTableError.message.includes("duplicate key")) {
      return { success: false, error: createTableError.message }
    }

    // Now set up RLS policies
    // Note: We can't directly create policies via the REST API
    // We'll need to use the Supabase dashboard for this or
    // use a migration script that runs on the server

    return { success: true }
  } catch (error) {
    console.error("Error creating profiles table:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    }
  }
}

async function createInterviewResultsTable() {
  try {
    // Check if table exists first
    const { error: checkError } = await supabase.from("interview_results").select("*", { count: "exact", head: true })

    if (!checkError) {
      return { success: true, message: "Interview results table already exists" }
    }

    // Create the interview_results table using REST API instead of raw SQL
    const { error: createTableError } = await supabase.from("interview_results").insert({
      user_id: "00000000-0000-0000-0000-000000000000", // Dummy UUID
      job_role: "System Test",
      level: "beginner",
      score: 0,
      relevance_score: 0,
      communication_score: 0,
      behavior_score: 0,
      coding_score: 0,
    })

    if (createTableError && !createTableError.message.includes("duplicate key")) {
      return { success: false, error: createTableError.message }
    }

    return { success: true }
  } catch (error) {
    console.error("Error creating interview results table:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    }
  }
}

async function createScheduledInterviewsTable() {
  try {
    // Check if table exists first
    const { error: checkError } = await supabase
      .from("scheduled_interviews")
      .select("*", { count: "exact", head: true })

    if (!checkError) {
      return { success: true, message: "Scheduled interviews table already exists" }
    }

    // Create the scheduled_interviews table using REST API instead of raw SQL
    const { error: createTableError } = await supabase.from("scheduled_interviews").insert({
      user_id: "00000000-0000-0000-0000-000000000000", // Dummy UUID
      email: "system@example.com",
      job_role: "System Test",
      level: "beginner",
      scheduled_date: new Date().toISOString().split("T")[0],
      scheduled_time: "12:00",
      status: "scheduled",
    })

    if (createTableError && !createTableError.message.includes("duplicate key")) {
      return { success: false, error: createTableError.message }
    }

    return { success: true }
  } catch (error) {
    console.error("Error creating scheduled interviews table:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    }
  }
}
