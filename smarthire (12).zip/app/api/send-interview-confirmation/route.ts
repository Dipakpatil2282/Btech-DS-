import { NextResponse } from "next/server"
import { supabase } from "@/lib/supabase"

export async function POST(request: Request) {
  try {
    const { email, date, time, name, jobRole, level, userId } = await request.json()

    if (!email || !date || !time) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Format date for display
    const formattedDate = new Date(date).toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    })

    // Create email content
    const emailContent = `
      <html>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
          <div style="background: linear-gradient(to right, #6d28d9, #4f46e5); padding: 20px; border-radius: 10px 10px 0 0;">
            <h1 style="color: white; margin: 0;">Interview Confirmation</h1>
          </div>
          <div style="border: 1px solid #e5e7eb; border-top: none; padding: 20px; border-radius: 0 0 10px 10px;">
            <p>Hello ${name},</p>
            <p>Your interview with SmartHire AI has been scheduled successfully!</p>
            <div style="background-color: #f3f4f6; padding: 15px; border-radius: 8px; margin: 20px 0;">
              <p style="margin: 0;"><strong>Date:</strong> ${formattedDate}</p>
              <p style="margin: 10px 0 0;"><strong>Time:</strong> ${time}</p>
              <p style="margin: 10px 0 0;"><strong>Job Role:</strong> ${jobRole}</p>
              <p style="margin: 10px 0 0;"><strong>Level:</strong> ${level}</p>
            </div>
            <p>Please make sure to be prepared and join the interview on time. Our AI interviewer will be ready to assess your skills and provide valuable feedback.</p>
            <p>If you need to reschedule or cancel your interview, please log in to your account and update your interview settings.</p>
            <p>Best regards,<br>The SmartHire AI Team</p>
          </div>
        </body>
      </html>
    `

    // Store the interview in the database
    const { data: interviewData, error: interviewError } = await supabase
      .from("scheduled_interviews")
      .insert({
        user_id: userId,
        email,
        job_role: jobRole,
        level,
        scheduled_date: date,
        scheduled_time: time,
        status: "scheduled",
      })
      .select()

    if (interviewError) {
      console.error("Error storing interview:", interviewError)
      return NextResponse.json({ error: "Failed to store interview" }, { status: 500 })
    }

    // In a real implementation, you would send an email here
    // For now, we'll just log it
    console.log("Email would be sent to:", email)
    console.log("Email content:", emailContent)

    return NextResponse.json({
      success: true,
      message: "Interview scheduled successfully",
      interviewId: interviewData?.[0]?.id,
    })
  } catch (error) {
    console.error("Error processing request:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
