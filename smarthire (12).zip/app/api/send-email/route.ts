import { NextResponse } from "next/server"
import { supabase } from "@/lib/supabase"

export async function POST(request: Request) {
  try {
    const { email, jobRole, level, date, time, userId, name } = await request.json()

    console.log("Received email request:", { email, jobRole, level, date, time, userId })

    // Store the interview in the database
    const { data: interviewData, error: interviewError } = await supabase
      .from("scheduled_interviews")
      .insert({
        user_id: userId,
        email,
        job_role: jobRole,
        level,
        scheduled_date: date,
        scheduled_time: time,
        status: "scheduled",
      })
      .select()

    if (interviewError) {
      console.error("Error storing interview:", interviewError)
      return NextResponse.json({ error: "Failed to store interview" }, { status: 500 })
    }

    // Format the email content
    const formattedDate = new Date(date).toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    })

    const emailContent = `
      <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(to right, #8b5cf6, #6366f1); padding: 20px; color: white; border-radius: 5px 5px 0 0; }
            .content { padding: 20px; border: 1px solid #ddd; border-top: none; border-radius: 0 0 5px 5px; }
            .footer { margin-top: 20px; font-size: 12px; color: #666; }
            .button { display: inline-block; background: linear-gradient(to right, #8b5cf6, #6366f1); color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>SmartHire AI Interview Confirmation</h1>
            </div>
            <div class="content">
              <p>Hello ${name || "there"},</p>
              <p>Your interview has been scheduled successfully!</p>
              <h2>Interview Details:</h2>
              <p><strong>Job Role:</strong> ${jobRole}</p>
              <p><strong>Level:</strong> ${level}</p>
              <p><strong>Date:</strong> ${formattedDate}</p>
              <p><strong>Time:</strong> ${time}</p>
              <p>Please be prepared and join the interview on time. Make sure you have a stable internet connection and a quiet environment.</p>
              <p>Good luck!</p>
              <a href="https://smarthire-ai.vercel.app" class="button">Go to SmartHire</a>
            </div>
            <div class="footer">
              <p>This is an automated message from SmartHire AI. Please do not reply to this email.</p>
            </div>
          </div>
        </body>
      </html>
    `

    // In a production environment, you would use a real email service
    // For now, we'll just log the email content and return success
    console.log("Email would be sent to:", email)
    console.log("Email content:", emailContent)

    // Uncomment this section and configure with your email provider when ready to send real emails
    /*
    // Create a transporter using your email service credentials
    const transporter = nodemailer.createTransport({
      host: process.env.EMAIL_HOST,
      port: parseInt(process.env.EMAIL_PORT || '587'),
      secure: process.env.EMAIL_SECURE === 'true',
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASSWORD,
      },
    });

    // Send the email
    await transporter.sendMail({
      from: `"SmartHire AI" <${process.env.EMAIL_FROM}>`,
      to: email,
      subject: "Your SmartHire AI Interview Confirmation",
      html: emailContent,
    });
    */

    return NextResponse.json({
      success: true,
      message: "Interview scheduled and email sent successfully",
      interviewId: interviewData?.[0]?.id,
    })
  } catch (error) {
    console.error("Error processing request:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
