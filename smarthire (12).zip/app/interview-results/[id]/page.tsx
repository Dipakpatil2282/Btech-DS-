"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { supabase } from "@/lib/supabase"
import { useAuth } from "@/contexts/auth-context"
import { ArrowLeft, Award, BarChart2, Brain, CheckCircle2, XCircle } from "lucide-react"
import { Progress } from "@/components/ui/progress"
import Link from "next/link"
import { useRouter } from "next/navigation"

interface InterviewResult {
  id: number
  user_id: string
  job_role: string
  level: string
  score: number
  relevance_score: number
  communication_score: number
  behavior_score: number
  coding_score: number
  date: string
  status: string
  strengths: string[]
  improvements: string[]
  feedback: string[]
}

export default function InterviewResultPage({ params }: { params: { id: string } }) {
  const { user } = useAuth()
  const [result, setResult] = useState<InterviewResult | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()

  useEffect(() => {
    const fetchInterviewResult = async () => {
      if (!user) {
        router.push("/login")
        return
      }

      try {
        const { data, error } = await supabase
          .from("interview_results")
          .select("*")
          .eq("id", params.id)
          .eq("user_id", user.id)
          .single()

        if (error) {
          throw error
        }

        setResult(data)
      } catch (err: any) {
        console.error("Error fetching interview result:", err)
        setError(err.message)
      } finally {
        setIsLoading(false)
      }
    }

    fetchInterviewResult()
  }, [user, params.id, router])

  const getScoreColor = (score: number) => {
    if (score >= 8) return "text-emerald-500"
    if (score >= 5) return "text-amber-500"
    return "text-rose-500"
  }

  const getScoreProgressColor = (score: number) => {
    if (score >= 8) return "bg-emerald-500"
    if (score >= 5) return "bg-amber-500"
    return "bg-rose-500"
  }

  const getLevelBadgeColor = (level: string) => {
    if (level === "beginner") return "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-400"
    if (level === "intermediate") return "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400"
    return "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400"
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-gray-900 to-gray-800 p-4">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-violet-500"></div>
      </div>
    )
  }

  if (error || !result) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-gray-900 to-gray-800 p-4">
        <div className="max-w-4xl mx-auto pt-12">
          <Card className="border-gray-700 bg-gray-800/50 backdrop-blur-sm shadow-xl">
            <CardHeader>
              <CardTitle className="text-white">Interview Result</CardTitle>
              <CardDescription className="text-gray-400">Error loading interview result</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="bg-rose-900/30 text-rose-300 p-4 rounded-md">
                <p>Error: {error || "Interview result not found"}</p>
                <Link href="/">
                  <Button className="mt-4 gradient-bg">Return to Dashboard</Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-gray-800 p-4">
      <div className="max-w-4xl mx-auto pt-12">
        <Link href="/" className="inline-flex items-center text-gray-400 hover:text-white mb-6">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Dashboard
        </Link>

        <div className="p-8 bg-gradient-to-r from-violet-600 to-indigo-700 text-white rounded-t-xl shadow-xl">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-4xl font-bold mb-2">Performance Analysis</h2>
              <div className="flex items-center">
                <p className="text-lg mr-2">Job Role: {result.job_role}</p>
                <span className={`px-3 py-1 rounded-full text-xs font-semibold ${getLevelBadgeColor(result.level)}`}>
                  {result.level.charAt(0).toUpperCase() + result.level.slice(1)}
                </span>
              </div>
            </div>
            <div className="hidden md:block">
              <Award className="h-16 w-16 text-yellow-300 opacity-80" />
            </div>
          </div>
        </div>

        <Card className="border-t-0 rounded-t-none border-gray-700 bg-gray-800/50 backdrop-blur-sm shadow-xl">
          <CardContent className="p-8">
            <div className="mb-10 text-center">
              <div className="relative inline-block">
                <div className="w-40 h-40 rounded-full bg-gray-100 flex items-center justify-center mx-auto mb-4 relative overflow-hidden">
                  <div
                    className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-emerald-500 to-blue-500 transition-all duration-1000 ease-out"
                    style={{ height: `${result.score * 10}%`, opacity: 0.7 }}
                  ></div>
                  <div className="relative z-10 flex flex-col items-center">
                    <div className={`text-6xl font-bold ${getScoreColor(result.score)}`}>{result.score}</div>
                    <div className="text-xl text-gray-600">/10</div>
                  </div>
                </div>
                <h3 className="text-2xl font-bold mb-2 text-white">Overall Score</h3>
                <p className="text-gray-500">Based on your interview performance</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10">
              <div className="bg-white p-6 rounded-xl shadow-md border border-gray-100 hover:shadow-lg transition-shadow">
                <div className="flex items-center mb-4">
                  <div className="p-3 rounded-full bg-purple-100 mr-4">
                    <Brain className="h-6 w-6 text-purple-600" />
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold">Technical Relevance</h4>
                    <p className="text-sm text-gray-500">How well you addressed technical questions</p>
                  </div>
                </div>
                <div className="flex items-center mb-3">
                  <span className={`text-3xl font-bold ${getScoreColor(result.relevance_score)}`}>
                    {result.relevance_score}
                  </span>
                  <span className="text-gray-400 ml-1">/10</span>
                </div>
                <Progress
                  value={result.relevance_score * 10}
                  className="h-2 bg-gray-100"
                  indicatorClassName={getScoreProgressColor(result.relevance_score)}
                />
              </div>

              <div className="bg-white p-6 rounded-xl shadow-md border border-gray-100 hover:shadow-lg transition-shadow">
                <div className="flex items-center mb-4">
                  <div className="p-3 rounded-full bg-blue-100 mr-4">
                    <BarChart2 className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold">Communication</h4>
                    <p className="text-sm text-gray-500">Clarity and structure of your responses</p>
                  </div>
                </div>
                <div className="flex items-center mb-3">
                  <span className={`text-3xl font-bold ${getScoreColor(result.communication_score)}`}>
                    {result.communication_score}
                  </span>
                  <span className="text-gray-400 ml-1">/10</span>
                </div>
                <Progress
                  value={result.communication_score * 10}
                  className="h-2 bg-gray-100"
                  indicatorClassName={getScoreProgressColor(result.communication_score)}
                />
              </div>
            </div>

            <div className="mb-10 bg-white p-6 rounded-xl shadow-md border border-gray-100">
              <h3 className="text-xl font-bold mb-4 text-gray-800">Feedback Summary</h3>
              <div className="space-y-3">
                {result.feedback.map((point, index) => (
                  <div key={index} className="flex items-start p-3 bg-blue-50 rounded-lg">
                    <Brain className="mr-3 text-blue-500 mt-1 flex-shrink-0 h-5 w-5" />
                    <p className="text-gray-700">{point}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10">
              <div className="bg-white p-6 rounded-xl shadow-md border border-gray-100">
                <h3 className="text-xl font-bold mb-4 text-green-600 flex items-center">
                  <CheckCircle2 className="mr-2 h-5 w-5" />
                  Strengths
                </h3>
                <div className="space-y-3">
                  {result.strengths.length > 0 ? (
                    result.strengths.map((strength, index) => (
                      <div key={index} className="flex items-start p-3 bg-green-50 rounded-lg">
                        <CheckCircle2 className="mr-3 text-green-500 mt-1 flex-shrink-0 h-5 w-5" />
                        <p className="text-gray-700">{strength}</p>
                      </div>
                    ))
                  ) : (
                    <p className="text-gray-500 italic">No specific strengths identified.</p>
                  )}
                </div>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-md border border-gray-100">
                <h3 className="text-xl font-bold mb-4 text-amber-600 flex items-center">
                  <XCircle className="mr-2 h-5 w-5" />
                  Areas for Improvement
                </h3>
                <div className="space-y-3">
                  {result.improvements.length > 0 ? (
                    result.improvements.map((improvement, index) => (
                      <div key={index} className="flex items-start p-3 bg-amber-50 rounded-lg">
                        <XCircle className="mr-3 text-amber-500 mt-1 flex-shrink-0 h-5 w-5" />
                        <p className="text-gray-700">{improvement}</p>
                      </div>
                    ))
                  ) : (
                    <p className="text-gray-500 italic">No specific areas for improvement identified.</p>
                  )}
                </div>
              </div>
            </div>

            <div className="text-center">
              <Link href="/">
                <Button className="gradient-bg px-10 py-3 rounded-full text-lg font-semibold shadow-lg hover:shadow-xl transition-all">
                  Return to Dashboard
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
