"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Brain, Mic, AlertTriangle, Clock, Copy, ExternalLink } from "lucide-react"
import { useRouter } from "next/navigation"

export default function InstructionsPage() {
  const [agreed, setAgreed] = useState(false)
  const router = useRouter()

  const handleContinue = () => {
    try {
      // Store in localStorage that the user has seen the instructions
      localStorage.setItem("instructionsViewed", "true")
      router.push("/")
    } catch (error) {
      console.error("Error setting localStorage:", error)
      // Fallback - still redirect even if localStorage fails
      router.push("/")
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 via-gray-800 to-gray-900 text-white py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="relative">
              <div className="absolute -inset-1 rounded-full bg-gradient-to-r from-violet-600 to-indigo-600 opacity-75 blur-sm"></div>
              <div className="relative bg-gray-900 rounded-full p-3">
                <Brain className="h-12 w-12 text-violet-400" />
              </div>
            </div>
          </div>
          <h1 className="text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-violet-400 via-pink-500 to-indigo-400">
            SmartHire AI
          </h1>
          <p className="text-xl text-gray-300 mt-2">Interview Instructions</p>
        </div>

        <Card className="border-gray-700 bg-gray-800/50 backdrop-blur-sm shadow-xl mb-8">
          <CardHeader>
            <CardTitle className="text-white text-2xl">Before You Begin</CardTitle>
            <CardDescription className="text-gray-400">
              Please read these instructions carefully before starting your interview
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4">
              <h3 className="text-xl font-semibold text-white flex items-center">
                <Clock className="mr-2 h-5 w-5 text-violet-400" />
                Interview Process
              </h3>
              <div className="pl-7 space-y-2 text-gray-300">
                <p>• The interview consists of multiple questions related to your selected job role and level.</p>
                <p>• You'll have 20 minutes to complete the entire interview.</p>
                <p>• Each question should be answered thoroughly to demonstrate your knowledge and skills.</p>
                <p>• After completing all questions, you'll receive a detailed performance analysis.</p>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-semibold text-white flex items-center">
                <Mic className="mr-2 h-5 w-5 text-violet-400" />
                Recording Your Answers
              </h3>
              <div className="pl-7 space-y-2 text-gray-300">
                <p>• You can answer questions by typing or using speech recognition.</p>
                <p>• Click the "Start Recording" button to use speech-to-text for your answers.</p>
                <p>• The system will automatically start recording after reading each question.</p>
                <p>• Click "Stop Recording" when you've finished your answer.</p>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-semibold text-white flex items-center">
                <AlertTriangle className="mr-2 h-5 w-5 text-amber-400" />
                Important Rules
              </h3>
              <div className="pl-7 space-y-2 text-gray-300">
                <p className="font-medium text-amber-300">
                  • Tab switching is limited to 3 times during the interview.
                </p>
                <p>• After 3 tab switches, your interview will be automatically submitted.</p>
                <p>• Copy and paste functionality is disabled in the answer box.</p>
                <p>• Taking screenshots is not allowed and may result in automatic submission.</p>
                <p>• Your camera will be active during the interview to simulate a real interview environment.</p>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-semibold text-white flex items-center">
                <Copy className="mr-2 h-5 w-5 text-violet-400" />
                Coding Questions
              </h3>
              <div className="pl-7 space-y-2 text-gray-300">
                <p>• For coding questions, a code editor will be provided.</p>
                <p>• You can write and test your code directly in the editor.</p>
                <p>• Multiple programming languages are supported.</p>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-semibold text-white flex items-center">
                <ExternalLink className="mr-2 h-5 w-5 text-rose-400" />
                Exiting the Interview
              </h3>
              <div className="pl-7 space-y-2 text-gray-300">
                <p>• You can exit the interview at any time by clicking the "Abort Interview" button.</p>
                <p>• Aborting the interview will discard all your answers and no results will be saved.</p>
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex flex-col space-y-4">
            <div className="flex items-start space-x-2">
              <div className="flex h-5 items-center" onClick={() => setAgreed(!agreed)}>
                <input
                  id="agree"
                  type="checkbox"
                  checked={agreed}
                  onChange={() => setAgreed(!agreed)}
                  className="h-4 w-4 rounded border-gray-300 text-violet-600 focus:ring-violet-600"
                />
              </div>
              <label htmlFor="agree" className="text-sm text-gray-300 cursor-pointer">
                I have read and understood the instructions and rules for the SmartHire AI interview process.
              </label>
            </div>
            <Button
              onClick={handleContinue}
              disabled={!agreed}
              className="w-full bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 text-white py-2 px-4 rounded-md shadow-lg hover:shadow-violet-500/20 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Continue to Interview
            </Button>
          </CardFooter>
        </Card>

        <div className="text-center">
          <p className="text-gray-400 text-sm">
            Need help? Contact our support team at{" "}
            <a href="mailto:support@smarthire.ai" className="text-violet-400 hover:text-violet-300">
              support@smarthire.ai
            </a>
          </p>
        </div>
      </div>
    </div>
  )
}
