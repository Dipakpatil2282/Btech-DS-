"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { supabase } from "@/lib/supabase"
import { useAuth } from "@/contexts/auth-context"
import { AlertCircle, User, Save } from "lucide-react"
import { useRouter } from "next/navigation"
import ScheduleInterview from "@/components/ScheduleInterview"

export default function ProfilePage() {
  const { user } = useAuth()
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)
  const router = useRouter()

  useEffect(() => {
    if (!user) {
      router.push("/login")
      return
    }

    const fetchProfile = async () => {
      try {
        const { data, error } = await supabase.from("profiles").select("*").eq("user_id", user.id).single()

        if (error) {
          console.error("Error fetching profile:", error)
          return
        }

        if (data) {
          setName(data.name || "")
          setEmail(data.email || user.email || "")
        }
      } catch (err) {
        console.error("Error fetching profile:", err)
      } finally {
        setIsLoading(false)
      }
    }

    fetchProfile()
  }, [user, router])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    setSuccess(false)
    setIsSaving(true)

    if (!name) {
      setError("Name is required")
      setIsSaving(false)
      return
    }

    try {
      // Check if profile exists
      const { data: existingProfile } = await supabase.from("profiles").select("id").eq("user_id", user?.id).single()

      let result

      if (existingProfile) {
        // Update existing profile
        result = await supabase
          .from("profiles")
          .update({
            name,
            email,
            updated_at: new Date().toISOString(),
          })
          .eq("user_id", user?.id)
      } else {
        // Insert new profile
        result = await supabase.from("profiles").insert({
          user_id: user?.id,
          name,
          email,
        })
      }

      if (result.error) {
        setError(result.error.message)
      } else {
        setSuccess(true)
        setTimeout(() => setSuccess(false), 3000)
      }
    } catch (err: any) {
      setError(err.message)
    } finally {
      setIsSaving(false)
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-gray-900 to-gray-800 p-4">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-purple-500"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-gray-800 p-4">
      <div className="max-w-4xl mx-auto pt-12">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white">Your Profile</h1>
          <p className="text-gray-400 mt-2">Manage your account information</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2">
            <Card className="border-gray-700 bg-gray-800/50 backdrop-blur-sm shadow-xl">
              <CardHeader>
                <CardTitle className="text-white">Personal Information</CardTitle>
                <CardDescription className="text-gray-400">Update your personal details</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name" className="text-white">
                      Full Name
                    </Label>
                    <Input
                      id="name"
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="bg-gray-700 border-gray-600 text-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-white">
                      Email
                    </Label>
                    <Input
                      id="email"
                      type="email"
                      value={email}
                      disabled
                      className="bg-gray-700 border-gray-600 text-white opacity-70"
                    />
                    <p className="text-xs text-gray-400">Email cannot be changed</p>
                  </div>

                  {error && (
                    <div className="bg-red-900/30 text-red-300 p-3 rounded-md flex items-start">
                      <AlertCircle className="h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
                      <span>{error}</span>
                    </div>
                  )}

                  {success && (
                    <div className="bg-green-900/30 text-green-300 p-3 rounded-md flex items-start">
                      <svg className="h-5 w-5 mr-2 mt-0.5 flex-shrink-0" viewBox="0 0 20 20" fill="currentColor">
                        <path
                          fillRule="evenodd"
                          d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                          clipRule="evenodd"
                        />
                      </svg>
                      <span>Profile updated successfully!</span>
                    </div>
                  )}

                  <Button
                    type="submit"
                    className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
                    disabled={isSaving}
                  >
                    {isSaving ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-white mr-2"></div>
                        Saving...
                      </>
                    ) : (
                      <>
                        <Save className="h-4 w-4 mr-2" />
                        Save Changes
                      </>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>

          <div>
            <Card className="border-gray-700 bg-gray-800/50 backdrop-blur-sm shadow-xl">
              <CardHeader>
                <CardTitle className="text-white">Account</CardTitle>
                <CardDescription className="text-gray-400">Your account information</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col items-center">
                  <div className="bg-gray-700 rounded-full p-6 mb-4">
                    <User className="h-12 w-12 text-gray-300" />
                  </div>
                  <h3 className="text-lg font-medium text-white">{name || "User"}</h3>
                  <p className="text-gray-400">{email}</p>
                </div>
              </CardContent>
              <CardFooter>
                <Button onClick={() => router.push("/")} className="w-full bg-gray-700 hover:bg-gray-600 text-white">
                  Back to Dashboard
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>

        <div className="mt-6">
          <Card className="border-gray-700 bg-gray-800/50 backdrop-blur-sm shadow-xl">
            <CardHeader>
              <CardTitle className="text-white">Schedule an Interview</CardTitle>
              <CardDescription className="text-gray-400">Book a live interview session with our AI</CardDescription>
            </CardHeader>
            <CardContent>
              <ScheduleInterview />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
