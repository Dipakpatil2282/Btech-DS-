import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

export async function GET(request: NextRequest) {
  const requestUrl = new URL(request.url)
  const code = requestUrl.searchParams.get("code")

  if (code) {
    const cookieStore = cookies()
    const supabase = createRouteHandlerClient({ cookies: () => cookieStore })

    // Exchange the code for a session
    await supabase.auth.exchangeCodeForSession(code)

    // After successful authentication, check if we need to create a profile
    // for users signing up with Google for the first time
    const {
      data: { session },
    } = await supabase.auth.getSession()

    if (session?.user) {
      // Check if profile exists
      const { data: profile } = await supabase.from("profiles").select("*").eq("user_id", session.user.id).single()

      // If no profile exists, create one
      if (!profile) {
        const userData = session.user.user_metadata || {}
        const name = userData.full_name || userData.name || "User"
        const email = session.user.email || ""

        await supabase.from("profiles").insert({
          user_id: session.user.id,
          name,
          email,
        })
      }
    }
  }

  // URL to redirect to after sign in process completes
  return NextResponse.redirect(new URL("/", request.url))
}
