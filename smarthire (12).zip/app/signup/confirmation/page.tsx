"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Brain, Mail } from "lucide-react"
import Link from "next/link"

export default function ConfirmationPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-gray-900 to-gray-800 p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="relative">
              <div className="absolute -inset-1 rounded-full bg-gradient-to-r from-purple-600 to-blue-600 opacity-75 blur-sm"></div>
              <div className="relative bg-gray-900 rounded-full p-3">
                <Brain className="h-12 w-12 text-purple-400" />
              </div>
            </div>
          </div>
          <h1 className="text-3xl font-bold text-white">SmartHire AI</h1>
          <p className="text-gray-400 mt-2">Email Confirmation</p>
        </div>

        <Card className="border-gray-700 bg-gray-800/50 backdrop-blur-sm shadow-xl">
          <CardHeader>
            <div className="flex justify-center mb-4">
              <div className="bg-blue-900/30 p-3 rounded-full">
                <Mail className="h-12 w-12 text-blue-400" />
              </div>
            </div>
            <CardTitle className="text-white text-center">Check Your Email</CardTitle>
            <CardDescription className="text-gray-400 text-center">
              We've sent a confirmation link to your email address. Please check your inbox and click the link to verify
              your account.
            </CardDescription>
          </CardHeader>
          <CardContent className="text-center">
            <p className="text-gray-300 mb-4">Once verified, you'll be able to sign in to your account.</p>
          </CardContent>
          <CardFooter className="flex justify-center">
            <Link href="/login">
              <Button className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700">
                Return to Login
              </Button>
            </Link>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
