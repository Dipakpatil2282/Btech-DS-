"use client"

import { useEffect, useState } from "react"
import HomeClient from "./home-client"
import { useRouter } from "next/navigation"

export default function Home() {
  const [hasViewedInstructions, setHasViewedInstructions] = useState<boolean | null>(null)
  const router = useRouter()

  useEffect(() => {
    // Check if the user has viewed the instructions
    try {
      const instructionsViewed = localStorage.getItem("instructionsViewed") === "true"
      setHasViewedInstructions(instructionsViewed)

      // Redirect if instructions haven't been viewed
      if (!instructionsViewed) {
        router.push("/instructions")
      }
    } catch (e) {
      console.error("Error accessing localStorage:", e)
      // Default to true if localStorage fails
      setHasViewedInstructions(true)
    }
  }, [router]) // Only depend on router

  // Don't render anything until we've checked localStorage
  if (hasViewedInstructions === null) {
    return null
  }

  // Only render HomeClient if instructions have been viewed
  if (hasViewedInstructions === false) {
    return null // Will redirect to instructions
  }

  return <HomeClient />
}
