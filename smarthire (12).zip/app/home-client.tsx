"use client"

import type React from "react"
import Link from "next/link"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import InterviewSession from "@/components/InterviewSession"
import { useState, useEffect } from "react"
import {
  Monitor,
  Brain,
  Code,
  Coffee,
  PiIcon as Python,
  Server,
  BarChartIcon as ChartBar,
  Cloud,
  SmartphoneIcon as Mobile,
  Palette,
  ChevronLeft,
  Sparkles,
  LogOut,
  User,
  History,
} from "lucide-react"
import { useAuth } from "@/contexts/auth-context"
import PastInterviews from "@/components/PastInterviews"
import { ThemeToggle } from "@/components/theme-toggle"

interface JobRole {
  id: string
  title: string
  description: string
  icon: React.ComponentType
  color: string
}

const jobRolesList: JobRole[] = [
  {
    id: "Frontend Developer",
    title: "Frontend Developer",
    description: "Technical interview for Frontend Developer position",
    icon: Monitor,
    color: "from-blue-400 to-indigo-500",
  },
  {
    id: "Backend Developer",
    title: "Backend Developer",
    description: "Technical interview for Backend Developer position",
    icon: Server,
    color: "from-green-400 to-teal-500",
  },
  {
    id: "Full Stack Developer",
    title: "Full Stack Developer",
    description: "Technical interview for Full Stack Developer position",
    icon: Code,
    color: "from-purple-400 to-indigo-500",
  },
  {
    id: "Java Developer",
    title: "Java Developer",
    description: "Technical interview for Java Developer position",
    icon: Coffee,
    color: "from-red-400 to-pink-500",
  },
  {
    id: "Python Developer",
    title: "Python Developer",
    description: "Technical interview for Python Developer position",
    icon: Python,
    color: "from-blue-400 to-cyan-500",
  },
  {
    id: "JavaScript Developer",
    title: "JavaScript Developer",
    description: "Technical interview for JavaScript Developer position",
    icon: Code,
    color: "from-yellow-400 to-amber-500",
  },
  {
    id: "React Developer",
    title: "React Developer",
    description: "Technical interview for React Developer position",
    icon: Code,
    color: "from-cyan-400 to-blue-500",
  },
  {
    id: "Node.js Developer",
    title: "Node.js Developer",
    description: "Technical interview for Node.js Developer position",
    icon: Server,
    color: "from-green-400 to-emerald-500",
  },
  {
    id: "Data Analyst",
    title: "Data Analyst",
    description: "Technical interview for Data Analyst position",
    icon: ChartBar,
    color: "from-blue-400 to-violet-500",
  },
  {
    id: "Data Scientist",
    title: "Data Scientist",
    description: "Technical interview for Data Scientist position",
    icon: Brain,
    color: "from-indigo-400 to-purple-500",
  },
  {
    id: "Machine Learning Engineer",
    title: "Machine Learning Engineer",
    description: "Technical interview for Machine Learning Engineer position",
    icon: Brain,
    color: "from-purple-400 to-pink-500",
  },
  {
    id: "DevOps Engineer",
    title: "DevOps Engineer",
    description: "Technical interview for DevOps Engineer position",
    icon: Cloud,
    color: "from-blue-400 to-indigo-500",
  },
  {
    id: "Cloud Engineer",
    title: "Cloud Engineer",
    description: "Technical interview for Cloud Engineer position",
    icon: Cloud,
    color: "from-cyan-400 to-blue-500",
  },
  {
    id: "Mobile App Developer",
    title: "Mobile App Developer",
    description: "Technical interview for Mobile App Developer position",
    icon: Mobile,
    color: "from-orange-400 to-red-500",
  },
  {
    id: "UI/UX Designer",
    title: "UI/UX Designer",
    description: "Technical interview for UI/UX Designer position",
    icon: Palette,
    color: "from-pink-400 to-rose-500",
  },
]

export default function HomeClient() {
  const { user, signOut } = useAuth()
  const [selectedJobRole, setSelectedJobRole] = useState<string | null>(null)
  const [selectedLevel, setSelectedLevel] = useState<"beginner" | "intermediate" | "advanced" | null>(null)
  const [isStarted, setIsStarted] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [filteredRoles, setFilteredRoles] = useState(jobRolesList)
  const [isLoading, setIsLoading] = useState(true)
  const [showPastInterviews, setShowPastInterviews] = useState(false)

  // Simulate loading state
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 1000)
    return () => clearTimeout(timer)
  }, [])

  // Filter job roles based on search term
  useEffect(() => {
    // Only update filtered roles if the search term has changed
    const filtered =
      searchTerm.trim() === ""
        ? jobRolesList
        : jobRolesList.filter(
            (role) =>
              role.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
              role.description.toLowerCase().includes(searchTerm.toLowerCase()),
          )

    setFilteredRoles(filtered)
  }, [searchTerm])

  const handleStartInterview = (jobRole: string) => {
    setSelectedJobRole(jobRole)
  }

  const handleSelectLevel = (level: "beginner" | "intermediate" | "advanced") => {
    setSelectedLevel(level)
    setIsStarted(true)
  }

  const handleAbortInterview = () => {
    setSelectedJobRole(null)
    setSelectedLevel(null)
    setIsStarted(false)
  }

  if (isStarted && selectedJobRole && selectedLevel) {
    return <InterviewSession jobRole={selectedJobRole} level={selectedLevel} onAbort={handleAbortInterview} />
  }

  return (
    <main className="min-h-screen bg-background text-foreground py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {isLoading ? (
          <div className="flex flex-col items-center justify-center min-h-[80vh]">
            <div className="relative w-24 h-24 mb-8">
              <div className="absolute top-0 left-0 w-full h-full border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
              <div className="absolute top-2 left-2 w-20 h-20 border-4 border-primary/70 border-t-transparent rounded-full animate-spin-slow"></div>
              <Brain className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 h-10 w-10 text-primary" />
            </div>
            <h2 className="text-2xl font-bold text-foreground mb-2">Loading SmartHire</h2>
            <p className="text-muted-foreground">Preparing your AI interview experience...</p>
          </div>
        ) : (
          <>
            <div className="flex justify-between items-center mb-8">
              <div className="flex items-center">
                <div className="relative mr-3">
                  <div className="absolute -inset-1 rounded-full bg-gradient-to-r from-primary to-primary/70 opacity-75 blur-sm"></div>
                  <div className="relative bg-background rounded-full p-2">
                    <Brain className="h-8 w-8 text-primary" />
                  </div>
                </div>
                <h1 className="text-2xl font-bold gradient-text">SmartHire AI</h1>
              </div>

              <div className="flex items-center space-x-4">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowPastInterviews(!showPastInterviews)}
                  className={`border-border text-foreground hover:bg-accent ${showPastInterviews ? "bg-primary/20 text-primary border-primary/70" : ""}`}
                >
                  <History className="h-4 w-4 mr-2" />
                  {showPastInterviews ? "Hide History" : "Past Interviews"}
                </Button>

                <ThemeToggle />

                <div className="hidden md:flex items-center bg-accent/50 rounded-full px-4 py-2">
                  <User className="h-4 w-4 text-muted-foreground mr-2" />
                  <span className="text-foreground">{user?.email}</span>
                </div>
                <Link href="/profile">
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-border text-foreground hover:bg-accent hover:shadow-lg transition-all duration-300"
                  >
                    <User className="h-4 w-4 mr-2" />
                    Profile
                  </Button>
                </Link>
                <Button
                  onClick={() => signOut()}
                  variant="outline"
                  size="sm"
                  className="border-border text-foreground hover:bg-accent hover:shadow-lg transition-all duration-300"
                >
                  <LogOut className="h-4 w-4 mr-2" />
                  Sign Out
                </Button>
              </div>
            </div>

            {showPastInterviews ? (
              <div className="animate-fade-in">
                <PastInterviews />
              </div>
            ) : (
              <div className="text-center mb-12 animate-fade-in">
                <h1 className="text-4xl sm:text-6xl font-bold mb-4 gradient-text">SmartHire AI</h1>
                <p className="text-xl text-foreground/80 max-w-2xl mx-auto">
                  Experience the future of technical interviews with our AI-powered platform. Practice, learn, and
                  improve your skills.
                </p>

                {selectedJobRole && !isStarted ? (
                  <div className="mt-8 max-w-md mx-auto">
                    <div className="bg-card/50 backdrop-blur-sm p-8 rounded-2xl shadow-xl border border-border gradient-border">
                      <Button
                        onClick={() => setSelectedJobRole(null)}
                        variant="ghost"
                        className="mb-4 text-muted-foreground hover:text-foreground flex items-center"
                      >
                        <ChevronLeft className="mr-1 h-4 w-4" />
                        Back to Job Roles
                      </Button>

                      <h2 className="text-2xl font-bold mb-2">{selectedJobRole}</h2>
                      <p className="text-muted-foreground mb-6">Select your experience level to begin the interview</p>

                      <div className="grid gap-4">
                        <Button
                          onClick={() => handleSelectLevel("beginner")}
                          className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white p-4 h-auto shadow-lg hover:shadow-emerald-500/20 transition-all duration-300"
                        >
                          <div className="flex flex-col items-center">
                            <span className="text-lg font-bold">Beginner</span>
                            <span className="text-xs mt-1 opacity-80">Entry-level questions</span>
                          </div>
                        </Button>
                        <Button
                          onClick={() => handleSelectLevel("intermediate")}
                          className="bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white p-4 h-auto shadow-lg hover:shadow-blue-500/20 transition-all duration-300"
                        >
                          <div className="flex flex-col items-center">
                            <span className="text-lg font-bold">Intermediate</span>
                            <span className="text-xs mt-1 opacity-80">Mid-level questions</span>
                          </div>
                        </Button>
                        <Button
                          onClick={() => handleSelectLevel("advanced")}
                          className="bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700 text-white p-4 h-auto shadow-lg hover:shadow-violet-500/20 transition-all duration-300"
                        >
                          <div className="flex flex-col items-center">
                            <span className="text-lg font-bold">Advanced</span>
                            <span className="text-xs mt-1 opacity-80">Senior-level questions</span>
                          </div>
                        </Button>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="mt-8">
                    <div className="max-w-md mx-auto mb-8">
                      <div className="relative">
                        <input
                          type="text"
                          placeholder="Search for a role..."
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                          className="w-full px-4 py-3 bg-card/50 border border-border rounded-full text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent shadow-lg transition-all duration-300"
                        />
                        <div className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground">
                          <Sparkles className="h-5 w-5" />
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                      {filteredRoles.map((role) => {
                        const Icon = role.icon
                        return (
                          <Card
                            key={role.id}
                            className="bg-card/50 backdrop-blur-sm border-border hover:border-primary transition-all duration-300 cursor-pointer group overflow-hidden shadow-lg hover:shadow-primary/10"
                            onClick={() => handleStartInterview(role.id)}
                          >
                            <div className="absolute inset-0 bg-gradient-to-br opacity-0 group-hover:opacity-10 transition-opacity duration-300"></div>
                            <CardContent className="p-6">
                              <div className="flex items-center mb-4">
                                <div className={`p-3 rounded-full bg-gradient-to-r ${role.color} mr-3`}>
                                  <Icon className="h-6 w-6 text-white" />
                                </div>
                                <h2 className="text-xl font-semibold">{role.title}</h2>
                              </div>
                              <p className="text-muted-foreground mb-6">{role.description}</p>
                              <Button className="w-full gradient-bg text-white border-none group-hover:shadow-lg transition-all duration-300">
                                Start Interview
                              </Button>
                            </CardContent>
                          </Card>
                        )
                      })}
                    </div>

                    {filteredRoles.length === 0 && (
                      <div className="text-center py-12">
                        <div className="mb-4">
                          <Sparkles className="h-12 w-12 text-muted-foreground mx-auto" />
                        </div>
                        <h3 className="text-xl font-semibold text-foreground">No matching roles found</h3>
                        <p className="text-muted-foreground mt-2">Try a different search term or browse all roles</p>
                        <Button
                          onClick={() => setSearchTerm("")}
                          variant="outline"
                          className="mt-4 border-border text-foreground hover:bg-accent"
                        >
                          Show All Roles
                        </Button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </>
        )}
      </div>
    </main>
  )
}
