"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useAuth } from "@/contexts/auth-context"
import Link from "next/link"
import { AlertCircle, Brain, Loader2, WifiOff } from "lucide-react"
import { useRouter } from "next/navigation"
import PasswordInput from "@/components/PasswordInput"
import NetworkStatus from "@/components/NetworkStatus"
import { createProfilesTable } from "@/lib/createTables"

export default function LoginPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState<string | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isOnline, setIsOnline] = useState(true)
  const { signIn, signInWithGoogle, user, isLoading } = useAuth()
  const router = useRouter()

  // Check online status
  useEffect(() => {
    const handleOnline = () => setIsOnline(true)
    const handleOffline = () => setIsOnline(false)

    // Set initial state
    setIsOnline(navigator.onLine)

    // Add event listeners
    window.addEventListener("online", handleOnline)
    window.addEventListener("offline", handleOffline)

    // Clean up
    return () => {
      window.removeEventListener("online", handleOnline)
      window.removeEventListener("offline", handleOffline)
    }
  }, [])

  // Ensure tables exist
  useEffect(() => {
    const initTables = async () => {
      try {
        const result = await createProfilesTable()
        if (!result.success) {
          // Check if it's a network error
          if (result.networkError || result.offline) {
            console.warn("Network issue detected when initializing tables:", result.error?.message)
            // Don't show an error to the user for network issues, just continue
            // The app should still work for authentication
          } else {
            console.warn(
              "Could not automatically create profiles table. This is expected if you're using the app without a database connection.",
            )
          }
          // Continue anyway, as the tables might already exist or be created by the backend
        }
      } catch (error) {
        console.error("Error initializing tables:", error)
        // Continue anyway, as the tables might already exist or be created by the backend
      }
    }

    if (isOnline) {
      // Try to initialize tables, but don't block the app if it fails
      initTables().catch((err) => {
        console.warn("Failed to initialize tables, continuing without database features:", err)
      })
    }
  }, [isOnline])

  // Redirect if already logged in
  useEffect(() => {
    if (user && !isLoading) {
      router.push("/")
    }
  }, [user, isLoading, router])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    setIsSubmitting(true)

    if (!isOnline) {
      setError("You are offline. Please check your internet connection and try again.")
      setIsSubmitting(false)
      return
    }

    if (!email || !password) {
      setError("Please fill in all fields")
      setIsSubmitting(false)
      return
    }

    try {
      const { error, success } = await signIn(email, password)

      if (error) {
        if (
          error.message?.includes("Invalid login credentials") ||
          error.message?.includes("Invalid email or password")
        ) {
          setError("Invalid email or password. Please try again.")
        } else if (error.message?.includes("No account found")) {
          setError("No account found with this email. Please sign up first.")
        } else if (
          error.message?.includes("Failed to fetch") ||
          error.message?.includes("Network error") ||
          error.message?.includes("Unable to connect")
        ) {
          setError(
            "Network error: Unable to connect to the authentication service. Please check your internet connection.",
          )
        } else {
          setError(error.message || "Failed to sign in")
        }
      } else if (success) {
        // Redirect is handled in the auth context
      }
    } catch (err: any) {
      console.error("Login error:", err)

      if (err.message?.includes("Failed to fetch")) {
        setError(
          "Network error: Unable to connect to the authentication service. Please check your internet connection.",
        )
      } else {
        setError(err.message || "An unexpected error occurred")
      }
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleGoogleSignIn = async () => {
    if (!isOnline) {
      setError("You are offline. Please check your internet connection and try again.")
      return
    }

    try {
      setIsSubmitting(true)
      const { error, success } = await signInWithGoogle()

      if (error) {
        console.error("Google sign in error:", error)
        setError(error.message || "Failed to sign in with Google")
      }
    } catch (err: any) {
      console.error("Google sign in error:", err)
      setError(err.message || "An unexpected error occurred")
    } finally {
      setIsSubmitting(false)
    }
  }

  // Show loading state while checking auth
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-gray-900 to-gray-800 p-4">
        <div className="text-center">
          <Loader2 className="h-12 w-12 animate-spin text-purple-500 mx-auto mb-4" />
          <p className="text-white">Loading...</p>
        </div>
      </div>
    )
  }

  // Don't show login page if already logged in
  if (user) {
    return null // Will redirect via useEffect
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-gray-900 to-gray-800 p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="relative">
              <div className="absolute -inset-1 rounded-full bg-gradient-to-r from-purple-600 to-blue-600 opacity-75 blur-sm"></div>
              <div className="relative bg-gray-900 rounded-full p-3">
                <Brain className="h-12 w-12 text-purple-400" />
              </div>
            </div>
          </div>
          <h1 className="text-3xl font-bold text-white">SmartHire AI</h1>
          <p className="text-gray-400 mt-2">Sign in to your account</p>
        </div>

        {!isOnline && (
          <div className="mb-6 bg-red-900/30 text-red-300 p-4 rounded-md flex items-center">
            <WifiOff className="h-5 w-5 mr-3 flex-shrink-0" />
            <div>
              <p className="font-medium">You are offline</p>
              <p className="text-sm">Please check your internet connection to sign in.</p>
            </div>
          </div>
        )}

        <Card className="border-gray-700 bg-gray-800/50 backdrop-blur-sm shadow-xl">
          <CardHeader>
            <CardTitle className="text-white">Login</CardTitle>
            <CardDescription className="text-gray-400">Enter your credentials to access your account</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-white">
                  Email
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="name@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="bg-gray-700 border-gray-600 text-white placeholder:text-gray-400"
                  disabled={isSubmitting || !isOnline}
                />
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="password" className="text-white">
                    Password
                  </Label>
                  <Link href="/forgot-password" className="text-sm text-purple-400 hover:text-purple-300">
                    Forgot password?
                  </Link>
                </div>
                <PasswordInput
                  id="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="bg-gray-700 border-gray-600 text-white placeholder:text-gray-400"
                  placeholder="••••••••"
                  disabled={isSubmitting || !isOnline}
                />
              </div>

              {error && (
                <div className="bg-red-900/30 text-red-300 p-3 rounded-md flex items-start">
                  <AlertCircle className="h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
                disabled={isSubmitting || !isOnline}
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Signing in...
                  </>
                ) : (
                  "Sign in"
                )}
              </Button>

              <div className="relative my-4">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t border-gray-600"></span>
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-gray-800 px-2 text-gray-400">Or continue with</span>
                </div>
              </div>

              <div className="space-y-3">
                <Button
                  type="button"
                  variant="outline"
                  className="w-full bg-white text-black hover:bg-gray-100 border-gray-300"
                  onClick={handleGoogleSignIn}
                  disabled={isSubmitting || !isOnline}
                >
                  {isSubmitting ? (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  ) : (
                    <svg
                      className="mr-2 h-4 w-4"
                      aria-hidden="true"
                      focusable="false"
                      data-prefix="fab"
                      data-icon="google"
                      role="img"
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 488 512"
                    >
                      <path
                        fill="currentColor"
                        d="M488 261.8C488 403.3 391.1 504 248 504 110.8 504 0 393.2 0 256S110.8 8 248 8c66.8 0 123 24.5 166.3 64.9l-67.5 64.9C258.5 52.6 94.3 116.6 94.3 256c0 86.5 69.1 156.6 153.7 156.6 98.2 0 135-70.4 140.8-106.9H248v-85.3h236.1c2.3 12.7 3.9 24.9 3.9 41.4z"
                      ></path>
                    </svg>
                  )}
                  Sign in with Google
                </Button>
              </div>
            </form>
          </CardContent>
          <CardFooter className="flex justify-center border-t border-gray-700 pt-4">
            <p className="text-gray-400 text-sm">
              Don't have an account?{" "}
              <Link href="/signup" className="text-purple-400 hover:text-purple-300 font-medium">
                Sign up
              </Link>
            </p>
          </CardFooter>
        </Card>
      </div>
      <NetworkStatus onStatusChange={setIsOnline} />
    </div>
  )
}
