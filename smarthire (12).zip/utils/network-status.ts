// Utility to check if the browser is online
export const isOnline = () => {
  return typeof navigator !== "undefined" && typeof navigator.onLine === "boolean" ? navigator.onLine : true
}

// Utility to check if a URL is reachable
export const checkEndpointReachable = async (url: string, timeout = 5000) => {
  try {
    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), timeout)

    const response = await fetch(url, {
      method: "HEAD",
      mode: "no-cors",
      signal: controller.signal,
    })

    clearTimeout(timeoutId)
    return true
  } catch (error) {
    console.error(`Failed to reach ${url}:`, error)
    return false
  }
}
