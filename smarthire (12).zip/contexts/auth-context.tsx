"use client"

import type React from "react"

import { createContext, useContext, useEffect, useState } from "react"
import { supabase, checkSupabaseConnection } from "@/lib/supabase"
import type { Session, User, PostgrestError } from "@supabase/supabase-js"
import { useRouter } from "next/navigation"
import { createProfilesTable } from "@/lib/createTables"
import { OAUTH_CONFIG } from "@/lib/oauth-config"

type AuthContextType = {
  user: User | null
  session: Session | null
  isLoading: boolean
  signUp: (
    email: string,
    password: string,
    name: string,
  ) => Promise<{
    error: any | null
    success: boolean
  }>
  signIn: (
    email: string,
    password: string,
  ) => Promise<{
    error: any | null
    success: boolean
  }>
  signInWithGoogle: () => Promise<{
    error: any | null
    success: boolean
  }>
  signInWithPhone: (phone: string) => Promise<{
    error: any | null
    success: boolean
  }>
  verifyOtp: (
    phone: string,
    token: string,
  ) => Promise<{
    error: any | null
    success: boolean
  }>
  signOut: () => Promise<void>
  createProfile: (
    userId: string,
    name: string,
    email: string,
  ) => Promise<{
    error: PostgrestError | Error | null
    success: boolean
  }>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [session, setSession] = useState<Session | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    const setData = async () => {
      try {
        const controller = new AbortController()
        const timeoutId = setTimeout(() => controller.abort(), 10000) // 10 second timeout

        const {
          data: { session },
          error,
        } = await supabase.auth.getSession()

        clearTimeout(timeoutId)

        if (error) {
          console.error("Error getting session:", error)
          setIsLoading(false)
          return
        }

        setSession(session)
        setUser(session?.user ?? null)
      } catch (error) {
        console.error("Unexpected error during session retrieval:", error)
      } finally {
        setIsLoading(false)
      }
    }

    // Set up auth state listener
    const { data: authListener } = supabase.auth.onAuthStateChange((_event, session) => {
      console.log("Auth state changed:", _event)
      setSession(session)
      setUser(session?.user ?? null)
      setIsLoading(false)
    })

    // Get initial session
    setData()

    // Cleanup subscription
    return () => {
      authListener?.subscription.unsubscribe()
    }
  }, [])

  // Create a profile in the profiles table
  const createProfile = async (userId: string, name: string, email: string) => {
    try {
      console.log("Creating profile for user:", userId, name, email)

      // Ensure profiles table exists
      const { success: tableSuccess, error: tableError } = await createProfilesTable()

      if (!tableSuccess) {
        console.warn("Could not ensure profiles table exists:", tableError)
        // Continue anyway, as the table might already exist
      }

      // Check if profile already exists
      const { data: existingProfile, error: checkError } = await supabase
        .from("profiles")
        .select("*")
        .eq("user_id", userId)
        .single()

      if (checkError && checkError.code !== "PGRST116") {
        // PGRST116 is "not found" which is expected
        console.error("Error checking for existing profile:", checkError)
        return { error: checkError, success: false }
      }

      if (existingProfile) {
        console.log("Profile already exists, skipping creation")
        return { error: null, success: true }
      }

      // Create new profile
      const { error: insertError } = await supabase.from("profiles").insert({
        user_id: userId,
        name,
        email,
      })

      if (insertError) {
        console.error("Error inserting profile:", insertError)
        return { error: insertError, success: false }
      }

      console.log("Profile created successfully")
      return { error: null, success: true }
    } catch (error: any) {
      console.error("Error in createProfile function:", error)
      return { error, success: false }
    }
  }

  const signUp = async (email: string, password: string, name: string) => {
    try {
      setIsLoading(true)

      // Check Supabase connection first
      const connectionCheck = await checkSupabaseConnection()
      if (!connectionCheck.ok) {
        console.error("Supabase connection check failed:", connectionCheck.error)
        return {
          error: new Error(`Unable to connect to authentication service: ${connectionCheck.error}`),
          success: false,
        }
      }

      // Sign up the user
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            name,
          },
          emailRedirectTo: `${window.location.origin}/auth/callback`,
        },
      })

      if (error) {
        console.error("Sign up error:", error)
        return { error, success: false }
      }

      // If user is created successfully
      if (data?.user) {
        // Create profile
        const { error: profileError, success: profileSuccess } = await createProfile(data.user.id, name, email)

        if (profileError) {
          console.error("Error creating profile after signup:", profileError)
          // Continue anyway, as the user is created
        }

        // If email confirmation is required
        if (!data.user.confirmed_at) {
          router.push("/signup/confirmation")
        } else {
          // If no email confirmation required, redirect to home
          router.push("/")
        }

        return { error: null, success: true }
      }

      return { error: new Error("Unknown error during sign up"), success: false }
    } catch (error: any) {
      console.error("Unexpected error during sign up:", error)

      // Provide a more user-friendly error message for network issues
      if (error.message === "Failed to fetch") {
        return {
          error: new Error(
            "Network error: Unable to connect to the authentication service. Please check your internet connection and try again.",
          ),
          success: false,
        }
      }

      return { error, success: false }
    } finally {
      setIsLoading(false)
    }
  }

  const signIn = async (email: string, password: string) => {
    try {
      setIsLoading(true)

      // Check connection first
      const connectionCheck = await checkSupabaseConnection()
      if (!connectionCheck.ok) {
        console.error("Supabase connection check failed:", connectionCheck.error)
        return {
          error: new Error(`Unable to connect to authentication service: ${connectionCheck.error}`),
          success: false,
        }
      }

      // Try to sign in
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      })

      if (error) {
        console.error("Sign in error:", error)

        // Provide more user-friendly error messages
        if (error.message.includes("Invalid login credentials")) {
          return {
            error: new Error("Invalid email or password. Please try again."),
            success: false,
          }
        }

        return { error, success: false }
      }

      if (data?.user) {
        router.push("/")
        return { error: null, success: true }
      }

      return { error: new Error("Unknown error during sign in"), success: false }
    } catch (error: any) {
      console.error("Unexpected error during sign in:", error)

      // Provide a more user-friendly error message for network issues
      if (error.message === "Failed to fetch") {
        return {
          error: new Error(
            "Network error: Unable to connect to the authentication service. Please check your internet connection and try again.",
          ),
          success: false,
        }
      }

      return { error, success: false }
    } finally {
      setIsLoading(false)
    }
  }

  const signInWithGoogle = async () => {
    try {
      setIsLoading(true)

      // Check connection first
      const connectionCheck = await checkSupabaseConnection()
      if (!connectionCheck.ok) {
        console.error("Supabase connection check failed:", connectionCheck.error)
        return {
          error: new Error(`Unable to connect to authentication service: ${connectionCheck.error}`),
          success: false,
        }
      }

      // Sign in with Google
      const { data, error } = await supabase.auth.signInWithOAuth({
        provider: "google",
        options: {
          redirectTo: OAUTH_CONFIG.google.redirectUri,
        },
      })

      if (error) {
        console.error("Google sign in error:", error)
        return { error, success: false }
      }

      // The user will be redirected to Google for authentication
      return { error: null, success: true }
    } catch (error: any) {
      console.error("Unexpected error during Google sign in:", error)

      // Provide a more user-friendly error message for network issues
      if (error.message === "Failed to fetch") {
        return {
          error: new Error(
            "Network error: Unable to connect to the authentication service. Please check your internet connection and try again.",
          ),
          success: false,
        }
      }

      return { error, success: false }
    } finally {
      setIsLoading(false)
    }
  }

  const signInWithPhone = async (phone: string) => {
    try {
      setIsLoading(true)

      // Check connection first
      const connectionCheck = await checkSupabaseConnection()
      if (!connectionCheck.ok) {
        console.error("Supabase connection check failed:", connectionCheck.error)
        return {
          error: new Error(`Unable to connect to authentication service: ${connectionCheck.error}`),
          success: false,
        }
      }

      // Send OTP to phone
      const { data, error } = await supabase.auth.signInWithOtp({
        phone,
        options: {
          shouldCreateUser: true,
        },
      })

      if (error) {
        console.error("Phone sign in error:", error)
        return { error, success: false }
      }

      // Redirect to OTP verification page
      router.push(`/verify-otp?phone=${encodeURIComponent(phone)}`)
      return { error: null, success: true }
    } catch (error: any) {
      console.error("Unexpected error during phone sign in:", error)

      // Provide a more user-friendly error message for network issues
      if (error.message === "Failed to fetch") {
        return {
          error: new Error(
            "Network error: Unable to connect to the authentication service. Please check your internet connection and try again.",
          ),
          success: false,
        }
      }

      return { error, success: false }
    } finally {
      setIsLoading(false)
    }
  }

  const verifyOtp = async (phone: string, token: string) => {
    try {
      setIsLoading(true)

      // Check connection first
      const connectionCheck = await checkSupabaseConnection()
      if (!connectionCheck.ok) {
        console.error("Supabase connection check failed:", connectionCheck.error)
        return {
          error: new Error(`Unable to connect to authentication service: ${connectionCheck.error}`),
          success: false,
        }
      }

      // Verify OTP
      const { data, error } = await supabase.auth.verifyOtp({
        phone,
        token,
        type: "sms",
      })

      if (error) {
        console.error("OTP verification error:", error)
        return { error, success: false }
      }

      if (data?.user) {
        // Create a profile for the user if it doesn't exist
        const { error: profileError } = await createProfile(data.user.id, data.user.phone || "", data.user.email || "")

        if (profileError) {
          console.error("Error creating profile after phone verification:", profileError)
          // Continue anyway, as the user is authenticated
        }

        router.push("/")
        return { error: null, success: true }
      }

      return { error: new Error("Unknown error during OTP verification"), success: false }
    } catch (error: any) {
      console.error("Unexpected error during OTP verification:", error)

      // Provide a more user-friendly error message for network issues
      if (error.message === "Failed to fetch") {
        return {
          error: new Error(
            "Network error: Unable to connect to the authentication service. Please check your internet connection and try again.",
          ),
          success: false,
        }
      }

      return { error, success: false }
    } finally {
      setIsLoading(false)
    }
  }

  const signOut = async () => {
    try {
      setIsLoading(true)
      await supabase.auth.signOut()
      router.push("/login")
    } catch (error) {
      console.error("Error signing out:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const value = {
    user,
    session,
    isLoading,
    signUp,
    signIn,
    signInWithGoogle,
    signInWithPhone,
    verifyOtp,
    signOut,
    createProfile,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
