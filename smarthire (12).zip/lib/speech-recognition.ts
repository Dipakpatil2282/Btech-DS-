// A dedicated service for handling speech recognition with better reliability

type SpeechRecognitionStatus = "inactive" | "initializing" | "active" | "error"

interface SpeechRecognitionOptions {
  continuous?: boolean
  interimResults?: boolean
  language?: string
  maxDuration?: number // in milliseconds, 0 for no limit
}

interface SpeechRecognitionCallbacks {
  onStart?: () => void
  onResult?: (transcript: string, isFinal: boolean) => void
  onEnd?: () => void
  onError?: (error: string) => void
}

declare global {
  interface Window {
    SpeechRecognition: any
    webkitSpeechRecognition: any
  }
}

class SpeechRecognitionService {
  private recognition: any = null
  private status: SpeechRecognitionStatus = "inactive"
  private options: SpeechRecognitionOptions
  private callbacks: SpeechRecognitionCallbacks
  private finalTranscript = ""
  private interimTranscript = ""
  private lastResultTimestamp = 0
  private startTimestamp = 0
  private healthCheckInterval: NodeJS.Timeout | null = null
  private restartAttempts = 0
  private maxRestartAttempts = 5
  private isDestroyed = false
  private sessionId = Math.random().toString(36).substring(2, 9)

  constructor(options: SpeechRecognitionOptions = {}, callbacks: SpeechRecognitionCallbacks = {}) {
    this.options = {
      continuous: true,
      interimResults: true,
      language: "en-US",
      maxDuration: 0, // No limit by default
      ...options,
    }

    this.callbacks = callbacks
    console.log(`[SpeechRecognition-${this.sessionId}] Service created with options:`, this.options)
  }

  public isSupported(): boolean {
    return !!(window.SpeechRecognition || window.webkitSpeechRecognition)
  }

  public getStatus(): SpeechRecognitionStatus {
    return this.status
  }

  public start(): boolean {
    if (this.isDestroyed) {
      console.warn(`[SpeechRecognition-${this.sessionId}] Cannot start destroyed service`)
      return false
    }

    if (this.status === "active" || this.status === "initializing") {
      console.log(`[SpeechRecognition-${this.sessionId}] Speech recognition is already active or initializing`)
      return false
    }

    if (!this.isSupported()) {
      console.error(`[SpeechRecognition-${this.sessionId}] Speech recognition is not supported in this browser`)
      this.status = "error"
      this.callbacks.onError?.("Speech recognition is not supported in this browser")
      return false
    }

    try {
      this.status = "initializing"
      console.log(`[SpeechRecognition-${this.sessionId}] Initializing speech recognition...`)

      // Create a new instance each time to avoid potential issues with reusing instances
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
      this.recognition = new SpeechRecognition()

      // Configure the recognition instance
      this.recognition.continuous = this.options.continuous ?? true
      this.recognition.interimResults = this.options.interimResults ?? true
      this.recognition.lang = this.options.language ?? "en-US"
      this.recognition.maxAlternatives = 1

      // Set up event handlers
      this.recognition.onstart = this.handleStart.bind(this)
      this.recognition.onresult = this.handleResult.bind(this)
      this.recognition.onerror = this.handleError.bind(this)
      this.recognition.onend = this.handleEnd.bind(this)

      // Start recognition
      this.recognition.start()
      console.log(`[SpeechRecognition-${this.sessionId}] Recognition.start() called`)

      // Set up health check to ensure recognition is working
      this.startHealthCheck()

      return true
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Unknown error"
      console.error(`[SpeechRecognition-${this.sessionId}] Failed to start speech recognition:`, errorMessage)
      this.status = "error"
      this.callbacks.onError?.(`Failed to start speech recognition: ${errorMessage}`)
      return false
    }
  }

  public stop(): void {
    if (this.recognition && (this.status === "active" || this.status === "initializing")) {
      try {
        console.log(`[SpeechRecognition-${this.sessionId}] Stopping speech recognition...`)
        this.stopHealthCheck()
        this.recognition.stop()
        this.status = "inactive"
      } catch (error) {
        console.error(`[SpeechRecognition-${this.sessionId}] Error stopping speech recognition:`, error)
      }
    }
  }

  public reset(): void {
    this.finalTranscript = ""
    this.interimTranscript = ""
    console.log(`[SpeechRecognition-${this.sessionId}] Transcripts reset`)
  }

  public destroy(): void {
    console.log(`[SpeechRecognition-${this.sessionId}] Destroying speech recognition service`)
    this.isDestroyed = true
    this.stop()
    this.stopHealthCheck()
    this.recognition = null
  }

  public getFinalTranscript(): string {
    return this.finalTranscript
  }

  public getInterimTranscript(): string {
    return this.interimTranscript
  }

  private handleStart(): void {
    console.log(`[SpeechRecognition-${this.sessionId}] Speech recognition started`)
    this.status = "active"
    this.lastResultTimestamp = Date.now()
    this.startTimestamp = Date.now()
    this.restartAttempts = 0
    this.callbacks.onStart?.()
  }

  private handleResult(event: any): void {
    if (this.isDestroyed) return

    this.lastResultTimestamp = Date.now()

    let interimTranscript = ""
    let finalTranscriptAddition = ""

    // Process all results
    for (let i = event.resultIndex; i < event.results.length; i++) {
      const transcript = event.results[i][0].transcript

      if (event.results[i].isFinal) {
        finalTranscriptAddition += transcript + " "
      } else {
        interimTranscript += transcript
      }
    }

    // Update transcripts
    this.interimTranscript = interimTranscript

    if (finalTranscriptAddition) {
      this.finalTranscript += finalTranscriptAddition
      console.log(`[SpeechRecognition-${this.sessionId}] Final transcript updated:`, this.finalTranscript)
      this.callbacks.onResult?.(finalTranscriptAddition.trim(), true)
    } else if (interimTranscript) {
      console.log(`[SpeechRecognition-${this.sessionId}] Interim transcript:`, interimTranscript)
      this.callbacks.onResult?.(interimTranscript, false)
    }

    // Check if we've exceeded the maximum duration
    if (this.options.maxDuration && this.options.maxDuration > 0) {
      const elapsedTime = Date.now() - this.startTimestamp
      if (elapsedTime > this.options.maxDuration) {
        console.log(
          `[SpeechRecognition-${this.sessionId}] Maximum duration (${this.options.maxDuration}ms) exceeded, stopping`,
        )
        this.stop()
      }
    }
  }

  private handleError(event: any): void {
    if (this.isDestroyed) return

    console.error(`[SpeechRecognition-${this.sessionId}] Speech recognition error:`, event.error)

    // Don't treat no-speech as a critical error
    if (event.error === "no-speech") {
      return
    }

    this.status = "error"
    this.callbacks.onError?.(event.error || "Unknown speech recognition error")

    // Attempt to restart if appropriate
    if (!this.isDestroyed && this.restartAttempts < this.maxRestartAttempts) {
      this.restartAttempts++
      const backoffTime = 1000 * this.restartAttempts // Linear backoff

      console.log(
        `[SpeechRecognition-${this.sessionId}] Will attempt to restart in ${backoffTime}ms (attempt ${this.restartAttempts})`,
      )

      setTimeout(() => {
        if (!this.isDestroyed && this.status === "error") {
          console.log(`[SpeechRecognition-${this.sessionId}] Attempting restart after error`)
          this.start()
        }
      }, backoffTime)
    }
  }

  private handleEnd(): void {
    if (this.isDestroyed) return

    console.log(`[SpeechRecognition-${this.sessionId}] Speech recognition ended`)

    // Only update status if we're not already in error state
    if (this.status !== "error") {
      this.status = "inactive"
    }

    this.stopHealthCheck()
    this.callbacks.onEnd?.()

    // Auto-restart if it ended unexpectedly and we're not in error state or destroyed
    if (!this.isDestroyed && this.status !== "error" && this.restartAttempts < this.maxRestartAttempts) {
      this.restartAttempts++

      console.log(
        `[SpeechRecognition-${this.sessionId}] Auto-restarting speech recognition (attempt ${this.restartAttempts})`,
      )

      setTimeout(() => {
        if (!this.isDestroyed) {
          this.start()
        }
      }, 300)
    }
  }

  private startHealthCheck(): void {
    this.stopHealthCheck() // Clear any existing interval

    this.healthCheckInterval = setInterval(() => {
      if (this.isDestroyed) {
        this.stopHealthCheck()
        return
      }

      // If we haven't received results in 10 seconds and we think we're active, the recognition might be stuck
      const timeSinceLastResult = Date.now() - this.lastResultTimestamp
      if (this.status === "active" && timeSinceLastResult > 10000) {
        console.warn(`[SpeechRecognition-${this.sessionId}] Speech recognition appears to be stuck, restarting...`)
        this.stop()

        if (!this.isDestroyed) {
          setTimeout(() => this.start(), 500)
        }
      }
    }, 5000) // Check every 5 seconds
  }

  private stopHealthCheck(): void {
    if (this.healthCheckInterval) {
      clearInterval(this.healthCheckInterval)
      this.healthCheckInterval = null
    }
  }
}

// Create a factory function instead of a singleton to allow multiple instances
export function createSpeechRecognition(
  options?: SpeechRecognitionOptions,
  callbacks?: SpeechRecognitionCallbacks,
): SpeechRecognitionService {
  return new SpeechRecognitionService(options, callbacks)
}
