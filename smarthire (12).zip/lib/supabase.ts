import { createClient } from "@supabase/supabase-js"

// Supabase credentials
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || "https://jwasbuyknhzmbdckqtdd.supabase.co"
const supabaseAnonKey =
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ||
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imp3YXNidXlrbmh6bWJkY2txdGRkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDE0MDczNTMsImV4cCI6MjA1Njk4MzM1M30.KLD_6aqVpe3cklbWtWJG1lSeoBkwh7DSSFzrbqZ6yIs"

// Create a single instance of the Supabase client
let supabaseInstance: ReturnType<typeof createClient> | null = null

export const getSupabase = () => {
  if (!supabaseInstance) {
    try {
      console.log("Initializing Supabase client with URL:", supabaseUrl)
      supabaseInstance = createClient(supabaseUrl, supabaseAnonKey, {
        auth: {
          persistSession: true,
          autoRefreshToken: true,
          detectSessionInUrl: true,
        },
        global: {
          fetch: (...args) => {
            // Add timeout to fetch requests
            const [url, options] = args
            const controller = new AbortController()
            const { signal } = controller

            const timeoutId = setTimeout(() => controller.abort(), 10000) // 10 second timeout

            return fetch(url, {
              ...options,
              signal,
            }).finally(() => {
              clearTimeout(timeoutId)
            })
          },
        },
        realtime: {
          params: {
            eventsPerSecond: 10,
          },
        },
      })
    } catch (error) {
      console.error("Error initializing Supabase client:", error)
      throw new Error("Failed to initialize Supabase client. Please check your connection and try again.")
    }
  }
  return supabaseInstance
}

// Export the client directly for convenience
export const supabase = getSupabase()

// Helper function to check if Supabase is accessible
export const checkSupabaseConnection = async () => {
  try {
    // First check if we're online at all
    if (typeof navigator !== "undefined" && !navigator.onLine) {
      return { ok: false, error: "You are offline. Please check your internet connection." }
    }

    // Try a simple ping to the Supabase URL with timeout
    try {
      const controller = new AbortController()
      const timeoutId = setTimeout(() => controller.abort(), 5000) // 5 second timeout

      const response = await fetch(`${supabaseUrl}/rest/v1/?apikey=${supabaseAnonKey}`, {
        method: "HEAD",
        headers: {
          "Content-Type": "application/json",
          apikey: supabaseAnonKey,
        },
        signal: controller.signal,
      })

      clearTimeout(timeoutId)

      if (!response.ok) {
        return { ok: false, error: `Supabase API returned status ${response.status}` }
      }
    } catch (error: any) {
      if (error.name === "AbortError") {
        return { ok: false, error: "Connection to Supabase timed out. Please try again later." }
      }
      return { ok: false, error: `Network error: ${error.message}` }
    }

    // If we got here, basic connectivity is working, now check if auth is working
    try {
      const controller = new AbortController()
      const timeoutId = setTimeout(() => controller.abort(), 5000) // 5 second timeout

      const { data, error } = await supabase.auth.getSession()

      clearTimeout(timeoutId)

      if (error) {
        console.warn("Auth service check failed:", error)
        return { ok: false, error: `Auth service error: ${error.message}` }
      }
    } catch (error: any) {
      if (error.name === "AbortError") {
        return { ok: false, error: "Authentication service timed out. Please try again later." }
      }
      console.error("Error checking auth service:", error)
      return { ok: false, error: `Auth service error: ${error.message}` }
    }

    return { ok: true, error: null }
  } catch (error: any) {
    console.error("Supabase connection check failed:", error)
    return { ok: false, error: error?.message || "Failed to connect to Supabase" }
  }
}
