export const OAUTH_CONFIG = {
  google: {
    redirectUri: "https://jwasbuyknhzmbdckqtdd.supabase.co/auth/v1/callback",
  },
  twilio: {
    accountSid: "AC840c78e5b7e4fa03aa8d3108a9e7e64f",
    authToken: "f4fbc814c79cb43303b1bbee0ac27974",
    verifySid: "VAaf181623ea9458ba53611190f556f230",
  },
}
