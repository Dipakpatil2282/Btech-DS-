// Google Gemini API integration with the provided API key
const DEFAULT_API_KEY = "AIzaSyAst5EV-cLw47GDcu_lUnwT5YeXO-ilrE8"

interface GeminiResponse {
  questions: string[]
  error?: string
}

interface AnswerAnalysisResponse {
  score: number
  isCorrect: boolean
  feedback?: string
  error?: string
}

export async function generateRelevantQuestions(
  jobRole: string,
  level: "beginner" | "intermediate" | "advanced",
  apiKey: string = DEFAULT_API_KEY,
): Promise<GeminiResponse> {
  try {
    // In a real implementation, this would make an API call to Google's Gemini API
    // For now, we'll return structured questions based on the requirements

    if (!apiKey) {
      return {
        questions: [],
        error: "API key is required",
      }
    }

    // This is where you would make the actual API call
    // const response = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent', {
    //   method: 'POST',
    //   headers: {
    //     'Content-Type': 'application/json',
    //     'Authorization': `Bearer ${apiKey}`
    //   },
    //   body: JSON.stringify({
    //     contents: [{
    //       parts: [{
    //         text: `Generate 10 interview questions for a ${level} ${jobRole} position with the following structure:
    //                1. First question should be "Tell me about yourself and your experience as a ${jobRole}."
    //                2. Include 1 coding question appropriate for a ${level} ${jobRole}.
    //                3. Include 2 behavioral questions.
    //                4. Include 2 questions about OOP concepts relevant to the role.
    //                5. Include 4 technical questions specific to the ${jobRole} role.
    //                Format the response as a JSON array of strings.
    //                For the coding question, prefix it with [CODE] so the interface knows to display a code editor.`
    //       }]
    //     }]
    //   })
    // });

    // const data = await response.json();
    // const questions = JSON.parse(data.candidates[0].content.parts[0].text);

    // For now, we'll simulate different questions based on the level and job role
    console.log(`Generating 10 questions for ${level} ${jobRole} using API key ${apiKey.substring(0, 5)}...`)

    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 1500))

    // Generate structured questions based on job role and level
    const structuredQuestions = generateStructuredQuestions(jobRole, level)

    return {
      questions: structuredQuestions,
    }
  } catch (error) {
    console.error("Error generating questions:", error)
    return {
      questions: [],
      error: "Failed to generate questions",
    }
  }
}

export async function analyzeAnswer(
  question: string,
  answer: string,
  jobRole: string,
  level: "beginner" | "intermediate" | "advanced",
  apiKey: string = DEFAULT_API_KEY,
): Promise<AnswerAnalysisResponse> {
  try {
    if (!apiKey) {
      return {
        score: 0,
        isCorrect: false,
        error: "API key is required",
      }
    }

    // This is where you would make the actual API call to Gemini
    // const response = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent', {
    //   method: 'POST',
    //   headers: {
    //     'Content-Type': 'application/json',
    //     'Authorization': `Bearer ${apiKey}`
    //   },
    //   body: JSON.stringify({
    //     contents: [{
    //       parts: [{
    //         text: `You are an expert interviewer for ${jobRole} positions.
    //                Analyze the following answer to the interview question and rate it on a scale of 0-10.
    //
    //                Question: ${question}
    //
    //                Answer: ${answer}
    //
    //                Provide a JSON response with the following structure:
    //                {
    //                  "score": number between 0 and 10,
    //                  "isCorrect": boolean indicating if the answer is correct,
    //                  "feedback": brief feedback on the answer
    //                }
    //
    //                Consider the technical accuracy, completeness, clarity, and relevance to the ${level} ${jobRole} position.`
    //       }]
    //     }]
    //   })
    // });

    // const data = await response.json();
    // const analysis = JSON.parse(data.candidates[0].content.parts[0].text);

    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    // For now, we'll simulate a more sophisticated analysis
    const wordCount = answer.split(/\s+/).length
    let score = 0
    let isCorrect = false

    // Check for empty or very short answers
    if (!answer || answer.trim() === "" || wordCount < 5) {
      return {
        score: 0,
        isCorrect: false,
        feedback: "Answer is too short or empty.",
      }
    }

    // Check for keywords related to the question
    const questionLower = question.toLowerCase()
    const answerLower = answer.toLowerCase()

    // Extract key terms from the question
    const keyTerms = extractKeyTerms(questionLower, jobRole)

    // Count how many key terms are in the answer
    const matchedTerms = keyTerms.filter((term) => answerLower.includes(term))
    const matchRatio = keyTerms.length > 0 ? matchedTerms.length / keyTerms.length : 0

    // Determine if the answer is correct based on term matching and length
    if (matchRatio >= 0.7 && wordCount >= 30) {
      isCorrect = true

      // Calculate score based on match ratio and answer length
      if (wordCount < 50) {
        score = 6 + Math.floor(matchRatio * 2) // 6-8 range
      } else if (wordCount < 100) {
        score = 7 + Math.floor(matchRatio * 2) // 7-9 range
      } else {
        score = 8 + Math.floor(matchRatio * 2) // 8-10 range
      }

      // Cap at 10
      score = Math.min(10, score)
    } else {
      // For incorrect answers, always set score to 0
      isCorrect = false
      score = 0
    }

    return {
      score,
      isCorrect,
      feedback: `Your answer was ${isCorrect ? "correct" : "incomplete or incorrect"}. ${isCorrect ? "Good job!" : "Try to include more relevant information."}`,
    }
  } catch (error) {
    console.error("Error analyzing answer:", error)
    return {
      score: 0, // Default to 0 for errors
      isCorrect: false,
      error: "Failed to analyze answer",
    }
  }
}

// Helper function to extract key terms from a question
function extractKeyTerms(question: string, jobRole: string): string[] {
  // Basic extraction of technical terms based on job role
  const commonTerms = ["experience", "explain", "describe", "approach", "handle"]

  // Remove common terms and split into words
  const words = question
    .replace(/[.,?!;:(){}[\]"']/g, "")
    .split(/\s+/)
    .filter((word) => word.length > 3 && !commonTerms.includes(word))

  // Add job-specific terms
  const jobTerms: Record<string, string[]> = {
    "Frontend Developer": ["html", "css", "javascript", "react", "vue", "angular", "responsive", "dom", "framework"],
    "Backend Developer": ["api", "database", "server", "node", "express", "django", "flask", "spring", "sql", "nosql"],
    "Full Stack Developer": ["frontend", "backend", "fullstack", "stack", "database", "api", "client", "server"],
    "Java Developer": ["java", "spring", "hibernate", "maven", "gradle", "jvm", "object", "class", "interface"],
    "Python Developer": ["python", "django", "flask", "numpy", "pandas", "async", "object", "class"],
    "JavaScript Developer": ["javascript", "typescript", "node", "npm", "webpack", "babel", "async", "promise"],
    "React Developer": ["react", "component", "hook", "state", "props", "jsx", "redux", "context"],
    "Node.js Developer": ["node", "express", "npm", "async", "callback", "promise", "module", "middleware"],
    "Data Analyst": ["data", "analysis", "sql", "excel", "visualization", "statistics", "report", "dashboard"],
    "Data Scientist": ["algorithm", "model", "machine", "learning", "statistics", "prediction", "classification"],
    "Machine Learning Engineer": ["model", "algorithm", "training", "neural", "network", "feature", "dataset"],
    "DevOps Engineer": ["ci", "cd", "pipeline", "docker", "kubernetes", "jenkins", "automation", "deployment"],
    "Cloud Engineer": ["aws", "azure", "gcp", "cloud", "serverless", "infrastructure", "terraform"],
    "Mobile App Developer": ["android", "ios", "swift", "kotlin", "react", "native", "flutter", "mobile"],
    "UI/UX Designer": ["design", "user", "interface", "experience", "wireframe", "prototype", "usability"],
  }

  // Get job-specific terms
  const specificTerms = jobTerms[jobRole] || []

  // Combine all terms and remove duplicates
  const allTerms = [...new Set([...words, ...specificTerms])]

  // Filter to only include terms that are relevant to the question
  return allTerms.filter((term) => question.includes(term))
}

function generateStructuredQuestions(jobRole: string, level: string): string[] {
  // Always start with "Tell me about yourself"
  const questions = [`Tell me about yourself and your experience as a ${jobRole}.`]

  // Add 1 coding question based on job role and level
  questions.push(generateCodingQuestion(jobRole, level))

  // Add 2 behavioral questions
  questions.push(...generateBehavioralQuestions(jobRole, level, 2))

  // Add 2 OOP concept questions
  questions.push(...generateOOPQuestions(jobRole, level, 2))

  // Add 4 job-specific relevant questions
  questions.push(...generateJobSpecificQuestions(jobRole, level, 4))

  // Ensure we have exactly 10 questions
  return questions.slice(0, 10)
}

function generateCodingQuestion(jobRole: string, level: string): string {
  const codingQuestions: Record<string, Record<string, string>> = {
    "Frontend Developer": {
      beginner:
        "[CODE] Write a simple HTML form with fields for name, email, and a submit button. Style it using CSS to have rounded corners and a background color.",
      intermediate:
        "[CODE] Create a JavaScript function that fetches data from an API and displays it in a responsive grid layout. Use any framework or vanilla JS.",
      advanced:
        "[CODE] Implement a React component that uses hooks to manage state for a shopping cart. Include functionality to add items, remove items, and calculate the total.",
    },
    "Backend Developer": {
      beginner:
        "[CODE] Write a function that connects to a database and retrieves all records from a 'users' table. Use any language you're comfortable with.",
      intermediate:
        "[CODE] Create an API endpoint that handles user authentication. Include error handling and proper status codes.",
      advanced:
        "[CODE] Implement a caching mechanism for database queries to improve performance. Explain your approach and considerations.",
    },
    "Full Stack Developer": {
      beginner:
        "[CODE] Create a simple full-stack application with a form that submits data to a backend and stores it in a database.",
      intermediate:
        "[CODE] Implement a real-time chat feature using WebSockets. Show both the frontend and backend code.",
      advanced:
        "[CODE] Design and implement a microservice architecture for an e-commerce platform. Include service discovery and communication patterns.",
    },
    "Java Developer": {
      beginner:
        "[CODE] Write a Java class that represents a 'Book' with properties like title, author, and ISBN. Include getters, setters, and a toString method.",
      intermediate:
        "[CODE] Implement a Java program that reads data from a CSV file, processes it, and writes the results to a new file. Use proper exception handling.",
      advanced:
        "[CODE] Create a multithreaded application in Java that simulates a banking system with concurrent transactions. Ensure thread safety.",
    },
    "Python Developer": {
      beginner:
        "[CODE] Write a Python function that takes a list of numbers and returns the sum of all even numbers in the list.",
      intermediate:
        "[CODE] Create a Python class for a simple web scraper that extracts data from a webpage and saves it to a CSV file.",
      advanced:
        "[CODE] Implement a machine learning pipeline in Python that preprocesses data, trains a model, and evaluates its performance.",
    },
    "JavaScript Developer": {
      beginner:
        "[CODE] Write a JavaScript function that takes an array of numbers and returns a new array with only the even numbers.",
      intermediate:
        "[CODE] Implement a debounce function in JavaScript and demonstrate how it can be used to optimize event handling.",
      advanced:
        "[CODE] Create a JavaScript module that implements the Observer pattern. Show how it can be used in a real-world application.",
    },
    "React Developer": {
      beginner: "[CODE] Create a simple React component that displays a list of items from an array.",
      intermediate: "[CODE] Implement a custom hook in React that manages form state and validation.",
      advanced:
        "[CODE] Build a React application that uses Context API and Reducers to manage global state. Include optimizations for performance.",
    },
    "Node.js Developer": {
      beginner: "[CODE] Write a simple Node.js server that responds with 'Hello World' when accessed.",
      intermediate: "[CODE] Create a RESTful API in Node.js with endpoints for CRUD operations on a resource.",
      advanced: "[CODE] Implement a Node.js application that processes large files in chunks to avoid memory issues.",
    },
    "Data Analyst": {
      beginner: "[CODE] Write a SQL query to find the top 5 customers who have spent the most money.",
      intermediate:
        "[CODE] Create a Python script that analyzes a dataset and generates visualizations of key metrics.",
      advanced:
        "[CODE] Implement a data pipeline that extracts data from multiple sources, transforms it, and loads it into a data warehouse.",
    },
    "Data Scientist": {
      beginner: "[CODE] Write a Python function to clean a dataset by handling missing values and outliers.",
      intermediate: "[CODE] Implement a classification algorithm from scratch in Python and evaluate its performance.",
      advanced: "[CODE] Create a deep learning model for image classification using TensorFlow or PyTorch.",
    },
    "Machine Learning Engineer": {
      beginner:
        "[CODE] Write code to preprocess a dataset for machine learning, including normalization and encoding categorical variables.",
      intermediate: "[CODE] Implement a simple neural network using a framework like TensorFlow or PyTorch.",
      advanced: "[CODE] Create a reinforcement learning agent that learns to play a simple game.",
    },
    "DevOps Engineer": {
      beginner: "[CODE] Write a shell script that automates the backup of a directory.",
      intermediate: "[CODE] Create a Docker Compose file for a multi-container application.",
      advanced: "[CODE] Implement a CI/CD pipeline using a tool like Jenkins, GitHub Actions, or GitLab CI.",
    },
    "Cloud Engineer": {
      beginner: "[CODE] Write a script to create and configure a virtual machine in a cloud provider.",
      intermediate: "[CODE] Create an Infrastructure as Code (IaC) template for a three-tier web application.",
      advanced: "[CODE] Implement a serverless architecture for a real-time data processing application.",
    },
    "Mobile App Developer": {
      beginner: "[CODE] Create a simple mobile app screen with a list of items.",
      intermediate: "[CODE] Implement a mobile app feature that fetches and displays data from an API.",
      advanced: "[CODE] Create a mobile app that uses device features like camera, location, and push notifications.",
    },
    "UI/UX Designer": {
      beginner: "[CODE] Write HTML and CSS for a responsive navigation menu.",
      intermediate: "[CODE] Create an interactive prototype for a user onboarding flow.",
      advanced: "[CODE] Implement an accessible form with client-side validation using HTML, CSS, and JavaScript.",
    },
  }

  // Default coding question if job role or level not found
  const defaultQuestion = "[CODE] Write a function that solves a problem relevant to your field. Explain your approach."

  return codingQuestions[jobRole]?.[level] || defaultQuestion
}

function generateBehavioralQuestions(jobRole: string, level: string, count: number): string[] {
  const behavioralQuestions = [
    `Describe a challenging situation you faced in a previous ${jobRole} role and how you handled it.`,
    `Tell me about a time when you had to work under pressure to meet a deadline as a ${jobRole}.`,
    `Describe a situation where you had to collaborate with a difficult team member to complete a project.`,
    `Tell me about a time when you had to learn a new technology or skill quickly to complete a task.`,
    `Describe a situation where you identified a problem and took the initiative to solve it.`,
    `Tell me about a time when you received critical feedback and how you responded to it.`,
    `Describe a project where you had to manage multiple priorities simultaneously.`,
    `Tell me about a time when you had to make a difficult decision with limited information.`,
  ]

  // Shuffle and select the requested number of questions
  return shuffleArray(behavioralQuestions).slice(0, count)
}

function generateOOPQuestions(jobRole: string, level: string, count: number): string[] {
  const oopQuestions = [
    `Explain the concept of inheritance in object-oriented programming and provide an example relevant to ${jobRole} work.`,
    `Describe the difference between abstraction and encapsulation in OOP. How have you applied these concepts in your projects?`,
    `Explain polymorphism and how it can be used to write more flexible code in ${level} ${jobRole} applications.`,
    `How do you apply SOLID principles in your object-oriented design? Give specific examples from your experience.`,
    `Explain the concept of composition over inheritance. When would you choose one over the other?`,
    `Describe how you would implement a design pattern (like Singleton, Factory, or Observer) in a ${jobRole} project.`,
    `How do you handle error and exception scenarios in an object-oriented codebase?`,
    `Explain how you would design a class hierarchy for a system relevant to ${jobRole} responsibilities.`,
  ]

  // Shuffle and select the requested number of questions
  return shuffleArray(oopQuestions).slice(0, count)
}

function generateJobSpecificQuestions(jobRole: string, level: string, count: number): string[] {
  const jobSpecificQuestions: Record<string, string[]> = {
    "Frontend Developer": [
      `Explain the difference between client-side and server-side rendering. When would you choose one over the other?`,
      `How do you optimize the performance of a web application? Mention specific techniques you've used.`,
      `Describe your experience with CSS preprocessors and how they improve your workflow.`,
      `How do you ensure cross-browser compatibility in your frontend projects?`,
      `Explain how you implement accessibility in your frontend applications.`,
      `Describe your approach to state management in complex frontend applications.`,
      `How do you handle API integration in frontend applications?`,
      `Explain your testing strategy for frontend code.`,
    ],
    "Backend Developer": [
      `Describe your experience with database design and optimization.`,
      `How do you ensure the security of a backend application?`,
      `Explain your approach to API design and documentation.`,
      `How do you handle database migrations in a production environment?`,
      `Describe your experience with message queues and when you would use them.`,
      `How do you monitor and troubleshoot performance issues in a backend system?`,
      `Explain your approach to writing maintainable and scalable backend code.`,
      `How do you handle authentication and authorization in backend systems?`,
    ],
    "Full Stack Developer": [
      `How do you manage the integration between frontend and backend systems?`,
      `Describe your experience with full-stack frameworks and when you would choose one over another.`,
      `How do you handle state management across the full stack?`,
      `Explain your approach to testing full-stack applications.`,
      `How do you ensure security in full-stack applications?`,
      `Describe your experience with database design and optimization for full-stack applications.`,
      `How do you handle deployment and DevOps in your full-stack projects?`,
      `Explain your approach to API design in full-stack applications.`,
    ],
    "Java Developer": [
      `Describe your experience with Java frameworks like Spring or Hibernate.`,
      `How do you handle memory management in Java applications?`,
      `Explain your approach to concurrency in Java.`,
      `How do you optimize the performance of Java applications?`,
      `Describe your experience with Java build tools and dependency management.`,
      `How do you implement design patterns in Java?`,
      `Explain your approach to testing Java applications.`,
      `How do you handle logging and monitoring in Java applications?`,
    ],
    "Python Developer": [
      `Describe your experience with Python frameworks like Django or Flask.`,
      `How do you handle package management in Python?`,
      `Explain your approach to writing efficient Python code.`,
      `How do you handle asynchronous programming in Python?`,
      `Describe your experience with Python for data analysis or machine learning.`,
      `How do you implement testing in Python projects?`,
      `Explain your approach to handling environment management in Python.`,
      `How do you optimize Python code for performance?`,
    ],
    "JavaScript Developer": [
      `Describe your experience with JavaScript frameworks and libraries.`,
      `How do you handle asynchronous operations in JavaScript?`,
      `Explain your approach to debugging JavaScript code.`,
      `How do you optimize JavaScript performance?`,
      `Describe your experience with modern JavaScript features (ES6+).`,
      `How do you implement testing in JavaScript projects?`,
      `Explain your approach to module bundling and build tools in JavaScript.`,
      `How do you handle browser compatibility issues in JavaScript?`,
    ],
    "React Developer": [
      `Describe your experience with React hooks and when you would use them.`,
      `How do you manage state in React applications?`,
      `Explain your approach to component design in React.`,
      `How do you optimize performance in React applications?`,
      `Describe your experience with React state management libraries.`,
      `How do you implement testing in React applications?`,
      `Explain your approach to handling forms in React.`,
      `How do you handle routing in React applications?`,
    ],
    "Node.js Developer": [
      `Describe your experience with Node.js frameworks like Express or Nest.js.`,
      `How do you handle asynchronous operations in Node.js?`,
      `Explain your approach to error handling in Node.js applications.`,
      `How do you optimize the performance of Node.js applications?`,
      `Describe your experience with database integration in Node.js.`,
      `How do you implement authentication and authorization in Node.js?`,
      `Explain your approach to testing Node.js applications.`,
      `How do you handle deployment of Node.js applications?`,
    ],
    "Data Analyst": [
      `Describe your experience with data visualization tools and techniques.`,
      `How do you approach data cleaning and preprocessing?`,
      `Explain your experience with SQL and database querying.`,
      `How do you handle large datasets in your analysis?`,
      `Describe your experience with statistical methods in data analysis.`,
      `How do you communicate your findings to non-technical stakeholders?`,
      `Explain your approach to automating data analysis workflows.`,
      `How do you ensure the accuracy and reliability of your analysis?`,
    ],
    "Data Scientist": [
      `Describe your experience with machine learning algorithms and when you would use different approaches.`,
      `How do you handle feature engineering in your data science projects?`,
      `Explain your approach to model evaluation and validation.`,
      `How do you handle imbalanced datasets?`,
      `Describe your experience with deep learning and neural networks.`,
      `How do you communicate complex findings to non-technical stakeholders?`,
      `Explain your approach to deploying machine learning models to production.`,
      `How do you stay updated with the latest advancements in data science?`,
    ],
    "Machine Learning Engineer": [
      `Describe your experience with machine learning frameworks and libraries.`,
      `How do you approach model selection for a given problem?`,
      `Explain your experience with data preprocessing for machine learning.`,
      `How do you handle overfitting in machine learning models?`,
      `Describe your approach to hyperparameter tuning.`,
      `How do you deploy machine learning models to production?`,
      `Explain your approach to monitoring and maintaining machine learning models in production.`,
      `How do you handle model interpretability and explainability?`,
    ],
    "DevOps Engineer": [
      `Describe your experience with CI/CD pipelines and tools.`,
      `How do you approach infrastructure as code?`,
      `Explain your experience with containerization and orchestration.`,
      `How do you handle monitoring and logging in a DevOps environment?`,
      `Describe your approach to security in the DevOps pipeline.`,
      `How do you manage configuration across different environments?`,
      `Explain your approach to incident response and management.`,
      `How do you handle database migrations in a DevOps context?`,
    ],
    "Cloud Engineer": [
      `Describe your experience with cloud platforms (AWS, Azure, GCP).`,
      `How do you approach cloud architecture design?`,
      `Explain your experience with serverless computing.`,
      `How do you handle cloud security and compliance?`,
      `Describe your approach to cloud cost optimization.`,
      `How do you manage multi-cloud or hybrid cloud environments?`,
      `Explain your approach to disaster recovery in cloud environments.`,
      `How do you handle cloud networking and connectivity?`,
    ],
    "Mobile App Developer": [
      `Describe your experience with mobile app development frameworks and platforms.`,
      `How do you approach responsive design for different screen sizes?`,
      `Explain your experience with mobile app architecture patterns.`,
      `How do you handle offline functionality in mobile apps?`,
      `Describe your approach to mobile app performance optimization.`,
      `How do you implement testing in mobile app development?`,
      `Explain your approach to mobile app security.`,
      `How do you handle app store submissions and guidelines?`,
    ],
    "UI/UX Designer": [
      `Describe your design process from concept to final product.`,
      `How do you approach user research and persona development?`,
      `Explain your experience with design systems and component libraries.`,
      `How do you handle accessibility in your designs?`,
      `Describe your approach to usability testing.`,
      `How do you collaborate with developers to implement your designs?`,
      `Explain your approach to designing for different platforms (web, mobile, etc.).`,
      `How do you stay updated with the latest design trends and best practices?`,
    ],
  }

  // Default questions if job role not found
  const defaultQuestions = [
    `Describe your experience with technologies relevant to ${jobRole}.`,
    `How do you stay updated with the latest trends in ${jobRole}?`,
    `Explain your approach to problem-solving in your role as a ${jobRole}.`,
    `How do you handle technical challenges in your ${jobRole} projects?`,
    `Describe your experience with tools and frameworks commonly used in ${jobRole} positions.`,
    `How do you approach learning new technologies relevant to ${jobRole}?`,
    `Explain your methodology for tackling complex problems in ${jobRole} work.`,
    `How do you ensure the quality of your work as a ${jobRole}?`,
  ]

  const questions = jobSpecificQuestions[jobRole] || defaultQuestions

  // Shuffle and select the requested number of questions
  return shuffleArray(questions).slice(0, count)
}

// Helper function to shuffle an array
function shuffleArray<T>(array: T[]): T[] {
  const newArray = [...array]
  for (let i = newArray.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[newArray[i], newArray[j]] = [newArray[j], newArray[i]]
  }
  return newArray
}
