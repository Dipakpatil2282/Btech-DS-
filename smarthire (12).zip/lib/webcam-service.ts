// A dedicated service for handling webcam with better reliability

interface WebcamOptions {
  width?: number
  height?: number
  facingMode?: string
  frameRate?: number
}

interface WebcamCallbacks {
  onStart?: (stream: MediaStream) => void
  onStop?: () => void
  onError?: (error: string) => void
}

class WebcamService {
  private stream: MediaStream | null = null
  private videoElement: HTMLVideoElement | null = null
  private isActive = false
  private isInitializing = false
  private retryCount = 0
  private maxRetries = 3
  private options: WebcamOptions
  private callbacks: WebcamCallbacks

  constructor(options: WebcamOptions = {}, callbacks: WebcamCallbacks = {}) {
    this.options = {
      width: 1280,
      height: 720,
      facingMode: "user",
      frameRate: 30,
      ...options,
    }

    this.callbacks = callbacks
  }

  public async initialize(videoElement: HTMLVideoElement): Promise<boolean> {
    if (this.isInitializing) {
      console.log("Webcam is already initializing")
      return false
    }

    if (this.isActive && this.stream) {
      console.log("Webcam is already active")
      return true
    }

    this.isInitializing = true
    this.videoElement = videoElement

    try {
      // Clean up any existing stream
      await this.cleanup()

      // Request camera with specific constraints for better compatibility
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: this.options.width },
          height: { ideal: this.options.height },
          facingMode: this.options.facingMode,
          frameRate: { ideal: this.options.frameRate },
        },
      })

      // Store the stream
      this.stream = stream

      // Set video source
      if (this.videoElement) {
        this.videoElement.srcObject = stream

        // Return a promise that resolves when the video can play
        await new Promise<void>((resolve, reject) => {
          if (!this.videoElement) {
            reject(new Error("Video element is null"))
            return
          }

          const onLoadedMetadata = () => {
            if (!this.videoElement) return
            this.videoElement.removeEventListener("loadedmetadata", onLoadedMetadata)

            this.videoElement
              .play()
              .then(() => {
                console.log("Camera started successfully")
                this.isActive = true
                this.isInitializing = false
                this.retryCount = 0
                this.callbacks.onStart?.(stream)
                resolve()
              })
              .catch((error) => {
                console.error("Failed to play video:", error)
                this.isInitializing = false
                this.callbacks.onError?.(`Failed to start camera: ${error.message}`)
                reject(error)
              })
          }

          const onError = (event: Event) => {
            if (!this.videoElement) return
            this.videoElement.removeEventListener("error", onError)
            this.isInitializing = false
            this.callbacks.onError?.("Error with camera feed")
            reject(new Error("Video element error"))
          }

          this.videoElement.addEventListener("loadedmetadata", onLoadedMetadata)
          this.videoElement.addEventListener("error", onError)
        })

        return true
      } else {
        throw new Error("Video element is null")
      }
    } catch (error) {
      this.isInitializing = false
      const errorMessage = error instanceof Error ? error.message : "Unknown error"
      console.error("Failed to initialize webcam:", errorMessage)
      this.callbacks.onError?.(errorMessage)

      // Retry camera initialization with a backoff
      if (this.retryCount < this.maxRetries) {
        this.retryCount++
        const backoffTime = 2000 * this.retryCount

        console.log(`Will retry camera initialization in ${backoffTime}ms (attempt ${this.retryCount})`)

        setTimeout(() => {
          if (this.videoElement) {
            this.initialize(this.videoElement)
          }
        }, backoffTime)
      }

      return false
    }
  }

  public async cleanup(): Promise<void> {
    if (this.stream) {
      try {
        // Stop all tracks
        this.stream.getTracks().forEach((track) => {
          try {
            track.stop()
          } catch (e) {
            console.warn("Error stopping track:", e)
          }
        })
      } catch (e) {
        console.warn("Error cleaning up camera stream:", e)
      }
      this.stream = null
    }

    // Clear video source
    if (this.videoElement && this.videoElement.srcObject) {
      try {
        this.videoElement.srcObject = null
      } catch (e) {
        console.warn("Error clearing video source:", e)
      }
    }

    this.isActive = false
    this.callbacks.onStop?.()
  }

  public isInitialized(): boolean {
    return this.isActive && !!this.stream
  }

  public getStream(): MediaStream | null {
    return this.stream
  }

  public async refresh(): Promise<boolean> {
    if (this.videoElement) {
      return this.initialize(this.videoElement)
    }
    return false
  }
}

// Create a singleton instance
let webcamServiceInstance: WebcamService | null = null

export function getWebcamService(options?: WebcamOptions, callbacks?: WebcamCallbacks): WebcamService {
  if (!webcamServiceInstance) {
    webcamServiceInstance = new WebcamService(options, callbacks)
  } else if (options || callbacks) {
    // Update options and callbacks if provided
    webcamServiceInstance.cleanup()
    webcamServiceInstance = new WebcamService(options, callbacks)
  }

  return webcamServiceInstance
}
