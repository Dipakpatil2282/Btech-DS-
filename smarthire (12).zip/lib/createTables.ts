import { supabase } from "./supabase"

export async function createProfilesTable() {
  try {
    console.log("Checking if profiles table exists...")

    // First check if we're online at all
    if (typeof window !== "undefined" && !navigator.onLine) {
      console.warn("Browser is offline, skipping database operations")
      return {
        success: false,
        error: new Error("You are offline. Database operations will resume when you're back online."),
        offline: true,
      }
    }

    // Add timeout to the fetch request
    const fetchWithTimeout = async (url: string, options: any, timeout = 5000) => {
      const controller = new AbortController()
      const id = setTimeout(() => controller.abort(), timeout)

      try {
        const response = await fetch(url, {
          ...options,
          signal: controller.signal,
        })
        clearTimeout(id)
        return response
      } catch (error) {
        clearTimeout(id)
        throw error
      }
    }

    // Try to check if the table exists with a timeout
    try {
      // Use a simple query with AbortController for timeout
      const controller = new AbortController()
      const timeoutId = setTimeout(() => controller.abort(), 5000) // 5 second timeout

      const { data, error } = await supabase
        .from("profiles")
        .select("count", { count: "exact", head: true })
        .limit(1)
        .abortSignal(controller.signal)

      clearTimeout(timeoutId)

      // If we can query the table, it exists
      if (!error) {
        console.log("Profiles table exists and is accessible")
        return { success: true, error: null }
      }

      // If error is not a "relation does not exist" error, then we have other issues
      if (error && !error.message.includes('relation "profiles" does not exist')) {
        if (error.message.includes("Failed to fetch") || error.code === "NETWORK_ERROR") {
          console.warn("Network error when checking profiles table:", error)
          return {
            success: false,
            error: new Error("Unable to connect to the database. Please check your internet connection."),
            networkError: true,
          }
        }

        console.error("Error accessing profiles table:", error)
        return { success: false, error }
      }
    } catch (error: any) {
      if (error.name === "AbortError" || error.message?.includes("fetch")) {
        console.warn("Network timeout when checking profiles table:", error)
        return {
          success: false,
          error: new Error("Database connection timed out. Please try again later."),
          networkError: true,
        }
      }

      console.error("Error checking profiles table:", error)
      // Continue to try creating the table, but with a more graceful fallback
    }

    console.log("Attempting to create profiles table...")

    // Call our API route to create the table
    try {
      const response = await fetchWithTimeout(
        "/api/create-tables",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
        },
        10000,
      ) // 10 second timeout

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Failed to create tables")
      }

      const result = await response.json()

      if (result.success) {
        console.log("Tables created successfully via API")
        return { success: true, error: null }
      } else {
        throw new Error(result.error || "Unknown error creating tables")
      }
    } catch (error: any) {
      // Check if it's a network error
      if (error.message?.includes("Failed to fetch") || error.name === "AbortError") {
        console.warn("Network error when creating tables:", error)
        return {
          success: false,
          error: new Error(
            "Unable to connect to the database. The app will continue to work with limited functionality.",
          ),
          networkError: true,
        }
      }

      console.error("Error calling create-tables API:", error)

      // Try direct SQL as a fallback - but skip this if it's a network error
      if (!error.message?.includes("Failed to fetch") && !error.name?.includes("AbortError")) {
        try {
          // Create a simple table with minimal fields
          const { error: createError } = await supabase
            .from("profiles")
            .insert({
              user_id: "00000000-0000-0000-0000-000000000000", // Dummy UUID
              name: "System",
              email: "system@example.com",
            })
            .select()

          if (!createError || createError.message.includes("duplicate key")) {
            // If insert worked or failed due to duplicate key, table exists
            console.log("Profiles table exists or was created successfully")
            return { success: true, error: null }
          }

          console.error("Error creating profiles table:", createError)
          return { success: false, error: createError }
        } catch (error) {
          console.error("Error in direct SQL fallback:", error)
          return { success: false, error }
        }
      }

      // Return a user-friendly error for network issues
      return {
        success: false,
        error: new Error(
          "Unable to connect to the database. The app will continue to work with limited functionality.",
        ),
        networkError: true,
      }
    }
  } catch (error) {
    console.error("Error in createProfilesTable function:", error)
    // Return a more user-friendly error
    return {
      success: false,
      error: new Error("Unable to access database. You can continue using the app, but some features may be limited."),
    }
  }
}

export async function createInterviewResultsTable() {
  try {
    console.log("Checking if interview_results table exists...")

    // First check if we can access the table
    try {
      const { data, error } = await supabase
        .from("interview_results")
        .select("count", { count: "exact", head: true })
        .limit(1)

      // If we can query the table, it exists
      if (!error) {
        console.log("Interview results table exists and is accessible")
        return { success: true, error: null }
      }

      // If error is not a "relation does not exist" error, then we have other issues
      if (error && !error.message.includes('relation "interview_results" does not exist')) {
        console.error("Error accessing interview_results table:", error)
        return { success: false, error }
      }
    } catch (error) {
      console.error("Error checking interview_results table:", error)
      // Continue to try creating the table
    }

    console.log("Attempting to create interview_results table...")

    // Call our API route to create the table
    try {
      const controller = new AbortController()
      const timeoutId = setTimeout(() => controller.abort(), 10000) // 10 second timeout

      const response = await fetch("/api/create-tables", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        signal: controller.signal,
      })

      clearTimeout(timeoutId)

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Failed to create tables")
      }

      const result = await response.json()

      if (result.success) {
        console.log("Tables created successfully via API")
        return { success: true, error: null }
      } else {
        throw new Error(result.error || "Unknown error creating tables")
      }
    } catch (error) {
      console.error("Error calling create-tables API:", error)

      // Try direct SQL as a fallback
      try {
        // Create a simple table with minimal fields
        const { error: createError } = await supabase
          .from("interview_results")
          .insert({
            user_id: "00000000-0000-0000-0000-000000000000", // Dummy UUID
            job_role: "System Test",
            level: "beginner",
            score: 0,
            relevance_score: 0,
            communication_score: 0,
            behavior_score: 0,
            coding_score: 0,
          })
          .select()

        if (!createError || createError.message.includes("duplicate key")) {
          // If insert worked or failed due to duplicate key, table exists
          console.log("Interview results table exists or was created successfully")
          return { success: true, error: null }
        }

        console.error("Error creating interview_results table:", createError)
        return { success: false, error: createError }
      } catch (error) {
        console.error("Error in direct SQL fallback:", error)
        return { success: false, error }
      }
    }
  } catch (error) {
    console.error("Error in createInterviewResultsTable function:", error)
    return { success: false, error }
  }
}
