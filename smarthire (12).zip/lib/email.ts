import { supabase } from "./supabase"

export async function sendEmail(to: string, subject: string, htmlContent: string) {
  try {
    // Log the email attempt
    console.log(`Attempting to send email to ${to} with subject: ${subject}`)

    // Store the email in the database for tracking
    const { data, error } = await supabase
      .from("email_logs")
      .insert({
        recipient: to,
        subject,
        content: htmlContent,
        status: "pending",
        created_at: new Date().toISOString(),
      })
      .select()

    if (error) {
      console.error("Error logging email:", error)
      return { success: false, error: "Failed to log email" }
    }

    const emailId = data?.[0]?.id

    // For now, we'll just log the email content since we don't have a real email service
    console.log("Email content:", htmlContent)
    console.log("Email would be sent to:", to)

    // Update the email log to show it was "sent" (for testing)
    await supabase.from("email_logs").update({ status: "sent", sent_at: new Date().toISOString() }).eq("id", emailId)

    return { success: true, emailId }
  } catch (error) {
    console.error("Error in sendEmail function:", error)
    return { success: false, error: "Email sending failed" }
  }
}
