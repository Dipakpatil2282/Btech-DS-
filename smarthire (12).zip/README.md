# SmartHire AI Interview Platform

SmartHire is an AI-powered interview platform that helps candidates practice and improve their interview skills.

## Features

- AI-powered interview simulations
- Real-time speech recognition
- Screen recording for interview review
- Performance analysis and feedback
- Interview scheduling
- User profile management

## Tech Stack

- Next.js 14
- TypeScript
- Tailwind CSS
- Supabase (Auth, Database)
- React Hooks

## Deployment Guide

### Prerequisites

1. A Supabase account and project
2. A Vercel account (recommended for deployment)
3. Node.js 18+ installed locally for development

### Environment Variables

Create a `.env.local` file with the following variables:
