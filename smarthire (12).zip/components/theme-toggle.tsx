"use client"

import { Moon, Sun } from "lucide-react"
import { useTheme } from "next-themes"
import { Button } from "@/components/ui/button"
import { useEffect, useState } from "react"

export function ThemeToggle() {
  // Use a state to track if component is mounted
  const [mounted, setMounted] = useState(false)

  // Get theme from next-themes
  const { resolvedTheme, setTheme } = useTheme()

  // Set mounted to true after component mounts
  useEffect(() => {
    setMounted(true)
  }, [])

  // Handle theme toggle
  const toggleTheme = () => {
    if (resolvedTheme === "dark") {
      setTheme("light")
    } else {
      setTheme("dark")
    }
  }

  // Return placeholder during SSR
  if (!mounted) {
    return (
      <Button variant="outline" size="icon" className="border-border text-foreground hover:bg-accent">
        <span className="sr-only">Toggle theme</span>
      </Button>
    )
  }

  // Return actual button after mounting
  return (
    <Button
      variant="outline"
      size="icon"
      onClick={toggleTheme}
      className="border-border text-foreground hover:bg-accent"
    >
      {resolvedTheme === "dark" ? (
        <Sun className="h-[1.2rem] w-[1.2rem]" />
      ) : (
        <Moon className="h-[1.2rem] w-[1.2rem]" />
      )}
      <span className="sr-only">Toggle theme</span>
    </Button>
  )
}
