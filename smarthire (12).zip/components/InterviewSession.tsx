"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { questions } from "@/lib/questions"
import {
  Mic,
  MicOff,
  AlertTriangle,
  Volume2,
  Camera,
  Clock,
  ArrowLeft,
  ArrowRight,
  Send,
  RefreshCw,
  WifiOff,
  Video,
  Loader2,
} from "lucide-react"
import PerformanceAnalysis from "./PerformanceAnalysis"
import { generateRelevantQuestions, analyzeAnswer } from "@/lib/gemini-api"
import CodeEditor from "./CodeEditor"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Brain } from "lucide-react"
import { createSpeechRecognition } from "@/lib/speech-recognition"

interface InterviewSessionProps {
  jobRole: string
  level: "beginner" | "intermediate" | "advanced"
  onAbort: () => void
}

export default function InterviewSession({ jobRole, level, onAbort }: InterviewSessionProps) {
  // Static state that doesn't change during component lifecycle
  const [initialState] = useState(() => ({
    jobRole,
    level,
  }))

  // Component state
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [timeLeft, setTimeLeft] = useState(20 * 60) // 20 minutes in seconds
  const [dynamicQuestions, setDynamicQuestions] = useState<string[]>([])
  const [isLoadingQuestions, setIsLoadingQuestions] = useState(true)
  const [answers, setAnswers] = useState<string[]>([])
  const [scores, setScores] = useState<number[]>([])
  const [isRecording, setIsRecording] = useState(false)
  const [isInitializingRecording, setIsInitializingRecording] = useState(false)
  const [tabSwitchCount, setTabSwitchCount] = useState(0)
  const [showTabWarning, setShowTabWarning] = useState(false)
  const [isInterviewCompleted, setIsInterviewCompleted] = useState(false)
  const [isSpeaking, setIsSpeaking] = useState(false)
  const [answerError, setAnswerError] = useState<string | null>(null)
  const [showScreenshotWarning, setShowScreenshotWarning] = useState(false)
  const [showConfirmSubmit, setShowConfirmSubmit] = useState(false)
  const [permissionsGranted, setPermissionsGranted] = useState(false)
  const [checkingPermissions, setCheckingPermissions] = useState(true)
  const [permissionError, setPermissionError] = useState<string | null>(null)
  const [interimTranscript, setInterimTranscript] = useState("")
  const [cameraActive, setCameraActive] = useState(false)
  const [cameraLoading, setCameraLoading] = useState(false)
  const [speechRecognitionSupported, setSpeechRecognitionSupported] = useState(true)
  const [networkStatus, setNetworkStatus] = useState<"online" | "offline" | "unstable">("online")
  const [showNetworkWarning, setShowNetworkWarning] = useState(false)
  const [permissionChangeDetected, setPermissionChangeDetected] = useState(false)
  const [showPermissionChangeWarning, setShowPermissionChangeWarning] = useState(false)
  const [browserCompatibilityIssue, setBrowserCompatibilityIssue] = useState(false)
  const [isScreenRecording, setIsScreenRecording] = useState(false)
  const [recordedChunks, setRecordedChunks] = useState<BlobPart[]>([])
  const [recordingUrl, setRecordingUrl] = useState<string | null>(null)
  const [screenRecordingRequested, setScreenRecordingRequested] = useState(false)
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([])
  const [selectedVoice, setSelectedVoice] = useState<SpeechSynthesisVoice | null>(null)
  const [recordingDuration, setRecordingDuration] = useState(0)
  const [recordingWithAudio, setRecordingWithAudio] = useState(true)

  // Refs for values that shouldn't trigger re-renders
  const videoRef = useRef<HTMLVideoElement>(null)
  const textareaRef = useRef<HTMLTextAreaElement>(null)
  const synthRef = useRef<SpeechSynthesis | null>(null)
  const screenshotCountRef = useRef(0)
  const questionsLoadedRef = useRef(false)
  const answersInitializedRef = useRef(false)
  const timerRef = useRef<NodeJS.Timeout | null>(null)
  const recordingTimerRef = useRef<NodeJS.Timeout | null>(null)
  const recordingStartTimeRef = useRef<number | null>(null)
  const cameraStreamRef = useRef<MediaStream | null>(null)
  const microphoneStreamRef = useRef<MediaStream | null>(null)
  const geminiApiKeyRef = useRef("AIzaSyAst5EV-cLw47GDcu_lUnwT5YeXO-ilrE8")
  const networkCheckIntervalRef = useRef<NodeJS.Timeout | null>(null)
  const permissionCheckIntervalRef = useRef<NodeJS.Timeout | null>(null)
  const lastNetworkStatusRef = useRef<"online" | "offline" | "unstable">("online")
  const lastPermissionStatusRef = useRef<{ camera: boolean; microphone: boolean }>({ camera: false, microphone: false })
  const answerSaveIntervalRef = useRef<NodeJS.Timeout | null>(null)
  const answerBackupRef = useRef<string[]>([])
  const isComponentMountedRef = useRef(true)
  const mediaRecorderRef = useRef<MediaRecorder | null>(null)
  const browserInfoRef = useRef({
    name: "",
    version: "",
    isMobile: false,
    isCompatible: true,
  })
  const voicesLoadedRef = useRef(false)
  const cameraRetryCountRef = useRef(0)
  const speechRecognitionRef = useRef<any>(null)
  const currentQuestionRef = useRef<number>(0)

  // Detect browser info on mount
  useEffect(() => {
    const ua = navigator.userAgent
    const browserInfo = {
      name: "",
      version: "",
      isMobile: /Mobi|Android/i.test(ua),
      isCompatible: true,
    }

    // Detect browser
    if (ua.indexOf("Chrome") !== -1) {
      browserInfo.name = "Chrome"
      browserInfo.version = ua.match(/Chrome\/(\d+)/)?.[1] || ""
    } else if (ua.indexOf("Firefox") !== -1) {
      browserInfo.name = "Firefox"
      browserInfo.version = ua.match(/Firefox\/(\d+)/)?.[1] || ""
    } else if (ua.indexOf("Safari") !== -1) {
      browserInfo.name = "Safari"
      browserInfo.version = ua.match(/Version\/(\d+)/)?.[1] || ""
    } else if (ua.indexOf("Edge") !== -1 || ua.indexOf("Edg") !== -1) {
      browserInfo.name = "Edge"
      const edgeMatch = ua.match(/Edge\/(\d+)/) || ua.match(/Edg\/(\d+)/)
      browserInfo.version = edgeMatch?.[1] || ""
    } else if (ua.indexOf("MSIE") !== -1 || ua.indexOf("Trident") !== -1) {
      browserInfo.name = "Internet Explorer"
      browserInfo.isCompatible = false
    }

    // Check compatibility
    if (browserInfo.name === "Chrome" && Number.parseInt(browserInfo.version) < 60) {
      browserInfo.isCompatible = false
    } else if (browserInfo.name === "Firefox" && Number.parseInt(browserInfo.version) < 60) {
      browserInfo.isCompatible = false
    } else if (browserInfo.name === "Safari" && Number.parseInt(browserInfo.version) < 13) {
      browserInfo.isCompatible = false
    } else if (browserInfo.name === "Edge" && Number.parseInt(browserInfo.version) < 79) {
      browserInfo.isCompatible = false
    }

    browserInfoRef.current = browserInfo

    if (!browserInfo.isCompatible) {
      setBrowserCompatibilityIssue(true)
    }
  }, [])

  // Initialize speech synthesis and load voices
  useEffect(() => {
    if (typeof window === "undefined" || !window.speechSynthesis) return

    synthRef.current = window.speechSynthesis

    // Function to load and process voices
    const loadVoices = () => {
      if (voicesLoadedRef.current) return

      const voices = synthRef.current?.getVoices() || []

      if (voices.length > 0) {
        setAvailableVoices(voices)
        voicesLoadedRef.current = true

        // Find Indian female voice or closest alternative
        let indianFemaleVoice = voices.find(
          (voice) =>
            (voice.lang.includes("hi-IN") || voice.lang.includes("en-IN")) &&
            voice.name.toLowerCase().includes("female"),
        )

        // If no specific Indian female voice, try to find any Indian voice
        if (!indianFemaleVoice) {
          indianFemaleVoice = voices.find((voice) => voice.lang.includes("hi-IN") || voice.lang.includes("en-IN"))
        }

        // If still no match, try to find any female voice
        if (!indianFemaleVoice) {
          indianFemaleVoice = voices.find(
            (voice) =>
              voice.name.toLowerCase().includes("female") && (voice.lang.includes("en") || voice.lang.includes("hi")),
          )
        }

        // If still no match, use any English voice
        if (!indianFemaleVoice) {
          indianFemaleVoice = voices.find((voice) => voice.lang.includes("en"))
        }

        if (indianFemaleVoice) {
          setSelectedVoice(indianFemaleVoice)
          console.log("Selected voice:", indianFemaleVoice.name, indianFemaleVoice.lang)
        } else {
          console.warn("No suitable voice found, using default")
        }
      }
    }

    // Load voices immediately if available
    loadVoices()

    // Set up event listener for when voices are loaded
    window.speechSynthesis.onvoiceschanged = loadVoices

    // Clean up
    return () => {
      window.speechSynthesis.onvoiceschanged = null
    }
  }, [])

  // Component mount/unmount tracking
  useEffect(() => {
    isComponentMountedRef.current = true
    currentQuestionRef.current = currentQuestionIndex

    return () => {
      isComponentMountedRef.current = false

      // Clean up speech recognition
      if (speechRecognitionRef.current) {
        speechRecognitionRef.current.destroy()
        speechRecognitionRef.current = null
      }

      // Clean up camera stream
      if (cameraStreamRef.current) {
        cameraStreamRef.current.getTracks().forEach((track) => track.stop())
        cameraStreamRef.current = null
      }

      // Clean up microphone stream
      if (microphoneStreamRef.current) {
        microphoneStreamRef.current.getTracks().forEach((track) => track.stop())
        microphoneStreamRef.current = null
      }
    }
  }, [])

  // Update current question ref when the index changes
  useEffect(() => {
    currentQuestionRef.current = currentQuestionIndex
  }, [currentQuestionIndex])

  // Set up automatic answer backup
  useEffect(() => {
    // Save answers to localStorage every 10 seconds as backup
    answerSaveIntervalRef.current = setInterval(() => {
      if (answers.length > 0) {
        try {
          localStorage.setItem("interview_answers_backup", JSON.stringify(answers))
          answerBackupRef.current = [...answers]
        } catch (error) {
          console.warn("Failed to save answers to localStorage:", error)
        }
      }
    }, 10000)

    // Try to restore answers from backup if available
    try {
      const savedAnswers = localStorage.getItem("interview_answers_backup")
      if (savedAnswers) {
        answerBackupRef.current = JSON.parse(savedAnswers)
      }
    } catch (error) {
      console.warn("Failed to restore answers from localStorage:", error)
    }

    return () => {
      if (answerSaveIntervalRef.current) {
        clearInterval(answerSaveIntervalRef.current)
      }
    }
  }, [])

  // Network status monitoring
  useEffect(() => {
    const checkNetworkStatus = async () => {
      const online = navigator.onLine

      if (!online) {
        setNetworkStatus("offline")
        lastNetworkStatusRef.current = "offline"
        setShowNetworkWarning(true)
        return
      }

      // Check if we can reach our API endpoint
      try {
        const response = await fetch("/api/health-check", { method: "HEAD" })
        if (!response.ok) {
          setNetworkStatus("unstable")
          lastNetworkStatusRef.current = "unstable"
          setShowNetworkWarning(true)
        } else {
          // Only update if there was a change to avoid unnecessary re-renders
          if (lastNetworkStatusRef.current !== "online") {
            setNetworkStatus("online")
            lastNetworkStatusRef.current = "online"
            setShowNetworkWarning(false)
          }
        }
      } catch (error) {
        setNetworkStatus("unstable")
        lastNetworkStatusRef.current = "unstable"
        setShowNetworkWarning(true)
      }
    }

    // Check network status immediately
    checkNetworkStatus()

    // Set up event listeners for online/offline events
    const handleOnline = () => {
      setNetworkStatus("online")
      lastNetworkStatusRef.current = "online"
      setShowNetworkWarning(false)
    }

    const handleOffline = () => {
      setNetworkStatus("offline")
      lastNetworkStatusRef.current = "offline"
      setShowNetworkWarning(true)
    }

    window.addEventListener("online", handleOnline)
    window.addEventListener("offline", handleOffline)

    // Set up interval to check network status
    networkCheckIntervalRef.current = setInterval(checkNetworkStatus, 30000)

    return () => {
      window.removeEventListener("online", handleOnline)
      window.removeEventListener("offline", handleOffline)

      if (networkCheckIntervalRef.current) {
        clearInterval(networkCheckIntervalRef.current)
      }
    }
  }, [])

  // Permission change monitoring
  useEffect(() => {
    const checkPermissionChanges = async () => {
      if (!permissionsGranted) return

      try {
        // Check camera permission
        let cameraPermission = false
        try {
          const status = await navigator.permissions.query({ name: "camera" as PermissionName })
          cameraPermission = status.state === "granted"
        } catch (error) {
          // Some browsers don't support permission queries
          cameraPermission = !!cameraStreamRef.current
        }

        // Check microphone permission
        let microphonePermission = false
        try {
          const status = await navigator.permissions.query({ name: "microphone" as PermissionName })
          microphonePermission = status.state === "granted"
        } catch (error) {
          // Some browsers don't support permission queries
          microphonePermission = isRecording || speechRecognitionSupported
        }

        // Check if permissions changed
        if (
          lastPermissionStatusRef.current.camera !== cameraPermission ||
          lastPermissionStatusRef.current.microphone !== microphonePermission
        ) {
          // Update last status
          lastPermissionStatusRef.current = {
            camera: cameraPermission,
            microphone: microphonePermission,
          }

          // If permissions were revoked
          if (!cameraPermission || !microphonePermission) {
            setPermissionChangeDetected(true)
            setShowPermissionChangeWarning(true)

            // Try to recover camera if it was disconnected
            if (!cameraPermission && cameraStreamRef.current === null) {
              refreshCamera()
            }
          }
        }
      } catch (error) {
        console.warn("Error checking permission changes:", error)
      }
    }

    // Check permission changes every 10 seconds
    permissionCheckIntervalRef.current = setInterval(checkPermissionChanges, 10000)

    return () => {
      if (permissionCheckIntervalRef.current) {
        clearInterval(permissionCheckIntervalRef.current)
      }
    }
  }, [permissionsGranted, isRecording, speechRecognitionSupported])

  const handleError = (error: any, context: string, fallbackMessage: string) => {
    console.error(`Error in ${context}:`, error)

    // Extract meaningful error message
    let errorMessage = fallbackMessage
    if (error instanceof Error) {
      errorMessage = error.message
    } else if (typeof error === "string") {
      errorMessage = error
    } else if (error && typeof error === "object" && "message" in error) {
      errorMessage = String(error.message)
    }

    // Set appropriate error state based on context
    if (context.includes("speech") || context.includes("recording")) {
      setAnswerError(`${fallbackMessage}: ${errorMessage}`)
    } else if (context.includes("camera") || context.includes("video")) {
      setPermissionError(`${fallbackMessage}: ${errorMessage}`)

      // Try to recover camera
      setTimeout(() => {
        if (isComponentMountedRef.current) {
          refreshCamera()
        }
      }, 3000)
    } else if (context.includes("network")) {
      // Handle network errors
      setNetworkStatus("unstable")
      setShowNetworkWarning(true)
    } else {
      // General error handling
      setAnswerError(fallbackMessage)
      console.warn(`Unhandled error in ${context}:`, errorMessage)
    }

    return errorMessage
  }

  // Initialize camera - completely rewritten for reliability
  const initializeCamera = async () => {
    try {
      // Update UI state
      setCameraLoading(true)
      setCameraActive(false)

      // Clean up any existing camera stream
      if (cameraStreamRef.current) {
        cameraStreamRef.current.getTracks().forEach((track) => track.stop())
        cameraStreamRef.current = null
      }

      // Clear video source
      if (videoRef.current && videoRef.current.srcObject) {
        videoRef.current.srcObject = null
      }

      console.log("Requesting camera access...")

      // Request camera with specific constraints for better compatibility
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 1280 },
          height: { ideal: 720 },
          facingMode: "user",
        },
        audio: false,
      })

      console.log("Camera access granted, tracks:", stream.getVideoTracks().length)

      // Check if we actually got video tracks
      if (stream.getVideoTracks().length === 0) {
        throw new Error("No video tracks found in camera stream")
      }

      // Store the stream
      cameraStreamRef.current = stream

      // Set video source directly
      if (videoRef.current) {
        // Ensure video element is properly set up
        videoRef.current.autoplay = true
        videoRef.current.playsInline = true
        videoRef.current.muted = true
        videoRef.current.style.display = "block"
        videoRef.current.style.width = "100%"
        videoRef.current.style.height = "100%"
        videoRef.current.style.objectFit = "cover"

        // Set the stream as source
        videoRef.current.srcObject = stream

        console.log("Video source set, attempting to play...")

        // Force play immediately
        try {
          await videoRef.current.play()
          console.log("Camera started successfully")
          setCameraActive(true)
          setCameraLoading(false)

          // Make sure video is visible
          if (videoRef.current.style.display === "none") {
            videoRef.current.style.display = "block"
          }

          // Log video element dimensions
          console.log(`Video element dimensions: ${videoRef.current.offsetWidth}x${videoRef.current.offsetHeight}`)
        } catch (e) {
          console.error("Failed to play video:", e)

          // Try again after a short delay
          setTimeout(async () => {
            if (videoRef.current && isComponentMountedRef.current) {
              try {
                console.log("Second attempt to play video...")
                await videoRef.current.play()
                console.log("Camera started on second attempt")
                setCameraActive(true)
                setCameraLoading(false)
              } catch (err) {
                console.error("Failed on second attempt:", err)
                setCameraLoading(false)
              }
            }
          }, 500)
        }
      } else {
        throw new Error("Video element not found")
      }

      return true
    } catch (error) {
      console.error("Camera initialization error:", error)
      setCameraLoading(false)
      return false
    }
  }

  // Initialize microphone for recording
  const initializeMicrophone = async () => {
    try {
      // Clean up any existing microphone stream
      if (microphoneStreamRef.current) {
        microphoneStreamRef.current.getTracks().forEach((track) => track.stop())
        microphoneStreamRef.current = null
      }

      console.log("Requesting microphone access for recording...")

      // Request microphone with quality settings
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      })

      console.log("Microphone access granted for recording")
      microphoneStreamRef.current = stream
      return true
    } catch (error) {
      console.error("Microphone initialization error:", error)
      return false
    }
  }

  // Enable camera button handler
  const handleEnableCamera = async () => {
    setCameraLoading(true)
    await initializeCamera()
  }

  // Start screen recording with audio
  const startScreenRecording = async () => {
    if (isScreenRecording || screenRecordingRequested) {
      console.log("Screen recording already active or requested")
      return
    }

    try {
      setScreenRecordingRequested(true)
      console.log("Requesting screen recording permission")

      // First get display media (screen)
      const displayStream = await navigator.mediaDevices.getDisplayMedia({
        video: {
          displaySurface: "window",
          frameRate: { ideal: 30 },
        },
        audio: false, // We'll handle audio separately for better control
      })

      // If we want audio, initialize the microphone
      let combinedStream = displayStream
      if (recordingWithAudio) {
        const micSuccess = await initializeMicrophone()
        if (micSuccess && microphoneStreamRef.current) {
          // Create a combined stream with both screen video and microphone audio
          const audioTracks = microphoneStreamRef.current.getAudioTracks()
          if (audioTracks.length > 0) {
            // Combine the tracks into a single stream
            const videoTracks = displayStream.getVideoTracks()
            combinedStream = new MediaStream([...videoTracks, ...audioTracks])
            console.log("Created combined stream with video and audio tracks")
          }
        } else {
          console.warn("Could not initialize microphone for recording, proceeding with video only")
        }
      }

      console.log("Screen recording permission granted")
      setIsScreenRecording(true)

      // Create media recorder with best available options
      const mimeType = MediaRecorder.isTypeSupported("video/webm;codecs=vp9")
        ? "video/webm;codecs=vp9"
        : MediaRecorder.isTypeSupported("video/webm")
          ? "video/webm"
          : "video/mp4"

      const options = {
        mimeType: mimeType,
        videoBitsPerSecond: 3000000, // 3 Mbps for better quality
      }

      mediaRecorderRef.current = new MediaRecorder(combinedStream, options)

      // Handle data available event
      mediaRecorderRef.current.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          setRecordedChunks((prev) => [...prev, event.data])
        }
      }

      // Handle stop event
      mediaRecorderRef.current.onstop = () => {
        console.log("Screen recording stopped")
        setIsScreenRecording(false)

        // Stop all tracks
        combinedStream.getTracks().forEach((track) => track.stop())

        // Also stop microphone stream if it exists
        if (microphoneStreamRef.current) {
          microphoneStreamRef.current.getTracks().forEach((track) => track.stop())
        }

        // Process the recording immediately
        if (recordedChunks.length > 0) {
          try {
            console.log(`Processing ${recordedChunks.length} recorded chunks after stop`)
            const blob = new Blob(recordedChunks, {
              type: mimeType,
            })
            const url = URL.createObjectURL(blob)
            setRecordingUrl(url)
            console.log("Recording URL created:", url)
          } catch (error) {
            console.error("Error processing recorded chunks:", error)
          }
        }
      }

      // Start recording with a reasonable timeslice
      mediaRecorderRef.current.start(1000) // Capture in 1-second chunks
      console.log("Screen recording started")

      // Add event listener for when user stops sharing
      const videoTracks = displayStream.getVideoTracks()
      if (videoTracks.length > 0) {
        const track = videoTracks[0]
        track.onended = () => {
          console.log("User stopped sharing screen")
          if (mediaRecorderRef.current && mediaRecorderRef.current.state === "recording") {
            mediaRecorderRef.current.stop()
          }
        }
      }
    } catch (error) {
      console.log("Screen recording permission denied or error:", error)
      setIsScreenRecording(false)
      setScreenRecordingRequested(true) // Still mark as requested to avoid asking again
    }
  }

  // Stop screen recording
  const stopScreenRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === "recording") {
      console.log("Stopping screen recording")
      mediaRecorderRef.current.stop()
    }
  }

  // Process recorded chunks
  useEffect(() => {
    if (recordedChunks.length > 0 && !isScreenRecording) {
      try {
        console.log(`Processing ${recordedChunks.length} recorded chunks`)
        const blob = new Blob(recordedChunks, {
          type: "video/webm",
        })
        const url = URL.createObjectURL(blob)
        setRecordingUrl(url)

        // Save recording to IndexedDB for recovery
        try {
          const request = indexedDB.open("InterviewRecordings", 1)

          request.onupgradeneeded = () => {
            const db = request.result
            if (!db.objectStoreNames.contains("recordings")) {
              db.createObjectStore("recordings", { keyPath: "id" })
            }
          }

          request.onsuccess = () => {
            const db = request.result
            const transaction = db.transaction(["recordings"], "readwrite")
            const store = transaction.objectStore("recordings")

            store.put({
              id: "current_recording",
              blob: blob,
              timestamp: Date.now(),
            })
          }
        } catch (error) {
          console.warn("Failed to save recording to IndexedDB:", error)
        }
      } catch (error) {
        console.error("Error processing recorded chunks:", error)
      }
    }
  }, [recordedChunks, isScreenRecording])

  // Check permissions first
  useEffect(() => {
    const checkPermissions = async () => {
      try {
        setCheckingPermissions(true)
        setPermissionError(null)

        // Check if browser supports required APIs
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
          setPermissionError(
            "Your browser doesn't support media devices. Please use a modern browser like Chrome, Firefox, or Edge.",
          )
          setPermissionsGranted(false)
          setCheckingPermissions(false)
          setBrowserCompatibilityIssue(true)
          return
        }

        // Check if speech recognition is supported
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
        if (!SpeechRecognition) {
          console.warn("Speech recognition not supported in this browser")
          setSpeechRecognitionSupported(false)
          setPermissionError(
            "Your browser doesn't support speech recognition. Please use Chrome for the best experience.",
          )
          setPermissionsGranted(false)
          setCheckingPermissions(false)
          setBrowserCompatibilityIssue(true)
          return
        }

        // Check camera permission
        let cameraPermission
        try {
          cameraPermission = await navigator.permissions.query({ name: "camera" as PermissionName })
        } catch (error) {
          console.warn("Camera permission query not supported, will try direct access:", error)
          // Some browsers don't support permission queries, we'll try direct access later
        }

        // Check microphone permission
        let micPermission
        try {
          micPermission = await navigator.permissions.query({ name: "microphone" as PermissionName })
        } catch (error) {
          console.warn("Microphone permission query not supported, will try direct access:", error)
          // Some browsers don't support permission queries, we'll try direct access later
        }

        // If permissions are explicitly denied
        if (
          (cameraPermission && cameraPermission.state === "denied") ||
          (micPermission && micPermission.state === "denied")
        ) {
          setPermissionError(
            "Camera and/or microphone permissions are denied. Please allow access in your browser settings and refresh the page.",
          )
          setPermissionsGranted(false)
          setCheckingPermissions(false)
          return
        }

        // Request permissions directly
        try {
          // Request microphone
          const micStream = await navigator.mediaDevices.getUserMedia({
            audio: {
              echoCancellation: true,
              noiseSuppression: true,
              autoGainControl: true,
            },
          })

          // Stop the mic stream as we'll use it later with speech recognition
          micStream.getTracks().forEach((track) => track.stop())

          // Update permission status
          lastPermissionStatusRef.current.microphone = true

          // Initialize camera
          const cameraSuccess = await initializeCamera()

          if (cameraSuccess) {
            lastPermissionStatusRef.current.camera = true
          }

          // We don't need screen recording permission anymore
          setPermissionsGranted(true)
          setCheckingPermissions(false)
        } catch (error) {
          console.error("Error requesting permissions:", error)
          setPermissionError(
            `Failed to access required devices: ${error instanceof Error ? error.message : "Unknown error"}. Please ensure permissions are granted and try again.`,
          )
          setPermissionsGranted(false)
          setCheckingPermissions(false)
        }
      } catch (error) {
        console.error("Error in permission checking process:", error)
        setPermissionError(
          "An error occurred while checking permissions. Please ensure your browser supports camera and microphone access.",
        )
        setPermissionsGranted(false)
        setCheckingPermissions(false)
      }
    }

    checkPermissions()

    return () => {
      // Clean up camera stream if component unmounts
      if (cameraStreamRef.current) {
        cameraStreamRef.current.getTracks().forEach((track) => track.stop())
        cameraStreamRef.current = null
      }

      // Clean up microphone stream
      if (microphoneStreamRef.current) {
        microphoneStreamRef.current.getTracks().forEach((track) => track.stop())
        microphoneStreamRef.current = null
      }

      // Clean up screen recording
      if (mediaRecorderRef.current && mediaRecorderRef.current.state === "recording") {
        stopScreenRecording()
      }

      // Clean up recording URL
      if (recordingUrl) {
        URL.revokeObjectURL(recordingUrl)
      }

      // Clean up recording timer
      if (recordingTimerRef.current) {
        clearInterval(recordingTimerRef.current)
      }
    }
  }, [])

  // Add camera refresh button functionality
  const refreshCamera = async () => {
    console.log("Refreshing camera...")

    // First, ensure any existing streams are properly cleaned up
    if (cameraStreamRef.current) {
      console.log("Stopping existing camera tracks")
      cameraStreamRef.current.getTracks().forEach((track) => {
        track.stop()
      })
      cameraStreamRef.current = null
    }

    // Clear the video element
    if (videoRef.current) {
      videoRef.current.srcObject = null
      videoRef.current.style.display = "block" // Ensure video is visible
    }

    // Reset states
    setCameraActive(false)
    setCameraLoading(true)

    // Short delay before reinitializing
    setTimeout(() => {
      if (isComponentMountedRef.current) {
        initializeCamera()
      }
    }, 500)
  }

  // Load questions only once when permissions are granted
  useEffect(() => {
    if (!permissionsGranted || questionsLoadedRef.current) return

    const fetchQuestions = async () => {
      try {
        // First try to load from local storage if available (for recovery)
        let cachedQuestions = null
        try {
          const cached = localStorage.getItem("interview_questions_cache")
          if (cached) {
            cachedQuestions = JSON.parse(cached)
          }
        } catch (error) {
          console.warn("Failed to load cached questions:", error)
        }

        if (cachedQuestions && Array.isArray(cachedQuestions) && cachedQuestions.length > 0) {
          console.log("Using cached questions")
          setDynamicQuestions(cachedQuestions)
          setIsLoadingQuestions(false)
          questionsLoadedRef.current = true
          return
        }

        // If no cache, fetch from API
        const result = await generateRelevantQuestions(
          initialState.jobRole,
          initialState.level,
          geminiApiKeyRef.current,
        )

        if (result.questions && result.questions.length > 0) {
          setDynamicQuestions(result.questions)

          // Cache the questions for recovery
          try {
            localStorage.setItem("interview_questions_cache", JSON.stringify(result.questions))
          } catch (error) {
            console.warn("Failed to cache questions:", error)
          }
        } else {
          // Fallback to static questions if API fails
          setDynamicQuestions(questions[initialState.jobRole] || [])
        }
      } catch (error) {
        console.error("Error fetching questions:", error)
        // Fallback to static questions
        setDynamicQuestions(questions[initialState.jobRole] || [])
      } finally {
        setIsLoadingQuestions(false)
        questionsLoadedRef.current = true
      }
    }

    fetchQuestions()

    // Cleanup function
    return () => {
      questionsLoadedRef.current = true
    }
  }, [initialState.jobRole, initialState.level, permissionsGranted])

  // Initialize answers array when questions are loaded
  useEffect(() => {
    if (dynamicQuestions.length > 0 && !answersInitializedRef.current) {
      // Check if we have backup answers to restore
      if (answerBackupRef.current.length > 0) {
        // If backup has same length as questions, restore it
        if (answerBackupRef.current.length === dynamicQuestions.length) {
          setAnswers(answerBackupRef.current)
        } else {
          // Otherwise initialize with empty strings but copy over any existing answers
          const newAnswers = new Array(dynamicQuestions.length).fill("")
          answerBackupRef.current.forEach((answer, index) => {
            if (index < newAnswers.length) {
              newAnswers[index] = answer
            }
          })
          setAnswers(newAnswers)
        }
      } else {
        // No backup, initialize with empty strings
        setAnswers(new Array(dynamicQuestions.length).fill(""))
      }

      setScores(new Array(dynamicQuestions.length).fill(0))
      answersInitializedRef.current = true

      // Auto-speak the first question after a short delay
      setTimeout(() => {
        if (dynamicQuestions[0]) {
          speakQuestion(dynamicQuestions[0])
        }
      }, 1000)
    }
  }, [dynamicQuestions])

  // Tab visibility change detection
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden) {
        // Tab switched away
        const newCount = tabSwitchCount + 1
        setTabSwitchCount(newCount)

        if (newCount >= 3) {
          // Auto submit after 3 tab switches
          handleSubmit()
        } else {
          setShowTabWarning(true)
          setTimeout(() => setShowTabWarning(false), 3000)
        }
      }
    }

    document.addEventListener("visibilitychange", handleVisibilityChange)

    return () => {
      document.removeEventListener("visibilitychange", handleVisibilityChange)
    }
  }, [tabSwitchCount])

  // Screenshot detection
  useEffect(() => {
    const handleScreenshot = (e: KeyboardEvent) => {
      // Detect common screenshot key combinations
      const isPrintScreen = e.key === "PrintScreen"
      const isMacScreenshot = e.metaKey && e.shiftKey && (e.key === "3" || e.key === "4" || e.key === "5")
      const isWindowsSnippingTool = (e.shiftKey && e.key === "S" && e.metaKey) || (e.ctrlKey && e.key === "S")

      if (isPrintScreen || isMacScreenshot || isWindowsSnippingTool) {
        screenshotCountRef.current += 1

        if (screenshotCountRef.current >= 3) {
          // Auto submit after 3 screenshots
          handleSubmit()
        } else {
          setShowScreenshotWarning(true)
          setTimeout(() => setShowScreenshotWarning(false), 3000)
        }
      }
    }

    window.addEventListener("keydown", handleScreenshot)

    return () => {
      window.removeEventListener("keydown", handleScreenshot)
    }
  }, [])

  // Start the timer when permissions are granted and questions are loaded
  useEffect(() => {
    if (!permissionsGranted || isLoadingQuestions) return

    // Start screen recording automatically (only once)
    if (!screenRecordingRequested) {
      startScreenRecording()
    }

    timerRef.current = setInterval(() => {
      setTimeLeft((prevTime) => {
        if (prevTime <= 1) {
          if (timerRef.current) {
            clearInterval(timerRef.current)
          }
          handleSubmit()
          return 0
        }
        return prevTime - 1
      })
    }, 1000)

    // Clean up the timer
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current)
      }
      // Stop screen recording if component unmounts
      if (isScreenRecording) {
        stopScreenRecording()
      }
    }
  }, [permissionsGranted, isLoadingQuestions, screenRecordingRequested])

  // Handle submit function
  const handleSubmit = () => {
    // Stop any ongoing speech
    if (synthRef.current) {
      synthRef.current.cancel()
      setIsSpeaking(false)
    }

    // Stop recording if active
    if (isRecording) {
      stopRecording()
    }

    // Stop screen recording if active
    if (isScreenRecording) {
      stopScreenRecording()
    }

    // Clean up camera
    if (cameraStreamRef.current) {
      cameraStreamRef.current.getTracks().forEach((track) => track.stop())
      cameraStreamRef.current = null
    }

    // Clean up microphone
    if (microphoneStreamRef.current) {
      microphoneStreamRef.current.getTracks().forEach((track) => track.stop())
      microphoneStreamRef.current = null
    }

    // Clean up timer
    if (timerRef.current) {
      clearInterval(timerRef.current)
    }

    // Clean up recording timer
    if (recordingTimerRef.current) {
      clearInterval(recordingTimerRef.current)
    }

    // Clear network check interval
    if (networkCheckIntervalRef.current) {
      clearInterval(networkCheckIntervalRef.current)
    }

    // Clear permission check interval
    if (permissionCheckIntervalRef.current) {
      clearInterval(permissionCheckIntervalRef.current)
    }

    // Clear answer save interval
    if (answerSaveIntervalRef.current) {
      clearInterval(answerSaveIntervalRef.current)
    }

    // Clean up localStorage
    try {
      localStorage.removeItem("interview_questions_cache")
      localStorage.removeItem("interview_answers_backup")
    } catch (error) {
      console.warn("Failed to clean up localStorage:", error)
    }

    // Process recording if available before showing performance analysis
    if (recordedChunks.length > 0 && !recordingUrl) {
      try {
        console.log(`Processing ${recordedChunks.length} recorded chunks before submission`)
        const blob = new Blob(recordedChunks, {
          type: "video/webm",
        })
        const url = URL.createObjectURL(blob)
        setRecordingUrl(url)

        // Wait a moment to ensure the URL is set before showing performance analysis
        setTimeout(() => {
          setIsInterviewCompleted(true)
        }, 500)
      } catch (error) {
        console.error("Error processing recording:", error)
        setIsInterviewCompleted(true)
      }
    } else {
      // Show performance analysis
      setIsInterviewCompleted(true)
    }
  }

  // Get current question
  const currentQuestion = dynamicQuestions[currentQuestionIndex] || "Loading question..."

  // Check if current question is a coding question
  const isCodingQuestion = currentQuestion.includes("[CODE]")

  // Clean question text (remove [CODE] prefix for display)
  const cleanQuestionText = isCodingQuestion ? currentQuestion.replace("[CODE]", "").trim() : currentQuestion

  // Format time function
  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60)
    const remainingSeconds = seconds % 60
    return `${minutes.toString().padStart(2, "0")}:${remainingSeconds.toString().padStart(2, "0")}`
  }

  // Handle answer change
  const handleAnswerChange = (value: string) => {
    setAnswers((prev) => {
      const newAnswers = [...prev]
      newAnswers[currentQuestionIndex] = value
      return newAnswers
    })
    setAnswerError(null)
  }

  // Handle code change
  const handleCodeChange = (code: string) => {
    // For coding questions, store the code as the answer
    if (isCodingQuestion) {
      handleAnswerChange(code)
    }
  }

  // Analyze answer and update score
  const analyzeCurrentAnswer = async () => {
    const currentAnswer = answers[currentQuestionIndex]
    if (!currentAnswer || currentAnswer.trim() === "") return

    try {
      // Check network status before making API call
      if (networkStatus !== "online") {
        console.warn("Network is not online, skipping answer analysis")
        return
      }

      const result = await analyzeAnswer(
        currentQuestion,
        currentAnswer,
        initialState.jobRole,
        initialState.level,
        geminiApiKeyRef.current,
      ).catch((error) => {
        throw new Error(`Analysis failed: ${error.message}`)
      })

      if (result.score !== undefined) {
        // Only update score if the answer is correct (score >= 6) AND better than previous score
        if (result.isCorrect && result.score >= 6) {
          setScores((prev) => {
            const newScores = [...prev]
            // Only increase score if new score is higher
            if (result.score > (prev[currentQuestionIndex] || 0)) {
              newScores[currentQuestionIndex] = result.score
            }
            return newScores
          })
        } else {
          // For incorrect answers, ensure score is 0
          setScores((prev) => {
            const newScores = [...prev]
            newScores[currentQuestionIndex] = 0
            return newScores
          })
        }
      }
    } catch (error) {
      handleError(error, "answer analysis", "Could not analyze your answer")
      // Continue anyway, don't block the user
    }
  }

  // Handle next question
  const handleNextQuestion = async () => {
    // Validate that the current question has been answered
    if (!answers[currentQuestionIndex]?.trim()) {
      setAnswerError("Please provide an answer before moving to the next question")
      return
    }

    // Analyze the current answer
    await analyzeCurrentAnswer()

    if (currentQuestionIndex < dynamicQuestions.length - 1) {
      // Stop recording if it's active
      if (isRecording) {
        stopRecording()
      }

      // Stop any ongoing speech
      if (synthRef.current) {
        synthRef.current.cancel()
        setIsSpeaking(false)
      }

      setAnswerError(null)
      setCurrentQuestionIndex((prev) => {
        const nextIndex = prev + 1

        // Auto-speak the next question after a short delay
        setTimeout(() => {
          if (dynamicQuestions[nextIndex]) {
            speakQuestion(dynamicQuestions[nextIndex])
          }
        }, 500)

        return nextIndex
      })

      // Reset the interim transcript
      setInterimTranscript("")
    }
  }

  // Handle previous question
  const handlePreviousQuestion = () => {
    if (currentQuestionIndex > 0) {
      // Stop recording if it's active
      if (isRecording) {
        stopRecording()
      }

      // Stop any ongoing speech
      if (synthRef.current) {
        synthRef.current.cancel()
        setIsSpeaking(false)
      }

      setCurrentQuestionIndex((prev) => {
        const prevIndex = prev - 1

        // Auto-speak the previous question after a short delay
        setTimeout(() => {
          if (dynamicQuestions[prevIndex]) {
            speakQuestion(dynamicQuestions[prevIndex])
          }
        }, 500)

        return prevIndex
      })

      // Reset the interim transcript
      setInterimTranscript("")
    }
  }

  // Toggle speech recognition
  const toggleSpeechRecognition = () => {
    if (isRecording) {
      stopRecording()
    } else {
      startRecording()
    }
  }

  // Start recording with our new speech recognition service
  const startRecording = () => {
    if (isRecording || isInitializingRecording) {
      console.log("Recording already active or initializing")
      return
    }

    setIsInitializingRecording(true)
    setAnswerError(null)

    try {
      // Clean up previous instance if it exists
      if (speechRecognitionRef.current) {
        speechRecognitionRef.current.destroy()
        speechRecognitionRef.current = null
      }

      // Create a new speech recognition instance for this recording session
      const speechRecognition = createSpeechRecognition(
        {
          continuous: true,
          interimResults: true,
          language: "en-US",
        },
        {
          onStart: () => {
            console.log("Speech recognition started successfully")
            setIsRecording(true)
            setIsInitializingRecording(false)
            setInterimTranscript("")

            // Start recording timer
            recordingStartTimeRef.current = Date.now()
            if (recordingTimerRef.current) {
              clearInterval(recordingTimerRef.current)
            }

            recordingTimerRef.current = setInterval(() => {
              if (recordingStartTimeRef.current) {
                const duration = Math.floor((Date.now() - recordingStartTimeRef.current) / 1000)
                setRecordingDuration(duration)
              }
            }, 1000)
          },
          onResult: (transcript, isFinal) => {
            // Always use the current question index from the ref to ensure we're updating the correct question
            const currentIdx = currentQuestionRef.current

            if (isFinal) {
              // Update the answer with the final transcript
              setAnswers((prev) => {
                const newAnswers = [...prev]
                const currentAnswer = newAnswers[currentIdx] || ""
                newAnswers[currentIdx] = (currentAnswer + " " + transcript).trim()
                return newAnswers
              })
              setInterimTranscript("")
            } else {
              // Update the interim transcript for display
              setInterimTranscript(transcript)
            }
          },
          onEnd: () => {
            console.log("Speech recognition ended")
            setIsRecording(false)
            setIsInitializingRecording(false)

            // Stop recording timer
            if (recordingTimerRef.current) {
              clearInterval(recordingTimerRef.current)
            }
            recordingStartTimeRef.current = null
            setRecordingDuration(0)
          },
          onError: (error) => {
            console.error("Speech recognition error:", error)
            setIsInitializingRecording(false)
            setAnswerError(`Speech recognition error: ${error}`)
          },
        },
      )

      speechRecognitionRef.current = speechRecognition

      if (!speechRecognition.isSupported()) {
        setIsInitializingRecording(false)
        setSpeechRecognitionSupported(false)
        setAnswerError(
          "Speech recognition is not supported in your browser. Please use Chrome for the best experience.",
        )
        return
      }

      // Start the speech recognition
      speechRecognition.start()
    } catch (error) {
      console.error("Error starting speech recognition:", error)
      setIsInitializingRecording(false)
      setAnswerError(`Failed to start speech recognition: ${error instanceof Error ? error.message : "Unknown error"}`)
    }
  }

  // Stop recording
  const stopRecording = () => {
    if (speechRecognitionRef.current) {
      speechRecognitionRef.current.stop()

      // Clear recording timer
      if (recordingTimerRef.current) {
        clearInterval(recordingTimerRef.current)
      }
      recordingStartTimeRef.current = null
      setRecordingDuration(0)
    }
  }

  // Speak question with enhanced Indian female voice
  const speakQuestion = (questionText: string) => {
    if (!synthRef.current) {
      console.log("Initializing speech synthesis")
      synthRef.current = window.speechSynthesis
    }

    // Safety check for undefined questionText
    if (!questionText) {
      console.warn("Attempted to speak undefined question text")
      return
    }

    const textToSpeak = isCodingQuestion ? questionText.replace("[CODE]", "").trim() : questionText

    // Cancel any ongoing speech
    synthRef.current.cancel()
    setIsSpeaking(false)

    try {
      console.log("Speaking question:", textToSpeak)

      // Create a single utterance for the entire text
      const utterance = new SpeechSynthesisUtterance(textToSpeak)

      // Set properties for better voice quality and Indian accent
      utterance.rate = 0.85 // Slightly slower for better clarity
      utterance.pitch = 1.1 // Slightly higher pitch for female voice
      utterance.volume = 1.0

      // Use the selected voice if available
      if (selectedVoice) {
        utterance.voice = selectedVoice
        console.log(`Using selected voice: ${selectedVoice.name} (${selectedVoice.lang})`)
      } else {
        // Try to find an Indian female voice again
        const voices = synthRef.current.getVoices()

        // First priority: Indian female voice
        let voice = voices.find(
          (v) => (v.lang.includes("hi-IN") || v.lang.includes("en-IN")) && v.name.toLowerCase().includes("female"),
        )

        // Second priority: Any Indian voice
        if (!voice) {
          voice = voices.find((v) => v.lang.includes("hi-IN") || v.lang.includes("en-IN"))
        }

        // Third priority: Any female voice
        if (!voice) {
          voice = voices.find((v) => v.name.toLowerCase().includes("female") && v.lang.includes("en"))
        }

        // Fallback to any English voice
        if (!voice) {
          voice = voices.find((v) => v.lang.includes("en"))
        }

        if (voice) {
          utterance.voice = voice
          console.log(`Using fallback voice: ${voice.name} (${voice.lang})`)
        } else {
          console.warn("No suitable voice found, using default browser voice")
        }
      }

      // Set event handlers
      utterance.onstart = () => {
        console.log("Speech started")
        setIsSpeaking(true)
      }

      utterance.onend = () => {
        console.log("Speech ended")
        setIsSpeaking(false)
      }

      utterance.onerror = (event) => {
        console.error("Speech synthesis error:", event)
        setIsSpeaking(false)
      }

      // Speak the utterance
      synthRef.current.speak(utterance)

      // Force speaking to start if it doesn't automatically
      if (!synthRef.current.speaking) {
        console.log("Forcing speech to start")
        const tempUtterance = new SpeechSynthesisUtterance(".")
        tempUtterance.volume = 0
        synthRef.current.speak(tempUtterance)
      }
    } catch (error) {
      console.error("Error in speech synthesis:", error)
      setIsSpeaking(false)
    }
  }

  // Prevent copy and paste
  const handlePaste = (e: React.ClipboardEvent) => {
    e.preventDefault()
  }

  const handleCopy = (e: React.ClipboardEvent) => {
    e.preventDefault()
  }

  // Get level color
  const getLevelColor = () => {
    if (initialState.level === "beginner") return "from-green-500 to-emerald-600"
    if (initialState.level === "intermediate") return "from-blue-500 to-indigo-600"
    return "from-purple-500 to-violet-600"
  }

  // Retry permissions
  const retryPermissions = () => {
    setCheckingPermissions(true)
    setPermissionError(null)
    setPermissionChangeDetected(false)
    setShowPermissionChangeWarning(false)

    // Clean up any existing streams
    if (cameraStreamRef.current) {
      cameraStreamRef.current.getTracks().forEach((track) => track.stop())
      cameraStreamRef.current = null
    }

    // Re-request permissions
    const requestPermissions = async () => {
      try {
        // Request camera and microphone
        const mediaStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true })

        // Stop audio tracks as we'll use them with speech recognition
        mediaStream.getAudioTracks().forEach((track) => track.stop())

        // Keep video tracks
        cameraStreamRef.current = new MediaStream(mediaStream.getVideoTracks())

        if (videoRef.current) {
          videoRef.current.srcObject = cameraStreamRef.current
        }

        setPermissionsGranted(true)
        setCheckingPermissions(false)

        // Update permission status
        lastPermissionStatusRef.current = {
          camera: true,
          microphone: true,
        }
      } catch (error) {
        console.error("Error requesting permissions:", error)
        setPermissionError("Failed to access camera or microphone. Please grant permissions and try again.")
        setPermissionsGranted(false)
        setCheckingPermissions(false)
      }
    }

    requestPermissions()
  }

  // Reset speech recognition when changing questions
  useEffect(() => {
    // If we're recording, restart the speech recognition for the new question
    if (isRecording) {
      stopRecording()
      setTimeout(() => {
        if (isComponentMountedRef.current) {
          startRecording()
        }
      }, 300)
    }
  }, [currentQuestionIndex])

  // Ensure camera is displayed
  useEffect(() => {
    if (permissionsGranted && videoRef.current && !cameraActive) {
      console.log("Camera permission granted but not active, reinitializing...")

      // Short timeout to ensure DOM is ready
      const timer = setTimeout(() => {
        if (isComponentMountedRef.current) {
          initializeCamera()
        }
      }, 1000)

      return () => clearTimeout(timer)
    }
  }, [permissionsGranted, cameraActive])

  // Add this near the other useEffect hooks
  useEffect(() => {
    // This effect runs once after the component is mounted
    if (videoRef.current && permissionsGranted) {
      // Short timeout to ensure DOM is fully rendered
      const timer = setTimeout(() => {
        console.log("Initial camera setup after mount")
        initializeCamera()
      }, 500)

      return () => clearTimeout(timer)
    }
  }, [permissionsGranted]) // Only run when permissions change

  // Render browser compatibility issue
  if (browserCompatibilityIssue) {
    return (
      <div className="max-w-4xl mx-auto bg-white shadow-xl rounded-xl overflow-hidden">
        <div className="p-8 bg-gradient-to-r from-red-600 to-pink-700 text-white">
          <h2 className="text-3xl font-bold mb-2">Browser Compatibility Issue</h2>
          <p className="text-lg">Your browser may not fully support all features needed for the interview</p>
        </div>
        <div className="p-16 text-center">
          <div className="bg-red-100 p-4 rounded-full inline-flex mb-6">
            <AlertTriangle className="h-12 w-12 text-red-500" />
          </div>
          <p className="text-xl font-semibold text-gray-800 mb-4">Browser Not Fully Compatible</p>
          <p className="text-gray-600 mb-6">
            We detected that you're using {browserInfoRef.current.name} {browserInfoRef.current.version}, which may not
            fully support all features needed for the interview. For the best experience, please use the latest version
            of Google Chrome.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button onClick={retryPermissions} className="bg-purple-600 hover:bg-purple-700 text-white">
              Continue Anyway
            </Button>
            <Button onClick={onAbort} variant="outline" className="border-red-300 text-red-600 hover:bg-red-50">
              Cancel Interview
            </Button>
          </div>
        </div>
      </div>
    )
  }

  // Render performance analysis if interview is completed
  if (isInterviewCompleted) {
    return (
      <PerformanceAnalysis
        jobRole={initialState.jobRole}
        level={initialState.level}
        answers={answers}
        scores={scores}
        tabSwitchCount={tabSwitchCount}
        onFinish={onAbort}
        recordingUrl={recordingUrl}
      />
    )
  }

  // Render permission check
  if (checkingPermissions) {
    return (
      <div className="max-w-4xl mx-auto bg-white shadow-xl rounded-xl overflow-hidden">
        <div className="p-8 bg-gradient-to-r from-purple-600 to-indigo-700 text-white">
          <h2 className="text-3xl font-bold mb-2">Checking Permissions</h2>
          <p className="text-lg">Please allow camera and microphone access when prompted</p>
        </div>
        <div className="p-16 text-center">
          <div className="relative w-20 h-20 mx-auto mb-6">
            <div className="absolute top-0 left-0 w-full h-full border-4 border-purple-500 border-t-transparent rounded-full animate-spin"></div>
            <Camera className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 h-8 w-8 text-purple-400" />
          </div>
          <p className="text-xl font-semibold text-gray-800 mb-2">Checking camera and microphone permissions...</p>
          <p className="text-gray-500">These permissions are required for the interview process</p>
        </div>
      </div>
    )
  }

  // Render permission error
  if (!permissionsGranted) {
    return (
      <div className="max-w-4xl mx-auto bg-white shadow-xl rounded-xl overflow-hidden">
        <div className="p-8 bg-gradient-to-r from-red-600 to-pink-700 text-white">
          <h2 className="text-3xl font-bold mb-2">Permissions Required</h2>
          <p className="text-lg">Camera and microphone access are required for the interview</p>
        </div>
        <div className="p-16 text-center">
          <div className="bg-red-100 p-4 rounded-full inline-flex mb-6">
            <AlertTriangle className="h-12 w-12 text-red-500" />
          </div>
          <p className="text-xl font-semibold text-gray-800 mb-4">Permission Error</p>
          <p className="text-gray-600 mb-6">
            {permissionError || "Camera and microphone permissions are required to proceed with the interview."}
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button onClick={retryPermissions} className="bg-purple-600 hover:bg-purple-700 text-white">
              Retry Permissions
            </Button>
            <Button onClick={onAbort} variant="outline" className="border-red-300 text-red-600 hover:bg-red-50">
              Cancel Interview
            </Button>
          </div>
        </div>
      </div>
    )
  }

  // Render loading state
  if (isLoadingQuestions) {
    return (
      <div className="max-w-4xl mx-auto bg-white shadow-xl rounded-xl overflow-hidden">
        <div className="p-8 bg-gradient-to-r from-purple-600 to-indigo-700 text-white">
          <h2 className="text-3xl font-bold mb-2">
            Preparing Your {initialState.level.charAt(0).toUpperCase() + initialState.level.slice(1)} Interview
          </h2>
          <p className="text-lg">We're generating relevant questions for your {initialState.jobRole} interview...</p>
        </div>
        <div className="p-16 text-center">
          <div className="relative w-20 h-20 mx-auto mb-6">
            <div className="absolute top-0 left-0 w-full h-full border-4 border-purple-500 border-t-transparent rounded-full animate-spin"></div>
            <div className="absolute top-2 left-2 w-16 h-16 border-4 border-indigo-400 border-t-transparent rounded-full animate-spin-slow"></div>
            <Brain className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 h-8 w-8 text-purple-400" />
          </div>
          <p className="text-xl font-semibold text-gray-800 mb-2">Loading personalized interview questions...</p>
          <p className="text-gray-500">This may take a few moments</p>
        </div>
      </div>
    )
  }

  // Main interview UI
  return (
    <>
      <div className="max-w-4xl mx-auto bg-white shadow-xl rounded-xl overflow-hidden">
        <div className="p-6 bg-gradient-to-r from-purple-600 to-indigo-700 text-white">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-3xl font-bold mb-2">
                {initialState.level.charAt(0).toUpperCase() + initialState.level.slice(1)} Interview for{" "}
                {initialState.jobRole}
              </h2>
              <div className="flex items-center">
                <Clock className="h-5 w-5 mr-2" />
                <div className="text-xl font-semibold">Time Remaining: {formatTime(timeLeft)}</div>
              </div>
            </div>
            <div className="hidden md:block">
              <div className={`px-4 py-2 rounded-full bg-gradient-to-r ${getLevelColor()} text-white font-semibold`}>
                {initialState.level.charAt(0).toUpperCase() + initialState.level.slice(1)} Level
              </div>
            </div>
          </div>

          {showTabWarning && (
            <div className="mt-3 flex items-center text-yellow-300 bg-yellow-900/30 p-2 rounded-lg animate-pulse">
              <AlertTriangle className="mr-2 h-5 w-5" />
              <span>Warning: Tab switch detected! ({tabSwitchCount}/3)</span>
            </div>
          )}
          {showScreenshotWarning && (
            <div className="mt-3 flex items-center text-yellow-300 bg-yellow-900/30 p-2 rounded-lg animate-pulse">
              <Camera className="mr-2 h-5 w-5" />
              <span>Warning: Screenshot detected! ({screenshotCountRef.current}/3)</span>
            </div>
          )}
          {showNetworkWarning && (
            <div className="mt-3 flex items-center text-yellow-300 bg-yellow-900/30 p-2 rounded-lg animate-pulse">
              <WifiOff className="mr-2 h-5 w-5" />
              <span>Warning: Network issues detected! Your answers are being saved locally.</span>
            </div>
          )}
          {showPermissionChangeWarning && (
            <div className="mt-3 flex items-center text-yellow-300 bg-yellow-900/30 p-2 rounded-lg animate-pulse">
              <AlertTriangle className="mr-2 h-5 w-5" />
              <span>Warning: Permission changes detected! Some features may not work properly.</span>
            </div>
          )}
          {isScreenRecording && (
            <div className="mt-3 flex items-center text-green-300 bg-green-900/30 p-2 rounded-lg">
              <Video className="mr-2 h-5 w-5" />
              <span>Screen recording active {recordingWithAudio ? "with audio" : ""}</span>
            </div>
          )}
        </div>

        <div className="p-6">
          <div className="flex items-center mb-4">
            <div className="h-2 bg-gray-200 flex-grow rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-purple-500 to-indigo-600 transition-all duration-500"
                style={{ width: `${((currentQuestionIndex + 1) / dynamicQuestions.length) * 100}%` }}
              ></div>
            </div>
            <span className="ml-3 text-gray-600 font-medium">
              {currentQuestionIndex + 1}/{dynamicQuestions.length}
            </span>
          </div>

          <div className="mb-6 flex flex-col md:flex-row items-start">
            <div className="w-full md:w-1/3 md:pr-4 mb-4 md:mb-0">
              <div className="bg-gray-50 p-4 rounded-xl border border-gray-100 shadow-sm">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-sm font-medium text-gray-500">Live Camera Feed</h4>
                </div>
                <div className="relative">
                  <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    muted
                    width="100%"
                    height="100%"
                    className="w-full h-40 bg-gray-200 rounded-lg object-cover"
                    style={{ transform: "scaleX(-1)" }}
                  />

                  {/* Camera loading indicator */}
                  {cameraLoading && (
                    <div className="absolute inset-0 flex items-center justify-center bg-gray-800/50 rounded-lg">
                      <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-white"></div>
                    </div>
                  )}

                  {/* Camera not active - show enable button */}
                  {!cameraActive && !cameraLoading && (
                    <div className="absolute inset-0 flex items-center justify-center bg-red-800/30 rounded-lg">
                      <div className="text-center p-2">
                        <AlertTriangle className="h-8 w-8 text-red-500 mx-auto mb-2" />
                        <p className="text-sm text-white mb-3">Camera not active</p>
                        <Button
                          onClick={handleEnableCamera}
                          className="bg-white text-red-600 hover:bg-gray-100"
                          size="sm"
                        >
                          <Camera className="mr-2 h-4 w-4" />
                          Enable Camera
                        </Button>
                      </div>
                    </div>
                  )}

                  {/* Camera active - show live indicator */}
                  {cameraActive && (
                    <div className="absolute top-2 left-2">
                      <div className="flex items-center bg-green-500/20 backdrop-blur-sm px-2 py-1 rounded-full">
                        <div className="w-2 h-2 bg-green-500 rounded-full mr-1 animate-pulse"></div>
                        <span className="text-xs text-green-700 font-medium">Live</span>
                      </div>
                    </div>
                  )}

                  {/* Always show refresh camera button */}
                  <div className="absolute top-2 right-2">
                    <Button
                      onClick={refreshCamera}
                      variant="outline"
                      size="sm"
                      className="bg-white/80 backdrop-blur-sm hover:bg-white text-gray-700 border-gray-200"
                      title="Refresh camera"
                      disabled={cameraLoading}
                    >
                      {cameraLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>
              </div>
            </div>

            <div className="w-full md:w-2/3">
              <div className="bg-gray-50 p-4 rounded-xl border border-gray-100 shadow-sm">
                <div className="flex items-center mb-3">
                  <h3 className="text-2xl font-semibold text-gray-800">Question</h3>
                  <Button
                    onClick={() => speakQuestion(currentQuestion)}
                    variant="ghost"
                    size="sm"
                    className={`ml-2 ${isSpeaking ? "text-blue-500 animate-pulse" : "text-gray-500"}`}
                    title="Read question aloud"
                  >
                    <Volume2 className={`h-5 w-5 ${isSpeaking ? "animate-pulse" : ""}`} />
                  </Button>
                </div>
                <p className="text-lg text-gray-700">{cleanQuestionText}</p>
              </div>
            </div>
          </div>

          {isCodingQuestion ? (
            // Show code editor for coding questions
            <CodeEditor question={cleanQuestionText} onCodeChange={handleCodeChange} />
          ) : (
            // Show regular answer box for non-coding questions
            <div className="mb-6">
              <div className="flex items-center mb-3">
                <h3 className="text-2xl font-semibold text-gray-800">Your Answer:</h3>
                <Button
                  onClick={toggleSpeechRecognition}
                  variant="outline"
                  size="sm"
                  disabled={isInitializingRecording}
                  className={`ml-3 ${
                    isRecording
                      ? "bg-red-50 text-red-600 border-red-200"
                      : isInitializingRecording
                        ? "bg-gray-100 text-gray-400 border-gray-200"
                        : "bg-green-50 text-green-600 border-green-200"
                  }`}
                >
                  {isRecording ? (
                    <>
                      <MicOff className="mr-2 h-4 w-4 animate-pulse" />
                      <span className="relative">
                        Stop Recording {recordingDuration > 0 && `(${formatTime(recordingDuration)})`}
                        <span className="absolute -top-1 -right-1 flex h-3 w-3">
                          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                          <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
                        </span>
                      </span>
                    </>
                  ) : isInitializingRecording ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Initializing...
                    </>
                  ) : (
                    <>
                      <Mic className="mr-2 h-4 w-4" />
                      Start Recording
                    </>
                  )}
                </Button>
              </div>
              <div className="relative">
                <textarea
                  ref={textareaRef}
                  className={`w-full h-40 p-4 border rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent resize-none ${
                    answerError ? "border-red-300 bg-red-50" : "border-gray-200"
                  }`}
                  value={answers[currentQuestionIndex] || ""}
                  onChange={(e) => {
                    handleAnswerChange(e.target.value)
                  }}
                  onPaste={handlePaste}
                  onCopy={handleCopy}
                  placeholder="Type or speak your answer here..."
                />
                {answerError && (
                  <p className="text-red-500 text-sm mt-2 flex items-center">
                    <AlertTriangle className="h-4 w-4 mr-1" />
                    {answerError}
                  </p>
                )}
                {isRecording && (
                  <div className="absolute bottom-3 right-3 flex items-center space-x-1 bg-red-100 px-2 py-1 rounded-full">
                    <span className="animate-ping inline-flex h-3 w-3 rounded-full bg-red-400 opacity-75"></span>
                    <span className="text-xs text-red-600 font-medium">
                      Recording... {recordingDuration > 0 && `(${formatTime(recordingDuration)})`}
                    </span>
                  </div>
                )}
                {interimTranscript && (
                  <div className="absolute bottom-12 right-3 left-3 bg-gray-100 p-2 rounded-md text-gray-600 text-sm italic">
                    {interimTranscript}
                  </div>
                )}
              </div>
            </div>
          )}

          <div className="flex justify-between mb-6">
            <Button
              onClick={handlePreviousQuestion}
              disabled={currentQuestionIndex === 0}
              className="bg-gray-100 text-gray-800 hover:bg-gray-200 border border-gray-300 flex items-center"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Previous
            </Button>
            <Button
              onClick={handleNextQuestion}
              disabled={currentQuestionIndex === dynamicQuestions.length - 1}
              className="bg-purple-600 text-white hover:bg-purple-700 flex items-center"
            >
              Next
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
          <div className="flex justify-between items-center">
            <Button onClick={onAbort} variant="outline" className="border-red-300 text-red-600 hover:bg-red-50">
              Abort Interview
            </Button>
            <Button
              onClick={() => setShowConfirmSubmit(true)}
              className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white px-8 py-3 text-lg font-semibold rounded-lg shadow-md hover:shadow-lg transition-all flex items-center"
            >
              <Send className="mr-2 h-5 w-5" />
              Submit Interview
            </Button>
          </div>
        </div>
      </div>

      {/* Screenshot Warning Dialog */}
      <AlertDialog open={showScreenshotWarning}>
        <AlertDialogContent className="bg-white rounded-xl border-none shadow-xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-xl text-red-600 flex items-center">
              <Camera className="mr-2 h-5 w-5" />
              Screenshot Detected
            </AlertDialogTitle>
            <AlertDialogDescription className="text-gray-600">
              Taking screenshots during the interview is not allowed. You have {3 - screenshotCountRef.current} attempts
              remaining before the interview is automatically submitted.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction
              onClick={() => setShowScreenshotWarning(false)}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              I Understand
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Network Warning Dialog */}
      <AlertDialog open={showNetworkWarning && networkStatus !== "online"}>
        <AlertDialogContent className="bg-white rounded-xl border-none shadow-xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-xl text-amber-600 flex items-center">
              <WifiOff className="mr-2 h-5 w-5" />
              Network Issues Detected
            </AlertDialogTitle>
            <AlertDialogDescription className="text-gray-600">
              {networkStatus === "offline"
                ? "You appear to be offline. Your answers are being saved locally and will be submitted when you reconnect."
                : "Your internet connection seems unstable. Your answers are being saved locally to prevent data loss."}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction
              onClick={() => setShowNetworkWarning(false)}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              I Understand
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Permission Change Warning Dialog */}
      <AlertDialog open={showPermissionChangeWarning && permissionChangeDetected}>
        <AlertDialogContent className="bg-white rounded-xl border-none shadow-xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-xl text-amber-600 flex items-center">
              <AlertTriangle className="mr-2 h-5 w-5" />
              Permission Changes Detected
            </AlertDialogTitle>
            <AlertDialogDescription className="text-gray-600">
              It appears that camera or microphone permissions have changed. This may affect the interview experience.
              Would you like to retry with the correct permissions?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <Button
              onClick={() => {
                setShowPermissionChangeWarning(false)
                retryPermissions()
              }}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              Retry Permissions
            </Button>
            <Button
              onClick={() => {
                setShowPermissionChangeWarning(false)
                setPermissionChangeDetected(false)
              }}
              variant="outline"
            >
              Continue Anyway
            </Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Confirm Submit Dialog */}
      <AlertDialog open={showConfirmSubmit}>
        <AlertDialogContent className="bg-white rounded-xl border-none shadow-xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-xl">Submit Interview?</AlertDialogTitle>
            <AlertDialogDescription className="text-gray-600">
              Are you sure you want to submit your interview? You won't be able to make any changes after submission.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <Button onClick={() => setShowConfirmSubmit(false)} variant="outline" className="mr-2">
              Cancel
            </Button>
            <Button
              onClick={() => {
                setShowConfirmSubmit(false)
                handleSubmit()
              }}
              className="bg-green-600 hover:bg-green-700 text-white"
            >
              Yes, Submit
            </Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}
