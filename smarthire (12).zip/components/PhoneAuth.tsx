"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Loader2, Phone } from "lucide-react"
import { useAuth } from "@/contexts/auth-context"

interface PhoneAuthProps {
  isSubmitting: boolean
  isOnline: boolean
  setError: (error: string | null) => void
}

export default function PhoneAuth({ isSubmitting, isOnline, setError }: PhoneAuthProps) {
  const [phone, setPhone] = useState("")
  const [showPhoneInput, setShowPhoneInput] = useState(false)
  const { signInWithPhone } = useAuth()

  const handlePhoneSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)

    if (!isOnline) {
      setError("You are offline. Please check your internet connection and try again.")
      return
    }

    if (!phone) {
      setError("Please enter your phone number")
      return
    }

    // Validate phone number format (basic validation)
    const phoneRegex = /^\+[1-9]\d{1,14}$/
    if (!phoneRegex.test(phone)) {
      setError("Please enter a valid phone number in international format (e.g., +1234567890)")
      return
    }

    try {
      const { error, success } = await signInWithPhone(phone)

      if (error) {
        console.error("Phone sign in error:", error)
        setError(error.message || "Failed to send verification code")
      }
    } catch (err: any) {
      console.error("Phone sign in error:", err)
      setError(err.message || "An unexpected error occurred")
    }
  }

  if (!showPhoneInput) {
    return (
      <Button
        type="button"
        variant="outline"
        className="w-full bg-gray-700 text-white hover:bg-gray-600 border-gray-600"
        onClick={() => setShowPhoneInput(true)}
        disabled={isSubmitting || !isOnline}
      >
        <Phone className="mr-2 h-4 w-4" />
        Sign in with Phone
      </Button>
    )
  }

  return (
    <form onSubmit={handlePhoneSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="phone" className="text-white">
          Phone Number
        </Label>
        <Input
          id="phone"
          type="tel"
          placeholder="+1234567890"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          className="bg-gray-700 border-gray-600 text-white placeholder:text-gray-400"
          disabled={isSubmitting || !isOnline}
        />
        <p className="text-xs text-gray-400">Enter your phone number in international format (e.g., +1234567890)</p>
      </div>

      <div className="flex space-x-2">
        <Button
          type="submit"
          className="flex-1 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
          disabled={isSubmitting || !isOnline}
        >
          {isSubmitting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Sending code...
            </>
          ) : (
            "Send verification code"
          )}
        </Button>
        <Button
          type="button"
          variant="outline"
          className="bg-transparent border-gray-600 text-gray-300 hover:bg-gray-700"
          onClick={() => setShowPhoneInput(false)}
          disabled={isSubmitting}
        >
          Cancel
        </Button>
      </div>
    </form>
  )
}
