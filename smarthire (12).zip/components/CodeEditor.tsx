"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Check, Copy, Play, Send, Loader2 } from "lucide-react"

interface CodeEditorProps {
  question: string
  language?: string
  onCodeChange?: (code: string) => void
}

export default function CodeEditor(props: CodeEditorProps) {
  // Store props in state to avoid re-renders from prop changes
  const [config] = useState(() => ({
    question: props.question,
    initialLanguage: props.language,
    onCodeChange: props.onCodeChange,
  }))

  // Component state
  const [language, setLanguage] = useState(() => config.initialLanguage || detectLanguage(config.question))
  const [code, setCode] = useState("")
  const [output, setOutput] = useState("")
  const [isCopied, setIsCopied] = useState(false)
  const [isRunning, setIsRunning] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [codeError, setCodeError] = useState<string | null>(null)
  const [isSubmitted, setIsSubmitted] = useState(false)

  // Refs
  const initialized = useRef(false)

  // Initialize code only once
  useEffect(() => {
    if (!initialized.current) {
      setCode(getStarterCode(language))
      initialized.current = true
    }
  }, [language])

  // Notify parent of code changes
  useEffect(() => {
    if (config.onCodeChange && initialized.current) {
      config.onCodeChange(code)
    }
  }, [code, config.onCodeChange])

  // Handle language change
  const handleLanguageChange = (newLanguage: string) => {
    if (code !== getStarterCode(language)) {
      if (window.confirm("Changing language will reset your code. Continue?")) {
        setLanguage(newLanguage)
        setCode(getStarterCode(newLanguage))
      }
    } else {
      setLanguage(newLanguage)
      setCode(getStarterCode(newLanguage))
    }
  }

  // Detect language from question
  function detectLanguage(question: string): string {
    const lowerQuestion = question.toLowerCase()
    if (lowerQuestion.includes("html") || lowerQuestion.includes("css")) return "html"
    if (lowerQuestion.includes("java ") && !lowerQuestion.includes("javascript")) return "java"
    if (lowerQuestion.includes("javascript") || lowerQuestion.includes("js")) return "javascript"
    if (lowerQuestion.includes("python")) return "python"
    if (lowerQuestion.includes("c++")) return "cpp"
    if (lowerQuestion.includes(" c ") || lowerQuestion.includes("c language")) return "c"
    if (lowerQuestion.includes("node")) return "javascript"
    if (lowerQuestion.includes("sql")) return "sql"
    if (lowerQuestion.includes("react")) return "javascript" // Use JavaScript for React code
    if (lowerQuestion.includes("scala")) return "scala"
    return "javascript" // Default
  }

  // Get starter code based on language
  function getStarterCode(lang: string): string {
    switch (lang) {
      case "html":
        return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <style>
    /* Add your CSS here */
  </style>
</head>
<body>
  <!-- Add your HTML here -->

  <script>
    // Add your JavaScript here
  </script>
</body>
</html>`
      case "javascript":
        return `// Write your JavaScript/React code here
function main() {
  // Your code here

  return "Hello, World!";
}

// Test your code
console.log(main());`
      case "python":
        return `# Write your Python code here
def main():
  # Your code here

  return "Hello, World!"

# Test your code
print(main())`
      case "java":
        return `// Write your Java code here
public class Main {
  public static void main(String[] args) {
    // Your code here
    System.out.println("Hello, World!");
  }
}`
      case "cpp":
        return `// Write your C++ code here
#include <iostream>
using namespace std;

int main() {
  // Your code here
  cout << "Hello, World!" << endl;
  return 0;
}`
      case "c":
        return `// Write your C code here
#include <stdio.h>

int main() {
  // Your code here
  printf("Hello, World!");
  return 0;
}`
      case "sql":
        return `-- Write your SQL query here
SELECT * FROM users WHERE id = 1;`
      case "scala":
        return `// Write your Scala code here
object Main {
  def main(args: Array[String]): Unit = {
    // Your code here
    println("Hello, World!")
  }
}`
      default:
        return `// Write your code here`
    }
  }

  // Basic code validation
  const validateCode = (codeToValidate: string, lang: string): { isValid: boolean; error?: string } => {
    if (!codeToValidate.trim()) {
      return { isValid: false, error: "Code is empty" }
    }

    try {
      switch (lang) {
        case "javascript":
          // Check for basic syntax errors
          try {
            // This will throw if there's a syntax error
            new Function(codeToValidate)
            return { isValid: true }
          } catch (error: any) {
            return { isValid: false, error: `JavaScript syntax error: ${error.message}` }
          }

        case "python":
          // Check for basic indentation and syntax
          if (codeToValidate.includes("  ") && codeToValidate.includes(":") && !codeToValidate.includes("    ")) {
            return { isValid: false, error: "Python indentation should be 4 spaces" }
          }
          return { isValid: true }

        case "java":
          // Check for basic Java structure
          if (!codeToValidate.includes("class")) {
            return { isValid: false, error: "Java code should contain a class definition" }
          }
          return { isValid: true }

        case "cpp":
        case "c":
          // Check for basic C/C++ structure
          if (!codeToValidate.includes("main")) {
            return { isValid: false, error: `${lang.toUpperCase()} code should contain a main function` }
          }
          return { isValid: true }

        case "html":
          // Check for basic HTML structure
          if (!codeToValidate.includes("<html") && !codeToValidate.includes("<body")) {
            return { isValid: false, error: "HTML should contain basic structure tags" }
          }
          return { isValid: true }

        case "sql":
          // Check for basic SQL keywords
          const sqlKeywords = ["SELECT", "INSERT", "UPDATE", "DELETE", "CREATE", "DROP", "ALTER", "FROM", "WHERE"]
          const hasKeyword = sqlKeywords.some((keyword) => codeToValidate.toUpperCase().includes(keyword))
          if (!hasKeyword) {
            return { isValid: false, error: "SQL should contain at least one SQL keyword" }
          }
          return { isValid: true }

        case "scala":
          // Check for basic Scala structure
          if (!codeToValidate.includes("object") && !codeToValidate.includes("def")) {
            return { isValid: false, error: "Scala code should contain object or def definitions" }
          }
          return { isValid: true }

        default:
          return { isValid: true }
      }
    } catch (error) {
      // If validation itself fails, we'll still run the code
      console.error("Validation error:", error)
      return { isValid: true }
    }
  }

  // Handle code execution with improved error handling and support for unstructured code
  const runCode = () => {
    setIsRunning(true)
    setOutput("")
    setCodeError(null)

    // Get the code to execute
    const codeToRun = code.trim()

    if (!codeToRun) {
      setOutput("Error: No code to run")
      setIsRunning(false)
      return
    }

    // Validate code before running
    const validation = validateCode(codeToRun, language)
    if (!validation.isValid) {
      setCodeError(validation.error || "Invalid code")
      setOutput(`Error: ${validation.error}`)
      setIsRunning(false)
      return
    }

    // Simulate code execution with a delay
    setTimeout(() => {
      try {
        let result = ""

        if (language === "javascript") {
          try {
            // Create a safe evaluation environment
            const consoleOutput: string[] = []
            const mockConsole = {
              log: (...args: any[]) => {
                consoleOutput.push(
                  args.map((arg) => (typeof arg === "object" ? JSON.stringify(arg) : String(arg))).join(" "),
                )
              },
              error: (...args: any[]) => {
                consoleOutput.push(
                  `Error: ${args
                    .map((arg) => (typeof arg === "object" ? JSON.stringify(arg) : String(arg)))
                    .join(" ")}`,
                )
              },
              warn: (...args: any[]) => {
                consoleOutput.push(
                  `Warning: ${args
                    .map((arg) => (typeof arg === "object" ? JSON.stringify(arg) : String(arg)))
                    .join(" ")}`,
                )
              },
            }

            // Create a function from the code string with console redirected
            const safeEval = new Function(
              "console",
              `
                try {
                  ${codeToRun}
                  return "Code executed successfully";
                } catch (error) {
                  return "Error: " + error.message;
                }
              `,
            )

            // Execute the code with our mock console
            const evalResult = safeEval(mockConsole)

            // Combine console output with eval result
            result = consoleOutput.join("\n")
            if (result && evalResult !== "Code executed successfully") {
              result += "\n\n" + evalResult
            } else if (!result) {
              result = evalResult
            }
          } catch (error: any) {
            result = `Error: ${error.message}`
          }
        } else if (language === "python") {
          // Simulate Python execution
          result = "Python Simulation:\n"

          // Handle both structured and unstructured Python code
          const hasPrintStatements = /print\s*$$.*?$$/g.test(codeToRun)

          if (hasPrintStatements) {
            result += "Executing Python code...\n\n"

            // Extract all print statements and simulate their output
            const printMatches = codeToRun.match(/print\s*$$(.*?)$$/g)
            if (printMatches) {
              printMatches.forEach((match) => {
                try {
                  // Extract content inside print()
                  const content = match.substring(match.indexOf("(") + 1, match.lastIndexOf(")"))
                  result += `${content.replace(/['"]/g, "")}\n`
                } catch (e) {
                  result += "Error parsing print statement\n"
                }
              })
              result += "\nExecution completed."
            } else {
              result += "No output detected. Make sure you use print() to display results."
            }
          } else if (codeToRun.includes("def main():")) {
            // Handle structured code with main function
            result += "Found main() function\n"

            // Check if the code calls the main function
            if (codeToRun.includes("main()")) {
              result += "Executing main() function...\n\n"
              result += "Hello, World!\n" // Simulate default output
              result += "Execution completed."
            } else {
              result += "Warning: main() function is defined but never called.\n"
              result += "Add 'main()' at the end of your code to execute it."
            }
          } else {
            // Handle completely unstructured code
            result += "Executing unstructured Python code...\n\n"
            result += "Code executed without output. Use print() statements to see results."
          }
        } else if (language === "html") {
          // For HTML, provide a preview message
          result = "HTML Preview:\n"
          result += "HTML code would render in a browser.\n"

          // Check for basic HTML structure
          const hasDoctype = codeToRun.includes("<!DOCTYPE") || codeToRun.includes("<!doctype")
          const hasHtmlTag = codeToRun.includes("<html")
          const hasHeadTag = codeToRun.includes("<head")
          const hasBodyTag = codeToRun.includes("<body")

          if (!hasDoctype) result += "Warning: Missing <!DOCTYPE html> declaration.\n"
          if (!hasHtmlTag) result += "Warning: Missing <html> tag.\n"
          if (!hasHeadTag) result += "Warning: Missing <head> tag.\n"
          if (!hasBodyTag) result += "Warning: Missing <body> tag.\n"

          // Check for CSS and JavaScript
          const hasCSS = codeToRun.includes("<style") || codeToRun.includes("css")
          const hasJS = codeToRun.includes("<script") || codeToRun.includes("javascript")

          if (hasCSS) result += "CSS styles detected.\n"
          if (hasJS) result += "JavaScript code detected.\n"

          result += "\nHTML execution successful. In a real environment, this would display in a browser."
        } else if (language === "sql") {
          // Simulate SQL execution
          result = "SQL Query Execution:\n"

          // Handle different SQL query types
          if (codeToRun.toLowerCase().includes("select")) {
            result += "Executing SELECT query...\n\n"
            result += "| id | name       | email               |\n"
            result += "|----|-----------|--------------------|\n"
            result += "| 1  | John Doe   | john@example.com    |\n"
            result += "| 2  | Jane Smith | jane@example.com    |\n"
            result += "| 3  | Bob Johnson| bob@example.com     |\n"
            result += "\n3 rows returned. Query executed successfully."
          } else if (codeToRun.toLowerCase().includes("insert")) {
            result += "Executing INSERT query...\n\n"
            result += "1 row(s) inserted successfully."
          } else if (codeToRun.toLowerCase().includes("update")) {
            result += "Executing UPDATE query...\n\n"
            result += "2 row(s) updated successfully."
          } else if (codeToRun.toLowerCase().includes("delete")) {
            result += "Executing DELETE query...\n\n"
            result += "1 row(s) deleted successfully."
          } else if (codeToRun.toLowerCase().includes("create table")) {
            result += "Executing CREATE TABLE query...\n\n"
            result += "Table created successfully."
          } else {
            result += "Executing SQL query...\n\n"
            result += "Query executed successfully."
          }
        } else if (language === "java") {
          // Simulate Java execution
          result = "Java Compilation and Execution:\n"

          // Handle both structured and unstructured Java code
          const hasMainMethod = codeToRun.includes("public static void main")
          const hasClass = codeToRun.includes("class")

          if (hasClass && hasMainMethod) {
            result += "Compiling Java code...\n"
            result += "Compilation successful.\n\n"

            // Look for System.out.println statements
            const printMatches = codeToRun.match(/System\.out\.println\s*$$(.*?)$$;/g)
            if (printMatches) {
              result += "Program output:\n"
              printMatches.forEach((match) => {
                try {
                  // Extract content inside println()
                  const content = match.substring(match.indexOf("(") + 1, match.lastIndexOf(")"))
                  result += `${content.replace(/['"]/g, "")}\n`
                } catch (e) {
                  result += "Error parsing println statement\n"
                }
              })
            } else {
              result += "No output detected. Make sure you use System.out.println() to display results."
            }
          } else if (hasMainMethod) {
            result += "Warning: Found main method but missing proper class declaration.\n"
            result += "Java programs must have a proper class declaration.\n\n"
            result += "Attempting to execute anyway...\n"
            result += "Hello, World!"
          } else if (hasClass) {
            result += "Warning: Found class but missing main method.\n"
            result += "Java programs must have a 'public static void main(String[] args)' method.\n\n"
            result += "Cannot execute without main method."
          } else {
            result += "Error: Missing proper Java structure.\n"
            result += "Java programs must have a class with a 'public static void main(String[] args)' method."
          }
        } else if (language === "cpp" || language === "c") {
          // Simulate C/C++ execution
          const langName = language === "cpp" ? "C++" : "C"
          result = `${langName} Compilation and Execution:\n`

          // Handle both structured and unstructured C/C++ code
          const hasMainFunction = codeToRun.includes("int main(") || codeToRun.includes("void main(")
          const hasReturn = codeToRun.includes("return 0;") || codeToRun.includes("return 0")

          if (hasMainFunction) {
            result += `Compiling ${langName} code...\n`
            result += "Compilation successful.\n\n"

            // Look for printf or cout statements
            let printMatches
            if (language === "cpp") {
              printMatches = codeToRun.match(/cout\s*<<\s*(.*?);/g)
            } else {
              printMatches = codeToRun.match(/printf\s*$$(.*?)$$;/g)
            }

            if (printMatches) {
              result += "Program output:\n"
              printMatches.forEach((match) => {
                try {
                  let content
                  if (language === "cpp") {
                    content = match.substring(match.indexOf("<<") + 2, match.length - 1).trim()
                  } else {
                    content = match.substring(match.indexOf("(") + 1, match.lastIndexOf(")"))
                  }
                  result += `${content.replace(/['"]/g, "")}\n`
                } catch (e) {
                  result += `Error parsing ${language === "cpp" ? "cout" : "printf"} statement\n`
                }
              })
            } else {
              result += `No output detected. Make sure you use ${language === "cpp" ? "cout" : "printf()"} to display results.`
            }

            if (!hasReturn && language === "cpp") {
              result += "\nWarning: Missing 'return 0;' statement at the end of main function."
            }
          } else {
            // Handle unstructured code
            result += `Warning: Missing main function.\n`
            result += `${langName} programs should have an 'int main()' function.\n\n`
            result += "Attempting to execute anyway...\n"

            // Try to find any output statements
            let printMatches
            if (language === "cpp") {
              printMatches = codeToRun.match(/cout\s*<<\s*(.*?);/g)
            } else {
              printMatches = codeToRun.match(/printf\s*$$(.*?)$$;/g)
            }

            if (printMatches) {
              result += "Program output:\n"
              printMatches.forEach((match) => {
                try {
                  let content
                  if (language === "cpp") {
                    content = match.substring(match.indexOf("<<") + 2, match.length - 1).trim()
                  } else {
                    content = match.substring(match.indexOf("(") + 1, match.lastIndexOf(")"))
                  }
                  result += `${content.replace(/['"]/g, "")}\n`
                } catch (e) {
                  result += `Error parsing ${language === "cpp" ? "cout" : "printf"} statement\n`
                }
              })
            } else {
              result += `No output detected. Make sure you use ${language === "cpp" ? "cout" : "printf()"} to display results.`
            }
          }
        } else if (language === "scala") {
          // Simulate Scala execution
          result = "Scala Compilation and Execution:\n"

          // Handle both structured and unstructured Scala code
          const hasMainMethod = codeToRun.includes("def main")
          const hasObject = codeToRun.includes("object")

          if (hasObject && hasMainMethod) {
            result += "Compiling Scala code...\n"
            result += "Compilation successful.\n\n"

            // Look for println statements
            const printMatches = codeToRun.match(/println\s*$$(.*?)$$/g)
            if (printMatches) {
              result += "Program output:\n"
              printMatches.forEach((match) => {
                try {
                  // Extract content inside println()
                  const content = match.substring(match.indexOf("(") + 1, match.lastIndexOf(")"))
                  result += `${content.replace(/['"]/g, "")}\n`
                } catch (e) {
                  result += "Error parsing println statement\n"
                }
              })
            } else {
              result += "No output detected. Make sure you use println() to display results."
            }
          } else if (hasMainMethod) {
            result += "Warning: Found main method but missing proper object declaration.\n"
            result += "Scala programs typically have an object with a main method.\n\n"
            result += "Attempting to execute anyway...\n"
            result += "Hello, World!"
          } else if (hasObject) {
            result += "Warning: Found object but missing main method.\n"
            result += "Scala programs need a 'def main(args: Array[String])' method to be executable.\n\n"
            result += "Cannot execute without main method."
          } else {
            // Handle unstructured code
            result += "Executing unstructured Scala code...\n\n"

            // Look for println statements
            const printMatches = codeToRun.match(/println\s*$$(.*?)$$/g)
            if (printMatches) {
              result += "Program output:\n"
              printMatches.forEach((match) => {
                try {
                  // Extract content inside println()
                  const content = match.substring(match.indexOf("(") + 1, match.lastIndexOf(")"))
                  result += `${content.replace(/['"]/g, "")}\n`
                } catch (e) {
                  result += "Error parsing println statement\n"
                }
              })
            } else {
              result += "No output detected. Make sure you use println() to display results."
            }
          }
        } else {
          // Generic execution for other languages
          result = `Simulated execution for ${language}:\n`
          result += "Code appears to be valid.\n"
          result += "Execution completed successfully."
        }

        setOutput(result)
      } catch (error: any) {
        setOutput(`Error: ${error.message}`)
      } finally {
        setIsRunning(false)
      }
    }, 1000)
  }

  // Submit code function
  const handleSubmitCode = () => {
    setIsSubmitting(true)
    setCodeError(null)

    // Get the code to submit
    const codeToSubmit = code.trim()

    if (!codeToSubmit) {
      setCodeError("Cannot submit empty code")
      setIsSubmitting(false)
      return
    }

    // Validate code before submitting
    const validation = validateCode(codeToSubmit, language)
    if (!validation.isValid) {
      setCodeError(validation.error || "Invalid code")
      setIsSubmitting(false)
      return
    }

    // Simulate submission with a delay
    setTimeout(() => {
      try {
        // Notify parent of final code
        if (config.onCodeChange) {
          config.onCodeChange(codeToSubmit)
        }

        // Set submitted state
        setIsSubmitted(true)
        setOutput("Code submitted successfully!")
      } catch (error: any) {
        setCodeError(`Submission error: ${error.message}`)
      } finally {
        setIsSubmitting(false)
      }
    }, 1000)
  }

  // Copy code to clipboard
  const copyCode = () => {
    try {
      navigator.clipboard.writeText(code)
      setIsCopied(true)
      setTimeout(() => setIsCopied(false), 2000)
    } catch (error) {
      console.error("Failed to copy code:", error)
    }
  }

  return (
    <div className="border rounded-lg overflow-hidden bg-gray-50 mb-6">
      <div className="flex items-center justify-between p-2 bg-gray-100 border-b">
        <div className="flex items-center">
          <span className="text-sm font-medium mr-2">Language:</span>
          <Select value={language} onValueChange={handleLanguageChange}>
            <SelectTrigger className="w-[180px] h-8">
              <SelectValue placeholder="Select language" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="html">HTML/CSS</SelectItem>
              <SelectItem value="javascript">JavaScript</SelectItem>
              <SelectItem value="python">Python</SelectItem>
              <SelectItem value="java">Java</SelectItem>
              <SelectItem value="cpp">C++</SelectItem>
              <SelectItem value="c">C</SelectItem>
              <SelectItem value="sql">SQL</SelectItem>
              <SelectItem value="scala">Scala</SelectItem>
              <SelectItem value="text">Plain Text</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="flex items-center space-x-2">
          <Button variant="outline" size="sm" onClick={copyCode} className="h-8 text-xs">
            {isCopied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
            {isCopied ? "Copied!" : "Copy"}
          </Button>
          <Button
            variant="default"
            size="sm"
            onClick={runCode}
            disabled={isRunning}
            className="h-8 text-xs bg-green-600 hover:bg-green-700"
          >
            {isRunning ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <Play className="h-4 w-4 mr-1" />}
            Run
          </Button>
        </div>
      </div>
      <div className="flex flex-col md:flex-row">
        <div className="w-full md:w-1/2 border-r">
          <textarea
            value={code}
            onChange={(e) => {
              setCode(e.target.value)
              setCodeError(null)
              setIsSubmitted(false)
            }}
            className={`w-full h-80 p-4 font-mono text-sm bg-white text-gray-900 focus:outline-none resize-none ${
              isSubmitted ? "bg-gray-50" : ""
            }`}
            spellCheck="false"
            disabled={isSubmitted}
          />
        </div>
        <div className="w-full md:w-1/2">
          <div className="p-2 bg-gray-800 text-xs font-medium text-white">Output</div>
          <pre className="p-4 font-mono text-sm h-[calc(80rem/4-2rem)] overflow-auto bg-gray-900 text-gray-100">
            {isRunning ? "Running..." : output || "Run your code to see the output here"}
          </pre>
        </div>
      </div>
      {codeError && (
        <div className="p-2 bg-red-100 text-red-700 text-sm border-t border-red-200">
          <strong>Error:</strong> {codeError}
        </div>
      )}
      {isSubmitted && (
        <div className="p-2 bg-green-100 text-green-700 text-sm border-t border-green-200">
          <strong>Success:</strong> Your code has been submitted successfully!
        </div>
      )}
      <div className="p-2 bg-gray-100 border-t flex justify-end">
        <Button
          onClick={handleSubmitCode}
          disabled={isSubmitting || isSubmitted}
          className="bg-blue-600 hover:bg-blue-700 text-white"
        >
          {isSubmitting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Submitting...
            </>
          ) : isSubmitted ? (
            <>
              <Check className="mr-2 h-4 w-4" />
              Submitted
            </>
          ) : (
            <>
              <Send className="mr-2 h-4 w-4" />
              Submit Code
            </>
          )}
        </Button>
      </div>
    </div>
  )
}
