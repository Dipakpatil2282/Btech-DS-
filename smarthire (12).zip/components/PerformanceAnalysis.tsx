"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import {
  CheckCircle2,
  XCircle,
  AlertTriangle,
  BarChart2,
  MessageSquare,
  Brain,
  Code,
  Trophy,
  Download,
  Video,
} from "lucide-react"
import { useAuth } from "@/contexts/auth-context"
import { supabase } from "@/lib/supabase"

interface PerformanceAnalysisProps {
  jobRole: string
  level: "beginner" | "intermediate" | "advanced"
  answers: string[]
  scores: number[]
  tabSwitchCount: number
  onFinish: () => void
  recordingUrl?: string | null
}

export default function PerformanceAnalysis(props: PerformanceAnalysisProps) {
  // Store props in state to avoid re-renders from prop changes
  const [data] = useState({
    jobRole: props.jobRole,
    level: props.level,
    answers: props.answers,
    scores: props.scores,
    tabSwitchCount: props.tabSwitchCount,
    onFinish: props.onFinish,
    recordingUrl: props.recordingUrl,
  })

  // Analysis state
  const [finalScores, setFinalScores] = useState({
    overall: 0,
    relevance: 0,
    communication: 0,
    behavior: 0,
    coding: 0,
  })

  const [feedback, setFeedback] = useState({
    points: [] as string[],
    strengths: [] as string[],
    improvements: [] as string[],
  })

  const [loading, setLoading] = useState(true)
  const [correctAnswers, setCorrectAnswers] = useState(0)
  const [totalQuestions, setTotalQuestions] = useState(0)

  // Refs
  const analysisCompleted = useRef(false)
  const { user } = useAuth()
  const geminiApiKeyRef = useRef("AIzaSyAst5EV-cLw47GDcu_lUnwT5YeXO-ilrE8")

  // Run analysis once
  useEffect(() => {
    // Skip if already analyzed
    if (analysisCompleted.current) return

    // Mark as analyzed immediately to prevent multiple runs
    analysisCompleted.current = true

    // Log if we have a recording URL
    if (data.recordingUrl) {
      console.log("Performance Analysis received recording URL:", data.recordingUrl)
    } else {
      console.log("Performance Analysis did not receive a recording URL")
    }

    const analyzeAnswers = async () => {
      try {
        // Simulate analysis delay
        await new Promise((resolve) => setTimeout(resolve, 2000))

        // Count total questions with answers
        const answeredQuestions = data.answers.filter((answer) => answer && answer.trim() !== "").length
        setTotalQuestions(answeredQuestions)

        // Count correct answers (scores >= 6 are considered correct)
        const correctCount = data.scores.filter((score) => score >= 6).length
        setCorrectAnswers(correctCount)

        // Calculate accuracy percentage - if no correct answers, accuracy is 0
        const accuracyPercentage = correctCount > 0 ? (correctCount / answeredQuestions) * 100 : 0

        // Generate scores based on accuracy and behavior
        const relevance = Math.min(Math.round(accuracyPercentage / 10), 10) // 0-10 based on accuracy

        // If no correct answers, communication score should be lower
        const communication =
          correctCount > 0
            ? Math.min(Math.max(5, Math.round(accuracyPercentage / 12)), 10) // 5-10 range
            : Math.min(Math.max(3, Math.round(accuracyPercentage / 20)), 5) // 3-5 range for no correct answers

        const behavior = Math.min(Math.max(10 - data.tabSwitchCount * 2, 1), 10) // Penalize tab switching

        // Calculate coding score based on code-related questions
        const codingAnswers = data.answers.filter(
          (answer, index) =>
            answer && (answer.includes("function") || answer.includes("class") || answer.includes("<")),
        )

        // If no correct answers, coding score should be 0
        const codingScore =
          correctCount > 0 && codingAnswers.length > 0 ? Math.min(Math.round(accuracyPercentage / 10) + 1, 10) : 0

        // Calculate overall score with weighted components
        // If no correct answers, overall score should be very low
        const overall =
          correctCount > 0
            ? Math.min(Math.round(relevance * 0.4 + communication * 0.2 + behavior * 0.2 + codingScore * 0.2), 10)
            : Math.min(Math.round(accuracyPercentage / 50), 2) // Max 2 if no correct answers

        // Set scores
        setFinalScores({
          overall,
          relevance,
          communication,
          behavior,
          coding: codingScore,
        })

        // Generate feedback based on performance
        const strengthsList: string[] = []
        const improvementsList: string[] = []
        const feedbackList: string[] = []

        // Add strengths based on scores
        if (relevance >= 7) {
          strengthsList.push(`Strong understanding of ${data.level} ${data.jobRole} concepts`)
        }
        if (communication >= 7) {
          strengthsList.push("Excellent communication skills with clear responses")
        }
        if (behavior >= 8) {
          strengthsList.push("Professional behavior throughout the interview")
        }
        if (codingScore >= 7) {
          strengthsList.push("Good coding skills and problem-solving abilities")
        }
        if (correctCount > 0) {
          strengthsList.push(`Correctly answered ${correctCount} out of ${answeredQuestions} questions`)
        }

        // Add improvements based on scores
        if (relevance < 7) {
          improvementsList.push(`Deepen your knowledge of ${data.level} ${data.jobRole} concepts`)
        }
        if (communication < 7) {
          improvementsList.push("Practice explaining technical concepts more clearly")
        }
        if (behavior < 8) {
          improvementsList.push("Maintain focus during interviews and avoid distractions")
        }
        if (codingScore < 7) {
          improvementsList.push("Improve your coding skills with more practice")
        }
        if (correctCount < answeredQuestions / 2) {
          improvementsList.push("Review fundamental concepts to improve accuracy of answers")
        }

        // If no correct answers, add specific feedback
        if (correctCount === 0) {
          improvementsList.push("Focus on providing more relevant and complete answers to technical questions")
          improvementsList.push("Study core concepts related to your field before attempting interviews")
        }

        // Add general feedback
        if (overall >= 8) {
          feedbackList.push(`Excellent performance for a ${data.level} ${data.jobRole} position`)
          feedbackList.push("You demonstrated strong technical knowledge and communication skills")
        } else if (overall >= 6) {
          feedbackList.push(`Good performance for a ${data.level} ${data.jobRole} position`)
          feedbackList.push("You have a solid foundation but could improve in some areas")
        } else if (overall >= 3) {
          feedbackList.push(`You need more preparation for a ${data.level} ${data.jobRole} position`)
          feedbackList.push("Focus on strengthening your technical knowledge and interview skills")
        } else {
          feedbackList.push(`Significant improvement needed for a ${data.level} ${data.jobRole} position`)
          feedbackList.push("Consider additional training and practice before attempting technical interviews")
        }

        // Set feedback
        setFeedback({
          points: feedbackList,
          strengths: strengthsList,
          improvements: improvementsList,
        })

        // Save to database if user exists
        if (user) {
          try {
            await supabase.from("interview_results").insert({
              user_id: user.id,
              job_role: data.jobRole,
              level: data.level,
              score: overall,
              relevance_score: relevance,
              communication_score: communication,
              behavior_score: behavior,
              coding_score: codingScore,
              strengths: strengthsList,
              improvements: improvementsList,
              feedback: feedbackList,
              status: "completed",
              date: new Date().toISOString(),
              has_recording: !!data.recordingUrl,
            })
          } catch (err) {
            console.error("Error saving interview results:", err)
          }
        }
      } catch (error) {
        console.error("Error analyzing answers:", error)
      } finally {
        // Always set loading to false
        setLoading(false)
      }
    }

    analyzeAnswers()

    // No cleanup needed
  }, [])

  // Download recording with improved error handling
  const downloadRecording = () => {
    if (data.recordingUrl) {
      try {
        console.log("Initiating download for recording URL:", data.recordingUrl)

        // Create a temporary anchor element
        const a = document.createElement("a")
        a.href = data.recordingUrl
        a.download = `interview-recording-${new Date().toISOString()}.webm`

        // Append to body, click, and remove
        document.body.appendChild(a)
        a.click()

        // Small delay before removing to ensure download starts
        setTimeout(() => {
          document.body.removeChild(a)
        }, 100)

        console.log("Download initiated successfully")
      } catch (error) {
        console.error("Error downloading recording:", error)
        alert("There was an error downloading the recording. Please try again.")
      }
    } else {
      console.error("Attempted to download recording but URL is not available")
      alert("Recording is not available for download.")
    }
  }

  // Helper functions
  const getScoreColor = (score: number) => {
    if (score >= 8) return "text-green-500"
    if (score >= 5) return "text-yellow-500"
    return "text-red-500"
  }

  const getScoreProgressColor = (score: number) => {
    if (score >= 8) return "bg-green-500"
    if (score >= 5) return "bg-yellow-500"
    return "bg-red-500"
  }

  const getLevelBadgeColor = () => {
    if (data.level === "beginner") return "bg-green-100 text-green-800"
    if (data.level === "intermediate") return "bg-blue-100 text-blue-800"
    return "bg-purple-100 text-purple-800"
  }

  // Render loading state
  if (loading) {
    return (
      <div className="max-w-4xl mx-auto bg-white shadow-xl rounded-lg overflow-hidden transform transition-all">
        <div className="p-8 bg-gradient-to-r from-purple-600 to-indigo-700 text-white">
          <h2 className="text-4xl font-bold mb-2">Performance Analysis</h2>
          <p className="text-lg">Analyzing your interview performance...</p>
        </div>
        <div className="p-16 text-center">
          <div className="animate-spin rounded-full h-20 w-20 border-t-4 border-b-4 border-purple-500 mx-auto mb-6"></div>
          <p className="text-xl text-gray-600">Analyzing your interview performance...</p>
          <p className="text-sm text-gray-500 mt-2">This may take a few moments</p>
        </div>
      </div>
    )
  }

  // Render results
  return (
    <div className="max-w-4xl mx-auto bg-white shadow-xl rounded-lg overflow-hidden transform transition-all">
      <div className="p-8 bg-gradient-to-r from-purple-600 to-indigo-700 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-4xl font-bold mb-2">Performance Analysis</h2>
            <div className="flex items-center">
              <p className="text-lg mr-2">Job Role: {data.jobRole}</p>
              <span className={`px-3 py-1 rounded-full text-xs font-semibold ${getLevelBadgeColor()}`}>
                {data.level.charAt(0).toUpperCase() + data.level.slice(1)}
              </span>
            </div>
          </div>
          <div className="hidden md:block">
            <Trophy className="h-16 w-16 text-yellow-300 opacity-80" />
          </div>
        </div>
      </div>

      <div className="p-8">
        <div className="mb-10 text-center">
          <div className="relative inline-block">
            <div className="w-40 h-40 rounded-full bg-gray-100 flex items-center justify-center mx-auto mb-4 relative overflow-hidden">
              <div
                className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-green-500 to-blue-500 transition-all duration-1000 ease-out"
                style={{ height: `${finalScores.overall * 10}%`, opacity: 0.7 }}
              ></div>
              <div className="relative z-10 flex flex-col items-center">
                <div className={`text-6xl font-bold ${getScoreColor(finalScores.overall)}`}>{finalScores.overall}</div>
                <div className="text-xl text-gray-600">/10</div>
              </div>
            </div>
            <h3 className="text-2xl font-bold mb-2">Overall Score</h3>
            <p className="text-gray-500">Based on your interview performance</p>
            <p className="text-sm text-gray-500 mt-1">
              Correctly answered {correctAnswers} out of {totalQuestions} questions
            </p>
          </div>
        </div>

        {data.recordingUrl ? (
          <div className="mb-10 bg-white p-6 rounded-xl shadow-md border border-green-100">
            <h3 className="text-xl font-bold mb-4 text-green-700 flex items-center">
              <Video className="mr-2 h-5 w-5" />
              Interview Recording
            </h3>
            <div className="flex flex-col sm:flex-row items-center gap-4">
              <video
                src={data.recordingUrl}
                controls
                className="w-full sm:w-2/3 h-auto rounded-lg border border-gray-300"
              />
              <div className="flex flex-col gap-2 w-full sm:w-1/3">
                <Button onClick={downloadRecording} className="bg-green-600 hover:bg-green-700 text-white py-6">
                  <Download className="mr-2 h-5 w-5" />
                  <span className="text-lg">Download Recording</span>
                </Button>
                <p className="text-sm text-gray-600 mt-2">
                  Your screen recording is available for download. This recording will be lost if you navigate away from
                  this page.
                </p>
              </div>
            </div>
          </div>
        ) : (
          <div className="mb-10 bg-white p-6 rounded-xl shadow-md border border-gray-100">
            <h3 className="text-xl font-bold mb-4 text-gray-800 flex items-center">
              <Video className="mr-2 h-5 w-5" />
              Interview Recording
            </h3>
            <div className="p-8 text-center">
              <p className="text-gray-500">No recording was available for this interview session.</p>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10">
          <div className="bg-white p-6 rounded-xl shadow-md border border-gray-100 hover:shadow-lg transition-shadow">
            <div className="flex items-center mb-4">
              <div className="p-3 rounded-full bg-purple-100 mr-4">
                <Brain className="h-6 w-6 text-purple-600" />
              </div>
              <div>
                <h4 className="text-lg font-semibold">Technical Relevance</h4>
                <p className="text-sm text-gray-500">How well you addressed technical questions</p>
              </div>
            </div>
            <div className="flex items-center mb-3">
              <span className={`text-3xl font-bold ${getScoreColor(finalScores.relevance)}`}>
                {finalScores.relevance}
              </span>
              <span className="text-gray-400 ml-1">/10</span>
            </div>
            <Progress
              value={finalScores.relevance * 10}
              className="h-2 bg-gray-100"
              indicatorClassName={getScoreProgressColor(finalScores.relevance)}
            />
          </div>

          <div className="bg-white p-6 rounded-xl shadow-md border border-gray-100 hover:shadow-lg transition-shadow">
            <div className="flex items-center mb-4">
              <div className="p-3 rounded-full bg-blue-100 mr-4">
                <MessageSquare className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <h4 className="text-lg font-semibold">Communication</h4>
                <p className="text-sm text-gray-500">Clarity and structure of your responses</p>
              </div>
            </div>
            <div className="flex items-center mb-3">
              <span className={`text-3xl font-bold ${getScoreColor(finalScores.communication)}`}>
                {finalScores.communication}
              </span>
              <span className="text-gray-400 ml-1">/10</span>
            </div>
            <Progress
              value={finalScores.communication * 10}
              className="h-2 bg-gray-100"
              indicatorClassName={getScoreProgressColor(finalScores.communication)}
            />
          </div>

          <div className="bg-white p-6 rounded-xl shadow-md border border-gray-100 hover:shadow-lg transition-shadow">
            <div className="flex items-center mb-4">
              <div className="p-3 rounded-full bg-green-100 mr-4">
                <BarChart2 className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <h4 className="text-lg font-semibold">Professional Behavior</h4>
                <p className="text-sm text-gray-500">Focus and professionalism during interview</p>
              </div>
            </div>
            <div className="flex items-center mb-3">
              <span className={`text-3xl font-bold ${getScoreColor(finalScores.behavior)}`}>
                {finalScores.behavior}
              </span>
              <span className="text-gray-400 ml-1">/10</span>
            </div>
            <Progress
              value={finalScores.behavior * 10}
              className="h-2 bg-gray-100"
              indicatorClassName={getScoreProgressColor(finalScores.behavior)}
            />
          </div>

          <div className="bg-white p-6 rounded-xl shadow-md border border-gray-100 hover:shadow-lg transition-shadow">
            <div className="flex items-center mb-4">
              <div className="p-3 rounded-full bg-orange-100 mr-4">
                <Code className="h-6 w-6 text-orange-600" />
              </div>
              <div>
                <h4 className="text-lg font-semibold">Coding Skills</h4>
                <p className="text-sm text-gray-500">Quality of your code and problem-solving</p>
              </div>
            </div>
            <div className="flex items-center mb-3">
              <span className={`text-3xl font-bold ${getScoreColor(finalScores.coding)}`}>{finalScores.coding}</span>
              <span className="text-gray-400 ml-1">/10</span>
            </div>
            <Progress
              value={finalScores.coding * 10}
              className="h-2 bg-gray-100"
              indicatorClassName={getScoreProgressColor(finalScores.coding)}
            />
          </div>
        </div>

        <div className="mb-10 bg-white p-6 rounded-xl shadow-md border border-gray-100">
          <h3 className="text-xl font-bold mb-4 text-gray-800">Feedback Summary</h3>
          <div className="space-y-3">
            {feedback.points.map((point, index) => (
              <div key={index} className="flex items-start p-3 bg-blue-50 rounded-lg">
                <AlertTriangle className="mr-3 text-blue-500 mt-1 flex-shrink-0" />
                <p className="text-gray-700">{point}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10">
          <div className="bg-white p-6 rounded-xl shadow-md border border-gray-100">
            <h3 className="text-xl font-bold mb-4 text-green-600 flex items-center">
              <CheckCircle2 className="mr-2 h-5 w-5" />
              Strengths
            </h3>
            <div className="space-y-3">
              {feedback.strengths.length > 0 ? (
                feedback.strengths.map((strength, index) => (
                  <div key={index} className="flex items-start p-3 bg-green-50 rounded-lg">
                    <CheckCircle2 className="mr-3 text-green-500 mt-1 flex-shrink-0" />
                    <p className="text-gray-700">{strength}</p>
                  </div>
                ))
              ) : (
                <p className="text-gray-500 italic">
                  No specific strengths identified. Focus on improving your technical knowledge and interview skills.
                </p>
              )}
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-md border border-gray-100">
            <h3 className="text-xl font-bold mb-4 text-amber-600 flex items-center">
              <XCircle className="mr-2 h-5 w-5" />
              Areas for Improvement
            </h3>
            <div className="space-y-3">
              {feedback.improvements.length > 0 ? (
                feedback.improvements.map((improvement, index) => (
                  <div key={index} className="flex items-start p-3 bg-amber-50 rounded-lg">
                    <XCircle className="mr-3 text-amber-500 mt-1 flex-shrink-0" />
                    <p className="text-gray-700">{improvement}</p>
                  </div>
                ))
              ) : (
                <p className="text-gray-500 italic">No specific areas for improvement identified.</p>
              )}
            </div>
          </div>
        </div>

        <div className="text-center">
          <Button
            onClick={data.onFinish}
            className="bg-gradient-to-r from-purple-600 to-indigo-700 hover:from-purple-700 hover:to-indigo-800 text-white px-10 py-3 rounded-full text-lg font-semibold shadow-lg hover:shadow-xl transition-all"
          >
            Return to Home
          </Button>
        </div>
      </div>
    </div>
  )
}
