"use client"

import { useState, useEffect } from "react"
import { Wifi, WifiOff } from "lucide-react"
import { isOnline, checkEndpointReachable } from "@/utils/network-status"

interface NetworkStatusProps {
  onStatusChange?: (online: boolean) => void
}

export default function NetworkStatus({ onStatusChange }: NetworkStatusProps) {
  const [online, setOnline] = useState(isOnline())
  const [showMessage, setShowMessage] = useState(false)

  useEffect(() => {
    const handleOnline = () => {
      setOnline(true)
      setShowMessage(true)
      if (onStatusChange) onStatusChange(true)

      // Hide the message after 5 seconds
      setTimeout(() => setShowMessage(false), 5000)
    }

    const handleOffline = () => {
      setOnline(false)
      setShowMessage(true)
      if (onStatusChange) onStatusChange(false)
    }

    // Check if Supabase is reachable
    const checkSupabase = async () => {
      const supabaseReachable = await checkEndpointReachable("https://jwasbuyknhzmbdckqtdd.supabase.co")
      if (!supabaseReachable && online) {
        // We're online but Supabase is not reachable
        setShowMessage(true)
      }
    }

    window.addEventListener("online", handleOnline)
    window.addEventListener("offline", handleOffline)

    // Initial check
    checkSupabase()

    return () => {
      window.removeEventListener("online", handleOnline)
      window.removeEventListener("offline", handleOffline)
    }
  }, [onStatusChange])

  if (!showMessage) return null

  return (
    <div
      className={`fixed bottom-4 right-4 z-50 p-4 rounded-lg shadow-lg ${online ? "bg-green-100 dark:bg-green-900/30" : "bg-red-100 dark:bg-red-900/30"}`}
    >
      <div className="flex items-center">
        {online ? (
          <Wifi className="h-5 w-5 text-green-600 dark:text-green-400 mr-2" />
        ) : (
          <WifiOff className="h-5 w-5 text-red-600 dark:text-red-400 mr-2" />
        )}
        <div>
          {online ? (
            <p className="text-green-800 dark:text-green-200 text-sm font-medium">You're back online</p>
          ) : (
            <div>
              <p className="text-red-800 dark:text-red-200 text-sm font-medium">You're offline</p>
              <p className="text-red-600 dark:text-red-300 text-xs">
                Authentication services may not work until you reconnect
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
