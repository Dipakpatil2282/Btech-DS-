"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { supabase } from "@/lib/supabase"
import { useAuth } from "@/contexts/auth-context"
import { Calendar, BarChart2, Award, ChevronRight, AlertTriangle } from "lucide-react"
import { Button } from "./ui/button"
import Link from "next/link"
import { createInterviewResultsTable } from "@/lib/createTables"

interface Interview {
  id: number
  job_role: string
  level: string
  score: number
  date: string
  status: string
}

export default function PastInterviews() {
  const { user } = useAuth()
  const [interviews, setInterviews] = useState<Interview[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let isMounted = true

    const fetchInterviews = async () => {
      if (!user) return

      try {
        // Check if we're online first
        if (typeof window !== "undefined" && !navigator.onLine) {
          if (isMounted) {
            setInterviews([])
            setError("You are currently offline. Interview history will load when you're back online.")
            setIsLoading(false)
          }
          return
        }

        // Try to create the table if it doesn't exist
        await createInterviewResultsTable()

        // Add timeout to the query
        const { data, error } = await supabase
          .from("interview_results")
          .select("*")
          .eq("user_id", user.id)
          .order("created_at", { ascending: false })
          .timeout(8000) // 8 second timeout

        if (error) {
          // Handle network errors specifically
          if (
            error.message?.includes("Failed to fetch") ||
            error.code === "NETWORK_ERROR" ||
            error.code === "TIMEOUT"
          ) {
            throw new Error(
              "Network error: Unable to load interview history. Please check your connection and try again.",
            )
          }

          if (error.message.includes("does not exist")) {
            // Table doesn't exist, just return empty array
            if (isMounted) setInterviews([])
          } else {
            throw error
          }
        } else {
          if (isMounted) setInterviews(data || [])
        }
      } catch (err: any) {
        console.error("Error fetching interviews:", err)
        if (isMounted) {
          // Provide a user-friendly error message
          if (err.message?.includes("Network error") || err.message?.includes("Failed to fetch")) {
            setError(
              "Unable to load interview history due to network issues. Please check your connection and try again.",
            )
          } else {
            setError(err.message || "Failed to load interview history")
          }
        }
      } finally {
        if (isMounted) setIsLoading(false)
      }
    }

    // Only fetch if user exists
    if (user) {
      fetchInterviews()
    }

    return () => {
      isMounted = false
    }
  }, [user])

  const getScoreColor = (score: number) => {
    if (score >= 8) return "text-emerald-500"
    if (score >= 5) return "text-amber-500"
    return "text-rose-500"
  }

  const getScoreBg = (score: number) => {
    if (score >= 8) return "bg-emerald-500"
    if (score >= 5) return "bg-amber-500"
    return "bg-rose-500"
  }

  const getLevelBadge = (level: string) => {
    switch (level) {
      case "beginner":
        return "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-400"
      case "intermediate":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400"
      case "advanced":
        return "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-400"
    }
  }

  if (isLoading) {
    return (
      <Card className="border-gray-700 bg-gray-800/50 backdrop-blur-sm shadow-xl">
        <CardHeader>
          <CardTitle className="text-white">Past Interviews</CardTitle>
          <CardDescription className="text-gray-400">Loading your interview history...</CardDescription>
        </CardHeader>
        <CardContent className="flex justify-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-violet-500"></div>
        </CardContent>
      </Card>
    )
  }

  if (error) {
    return (
      <Card className="border-gray-700 bg-gray-800/50 backdrop-blur-sm shadow-xl">
        <CardHeader>
          <CardTitle className="text-white">Past Interviews</CardTitle>
          <CardDescription className="text-gray-400">Your interview history</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="bg-rose-900/30 text-rose-300 p-4 rounded-md flex items-start">
            <AlertTriangle className="h-5 w-5 mr-3 mt-0.5 flex-shrink-0" />
            <p>Error loading interview history. Please try again later.</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="border-gray-700 bg-gray-800/50 backdrop-blur-sm shadow-xl">
      <CardHeader>
        <CardTitle className="text-white flex items-center">
          <Award className="h-5 w-5 mr-2 text-violet-400" />
          Past Interviews
        </CardTitle>
        <CardDescription className="text-gray-400">Your interview history and performance</CardDescription>
      </CardHeader>
      <CardContent>
        {interviews.length === 0 ? (
          <div className="text-center py-8">
            <div className="bg-gray-800 rounded-full p-3 inline-flex mb-4">
              <BarChart2 className="h-6 w-6 text-gray-400" />
            </div>
            <h3 className="text-lg font-medium text-gray-300 mb-2">No interviews yet</h3>
            <p className="text-gray-500 mb-4">Complete your first interview to see your performance here</p>
            <Link href="/">
              <Button className="gradient-bg transition-all duration-300">Start an Interview</Button>
            </Link>
          </div>
        ) : (
          <div className="space-y-4">
            {interviews.map((interview) => (
              <div
                key={interview.id}
                className="p-4 rounded-lg border border-gray-700 bg-gray-800/30 hover:bg-gray-800/50 transition-all duration-300 shadow-glow-hover"
              >
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h3 className="text-lg font-medium text-white">{interview.job_role}</h3>
                    <div className="flex items-center mt-1">
                      <span className={`text-xs px-2 py-1 rounded-full ${getLevelBadge(interview.level)}`}>
                        {interview.level.charAt(0).toUpperCase() + interview.level.slice(1)}
                      </span>
                      <span className="text-gray-400 text-sm ml-3 flex items-center">
                        <Calendar className="h-3 w-3 mr-1" />
                        {new Date(interview.date).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                  <div className="flex flex-col items-center">
                    <div className={`text-2xl font-bold ${getScoreColor(interview.score)}`}>{interview.score}/10</div>
                    <div className="w-full h-1.5 bg-gray-700 rounded-full mt-1 overflow-hidden">
                      <div
                        className={`h-full ${getScoreBg(interview.score)}`}
                        style={{ width: `${interview.score * 10}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
                <div className="flex justify-between items-center mt-2">
                  <span className="text-gray-400 text-sm">
                    Status: <span className="text-violet-400">{interview.status}</span>
                  </span>
                  <Link href={`/interview-results/${interview.id}`}>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-violet-400 hover:text-violet-300 hover:bg-violet-900/20 p-1"
                    >
                      <span className="mr-1">View Details</span>
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
