"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Calendar, Clock, CheckCircle } from "lucide-react"
import { useAuth } from "@/contexts/auth-context"

interface ScheduleInterviewProps {
  jobRole: string
  level: "beginner" | "intermediate" | "advanced"
  onClose: () => void
}

export default function ScheduleInterview({ jobRole, level, onClose }: ScheduleInterviewProps) {
  const [date, setDate] = useState("")
  const [time, setTime] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const { user } = useAuth()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    setError(null)

    try {
      // Validate inputs
      if (!date || !time) {
        throw new Error("Please select both date and time")
      }

      // Get today's date
      const today = new Date()
      today.setHours(0, 0, 0, 0)

      // Get selected date
      const selectedDate = new Date(date)
      selectedDate.setHours(0, 0, 0, 0)

      // Check if date is in the past
      if (selectedDate < today) {
        throw new Error("Please select a future date")
      }

      // Send data to API
      const response = await fetch("/api/send-email", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: user?.email,
          name: user?.user_metadata?.name || "User",
          jobRole,
          level,
          date,
          time,
          userId: user?.id,
        }),
      })

      if (!response.ok) {
        const data = await response.json()
        throw new Error(data.error || "Failed to schedule interview")
      }

      const data = await response.json()
      console.log("Schedule response:", data)
      setIsSuccess(true)

      // Reset form
      setDate("")
      setTime("")

      // Close after 3 seconds
      setTimeout(() => {
        onClose()
      }, 3000)
    } catch (err: any) {
      console.error("Error scheduling interview:", err)
      setError(err.message || "An unexpected error occurred")
    } finally {
      setIsSubmitting(false)
    }
  }

  // Generate available time slots
  const generateTimeSlots = () => {
    const slots = []
    for (let hour = 9; hour <= 17; hour++) {
      for (let minute = 0; minute < 60; minute += 30) {
        const hourFormatted = hour.toString().padStart(2, "0")
        const minuteFormatted = minute.toString().padStart(2, "0")
        slots.push(`${hourFormatted}:${minuteFormatted}`)
      }
    }
    return slots
  }

  const timeSlots = generateTimeSlots()

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-md bg-card text-card-foreground border-border">
        <CardHeader>
          <CardTitle className="text-2xl">Schedule Interview</CardTitle>
          <CardDescription>
            Select a date and time for your {level} {jobRole} interview
          </CardDescription>
        </CardHeader>

        {isSuccess ? (
          <CardContent className="text-center py-6">
            <div className="mx-auto w-16 h-16 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center mb-4">
              <CheckCircle className="h-8 w-8 text-green-600 dark:text-green-400" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Interview Scheduled!</h3>
            <p className="text-muted-foreground">
              Your interview has been scheduled successfully. You will receive a confirmation email shortly.
            </p>
          </CardContent>
        ) : (
          <form onSubmit={handleSubmit}>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <label htmlFor="date" className="block text-sm font-medium">
                  <Calendar className="inline-block w-4 h-4 mr-2" />
                  Select Date
                </label>
                <input
                  type="date"
                  id="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full p-2 rounded-md border border-input bg-background"
                  min={new Date().toISOString().split("T")[0]}
                />
              </div>

              <div className="space-y-2">
                <label htmlFor="time" className="block text-sm font-medium">
                  <Clock className="inline-block w-4 h-4 mr-2" />
                  Select Time
                </label>
                <select
                  id="time"
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  className="w-full p-2 rounded-md border border-input bg-background"
                >
                  <option value="">Select a time</option>
                  {timeSlots.map((slot) => (
                    <option key={slot} value={slot}>
                      {slot}
                    </option>
                  ))}
                </select>
              </div>

              {error && <div className="bg-destructive/10 text-destructive p-3 rounded-md text-sm">{error}</div>}
            </CardContent>

            <CardFooter className="flex justify-between">
              <Button type="button" variant="outline" onClick={onClose} disabled={isSubmitting}>
                Cancel
              </Button>
              <Button type="submit" disabled={isSubmitting || !date || !time} className="gradient-bg">
                {isSubmitting ? "Scheduling..." : "Schedule Interview"}
              </Button>
            </CardFooter>
          </form>
        )}
      </Card>
    </div>
  )
}
